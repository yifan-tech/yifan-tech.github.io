public class Client {
    public static void main(String[] args) {
        // ʹ�ú�ɫԲ��ʣ��Զ�ƥ���ɫ��о��
        BallPenFactory redFactory = new RedBallPenFactory();
        PenCore redCore = redFactory.createPenCore();
        BallPen redPen = redFactory.createBallPen();
        redCore.writeColor();
        redPen.usePen();

        // ʹ����ɫԲ���
        BallPenFactory blueFactory = new BlueBallPenFactory();
        PenCore blueCore = blueFactory.createPenCore();
        BallPen bluePen = blueFactory.createBallPen();
        blueCore.writeColor();
        bluePen.usePen();
    }
}