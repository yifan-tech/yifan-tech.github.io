public interface BallPen {
    void usePen();
}