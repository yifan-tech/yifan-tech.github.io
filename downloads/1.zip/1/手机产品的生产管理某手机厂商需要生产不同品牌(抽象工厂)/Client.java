public class Client {
    public static void main(String[] args) {
        // 1. ʹ�õ���������
        PhoneFactory lowFactory = new LowPhoneFactory();
        LowPhone lowPhone = lowFactory.createLowPhone();
        lowPhone.showInfo();

        // 2. ʹ�ø���������
        PhoneFactory highFactory = new HighPhoneFactory();
        HighPhone highPhone = highFactory.createHighPhone();
        highPhone.showInfo();
    }
}