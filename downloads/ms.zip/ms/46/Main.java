import java.util.*;

/** 题46 - 逐页迭代器 */
class PageIterator<T> implements Iterator<List<T>> {
    private List<T> data; private int pageSize; private int cursor = 0;
    public PageIterator(List<T> d, int s) { this.data = d; this.pageSize = s; }
    @Override public boolean hasNext() { return cursor < data.size(); }
    @Override public List<T> next() {
        int end = Math.min(cursor + pageSize, data.size());
        List<T> page = data.subList(cursor, end);
        cursor = end; return page;
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== 逐页迭代器 (分页处理) =====\n");
        List<Integer> data = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        PageIterator<Integer> it = new PageIterator<>(data, 3);
        int page = 1;
        while (it.hasNext()) System.out.println("  第" + (page++) + "页: " + it.next());
    }
}
