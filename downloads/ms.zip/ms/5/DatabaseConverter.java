/**
 * DatabaseConverter 具体产品 —— 数据库转换器
 */
public class DatabaseConverter extends DataConverter {

    @Override
    public void convertToXML() {
        System.out.println("  [数据库转换器] 连接数据源: " + sourcePath);
        System.out.println("    -> 执行SQL查询获取数据...");
        System.out.println("    -> 遍历ResultSet构建XML节点...");
        System.out.println("    -> 生成 output.xml");
    }
}
