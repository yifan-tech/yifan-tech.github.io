/**
 * 题5 测试类 —— 数据格式转换工具 (工厂方法模式 + 配置文件)
 *
 * ============================ 类图 ============================
 *
 *   ┌──────────────────────┐
 *   │  ConverterFactory    │  (抽象 Creator)
 *   ├──────────────────────┤
 *   │ + getConverter(path) │────────────┐
 *   │ # createConverter()  │            │ 依赖
 *   └──────────┬───────────┘            ▼
 *              │              ┌───────────────────┐
 *   ┌──────────┼──────────┐   │   DataConverter   │  (抽象 Product)
 *   ▼          ▼          ▼   ├───────────────────┤
 * ┌──────┐ ┌────────┐ ┌────────┐ + convertToXML() │
 * │ Txt  │ │Database│ │ Excel  │ └────────┬──────────┘
 * │Factory│ │Factory │ │Factory │          │
 * └──┬───┘ └───┬────┘ └───┬────┘   ┌──────┼──────┐
 *    │         │         │         ▼      ▼      ▼
 *    ▼         ▼         ▼      ┌────┐ ┌──────┐ ┌───────┐
 *  ┌───┐   ┌───────┐  ┌───────┐ │Txt │ │Data- │ │Excel  │
 *  │Txt│   │Data-  │  │Excel  │ │Conv│ │base  │ │Conv   │
 *  │   │   │base   │  │       │ │    │ │Conv  │ │       │
 *  └───┘   └───────┘  └───────┘ └────┘ └──────┘ └───────┘
 *
 *        ┌──────────────┐
 *        │ ConfigLoader │  (从 config.properties 读取配置)
 *        ├──────────────┤
 *        │+getFactory() │
 *        └──────────────┘
 * =============================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== 数据格式转换工具 - 工厂方法模式 =====\n");

        // 从配置文件读取转换器类型，动态获取对应工厂
        ConverterFactory factory = ConfigLoader.getFactory();

        // 客户端只需使用工厂获取转换器，无需关心具体实现
        DataConverter converter = factory.getConverter("data/sample");

        System.out.println("\n>>> 开始数据转换...");
        converter.convertToXML();

        System.out.println("\n===== 转换完成 =====");
        System.out.println("\n提示: 修改 config.properties 中 converter.type 的值");
        System.out.println("      (txt / database / excel) 即可切换转换器类型");
    }
}
