/**
 * TxtConverterFactory 具体工厂 —— TXT转换器工厂
 */
public class TxtConverterFactory extends ConverterFactory {

    @Override
    protected DataConverter createConverter() {
        return new TxtConverter();
    }
}
