/**
 * DataConverter 抽象产品类
 * 所有数据格式转换器均继承此类
 */
public abstract class DataConverter {

    protected String sourcePath;

    public void setSourcePath(String path) {
        this.sourcePath = path;
    }

    /** 执行数据转换，将源数据转为 XML */
    public abstract void convertToXML();
}
