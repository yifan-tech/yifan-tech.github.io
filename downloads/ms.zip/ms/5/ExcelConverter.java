/**
 * ExcelConverter 具体产品 —— Excel表格转换器
 */
public class ExcelConverter extends DataConverter {

    @Override
    public void convertToXML() {
        System.out.println("  [Excel转换器] 读取Excel文件: " + sourcePath);
        System.out.println("    -> 解析Sheet工作表...");
        System.out.println("    -> 遍历行/列提取单元格数据...");
        System.out.println("    -> 生成 " + sourcePath.replace(".xlsx", "").replace(".xls", "") + ".xml");
    }
}
