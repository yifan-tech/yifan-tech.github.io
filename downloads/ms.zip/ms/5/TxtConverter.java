/**
 * TxtConverter 具体产品 —— TXT文本转换器
 */
public class TxtConverter extends DataConverter {

    @Override
    public void convertToXML() {
        System.out.println("  [TXT转换器] 读取文本文件: " + sourcePath);
        System.out.println("    -> 逐行解析文本内容...");
        System.out.println("    -> 提取关键字段并构建XML节点...");
        System.out.println("    -> 生成 " + sourcePath.replace(".txt", "") + ".xml");
    }
}
