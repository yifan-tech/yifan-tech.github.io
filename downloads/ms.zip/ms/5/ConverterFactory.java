/**
 * ConverterFactory 抽象工厂类 (Creator)
 * 定义工厂方法，子类实现以创建具体的转换器对象
 */
public abstract class ConverterFactory {

    public DataConverter getConverter(String sourcePath) {
        DataConverter converter = createConverter();
        converter.setSourcePath(sourcePath);
        return converter;
    }

    /** 工厂方法 —— 子类实现 */
    protected abstract DataConverter createConverter();
}
