/**
 * DatabaseConverterFactory 具体工厂 —— 数据库转换器工厂
 */
public class DatabaseConverterFactory extends ConverterFactory {

    @Override
    protected DataConverter createConverter() {
        return new DatabaseConverter();
    }
}
