/**
 * ConfigLoader 配置文件加载工具
 * 从 config.properties 中读取 converter.type 来决定使用哪个工厂
 */
import java.io.*;
import java.util.Properties;

public class ConfigLoader {

    private static Properties props = new Properties();

    static {
        try (InputStream in = new FileInputStream("config.properties")) {
            props.load(in);
            System.out.println("[ConfigLoader] 配置文件加载成功");
        } catch (IOException e) {
            System.out.println("[ConfigLoader] 配置文件未找到，使用默认配置: txt");
            props.setProperty("converter.type", "txt");
        }
    }

    /** 获取配置的转换器类型 */
    public static String getConverterType() {
        return props.getProperty("converter.type", "txt");
    }

    /** 根据配置创建对应的工厂 */
    public static ConverterFactory getFactory() {
        String type = getConverterType();
        System.out.println("[ConfigLoader] 当前转换器类型配置: " + type);
        switch (type.toLowerCase()) {
            case "txt":
                return new TxtConverterFactory();
            case "database":
                return new DatabaseConverterFactory();
            case "excel":
                return new ExcelConverterFactory();
            default:
                System.out.println("[ConfigLoader] 未知类型 '" + type + "'，使用默认 TXT 转换器");
                return new TxtConverterFactory();
        }
    }
}
