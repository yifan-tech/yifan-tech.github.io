/**
 * ExcelConverterFactory 具体工厂 —— Excel转换器工厂
 */
public class ExcelConverterFactory extends ConverterFactory {

    @Override
    protected DataConverter createConverter() {
        return new ExcelConverter();
    }
}
