/** 题42 - 表达式接口 */
interface Expression { int interpret(); }

class NumberExpression implements Expression {
    private int n; public NumberExpression(int n) { this.n = n; }
    @Override public int interpret() { return n; }
}
class MulExpression implements Expression {
    private Expression left, right;
    public MulExpression(Expression l, Expression r) { this.left = l; this.right = r; }
    @Override public int interpret() { return left.interpret() * right.interpret(); }
}
class DivExpression implements Expression {
    private Expression left, right;
    public DivExpression(Expression l, Expression r) { this.left = l; this.right = r; }
    @Override public int interpret() { return left.interpret() / right.interpret(); }
}
class ModExpression implements Expression {
    private Expression left, right;
    public ModExpression(Expression l, Expression r) { this.left = l; this.right = r; }
    @Override public int interpret() { return left.interpret() % right.interpret(); }
}

/** 题42 - 解释器 */
public class Main {
    public static Expression parse(String expr) {
        // 简化: 从左到右解析 * / %
        String[] parts = expr.split("(?<=[0-9])(?=[*/%])|(?<=[*/%])(?=[0-9])");
        Expression e = new NumberExpression(Integer.parseInt(parts[0]));
        for (int i = 1; i < parts.length; i += 2) {
            String op = parts[i]; int n = Integer.parseInt(parts[i + 1]);
            if (op.equals("*")) e = new MulExpression(e, new NumberExpression(n));
            else if (op.equals("/")) e = new DivExpression(e, new NumberExpression(n));
            else if (op.equals("%")) e = new ModExpression(e, new NumberExpression(n));
        }
        return e;
    }
    public static void main(String[] args) {
        System.out.println("===== 整数运算解释器 - 解释器模式 =====\n");
        String expr = "3*4/2%4";
        System.out.println("表达式: " + expr);
        System.out.println("结果: " + parse(expr).interpret()); // 12/2%4 = 6%4 = 2
    }
}
