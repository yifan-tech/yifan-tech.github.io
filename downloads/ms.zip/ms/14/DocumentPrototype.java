/**
 * DocumentPrototype 抽象原型类
 * 公文模板的抽象基类，定义克隆接口
 */
public abstract class DocumentPrototype implements Cloneable {

    protected String title;
    protected String content;

    public void setTitle(String title) { this.title = title; }
    public void setContent(String content) { this.content = content; }

    public abstract void display();

    @Override
    public DocumentPrototype clone() {
        try {
            return (DocumentPrototype) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
}
