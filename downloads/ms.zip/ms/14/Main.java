/**
 * 题14 测试类 - 公文管理器 (带原型管理器的原型模式)
 *
 * ============================ 类图 ============================
 * ┌────────────────────┐         ┌──────────────────────┐
 * │ PrototypeManager   │────────>│ DocumentPrototype    │ (抽象原型)
 * ├────────────────────┤         ├──────────────────────┤
 * │-templates:Map      │         │#title, #content       │
 * │+register(key,proto)│         │+clone():DocPrototype   │
 * │+clone(key):DocProto│         │+display()             │
 * │+listTemplates()    │         └──────────┬───────────┘
 * └────────────────────┘                    │
 *                                          ▼
 *                                  ┌──────────────────┐
 *                                  │ OfficialDocument │ (具体原型)
 *                                  ├──────────────────┤
 *                                  │-documentNo       │
 *                                  │-department       │
 *                                  │+setDocumentNo()  │
 *                                  │+setDepartment()  │
 *                                  └──────────────────┘
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 公文管理器 - 原型模式 =====\n");

        // 1. 创建原型管理器并注册模板
        PrototypeManager mgr = new PrototypeManager();
        mgr.register("通知", new OfficialDocument(
                "关于XX的通知", "兹定于X月X日召开会议...",
                "TZ-001", "办公室"));
        mgr.register("请示", new OfficialDocument(
                "关于XX的请示", "为做好XX工作，特请示如下...",
                "QS-001", "综合部"));
        mgr.register("报告", new OfficialDocument(
                "关于XX的报告", "现将XX工作情况报告如下...",
                "BG-001", "财务部"));

        mgr.listTemplates();

        // 2. 通过克隆模板快速创建新公文
        OfficialDocument doc1 = (OfficialDocument) mgr.clone("通知");
        doc1.setTitle("关于端午节放假的通知");
        doc1.setContent("根据国家规定，6月22日-24日放假...");
        doc1.setDocumentNo("TZ-2024-008");
        doc1.setDepartment("人力资源部");
        doc1.display();

        // 3. 再克隆一份请示
        OfficialDocument doc2 = (OfficialDocument) mgr.clone("请示");
        doc2.setTitle("关于采购新服务器的请示");
        doc2.setContent("为提升系统性能，拟采购2台服务器...");
        doc2.setDocumentNo("QS-2024-015");
        doc2.setDepartment("信息技术部");
        doc2.display();

        System.out.println("\n===== 公文创建完毕 =====");
        System.out.println("特点: 克隆模板后仅需修改差异字段，无需重新创建");
    }
}
