import java.util.HashMap;
import java.util.Map;

/**
 * PrototypeManager 原型管理器
 * 管理常用公文模板的注册、获取和克隆
 */
public class PrototypeManager {

    private Map<String, DocumentPrototype> templates = new HashMap<>();

    /** 注册公文模板 */
    public void register(String key, DocumentPrototype prototype) {
        templates.put(key, prototype);
        System.out.println("[模板库] 注册模板: " + key);
    }

    /** 通过克隆获取公文副本 (原型模式核心) */
    public DocumentPrototype clone(String key) {
        DocumentPrototype template = templates.get(key);
        if (template == null) {
            System.out.println("[模板库] 未找到模板: " + key);
            return null;
        }
        System.out.println("[模板库] 克隆模板: " + key);
        return template.clone();
    }

    /** 展示所有可用模板 */
    public void listTemplates() {
        System.out.println("\n  ---- 可用公文模板 ----");
        for (String k : templates.keySet()) {
            System.out.println("  * " + k + ": " + templates.get(k).title);
        }
        System.out.println();
    }
}
