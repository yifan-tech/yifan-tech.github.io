/**
 * OfficialDocument 具体公文类
 */
public class OfficialDocument extends DocumentPrototype {

    private String documentNo;   // 公文编号
    private String department;   // 发文部门

    public OfficialDocument(String title, String content, String docNo, String dept) {
        this.title = title;
        this.content = content;
        this.documentNo = docNo;
        this.department = dept;
    }

    public void setDocumentNo(String docNo) { this.documentNo = docNo; }
    public void setDepartment(String dept) { this.department = dept; }

    @Override
    public void display() {
        System.out.println("\n  ============ 公文预览 ============");
        System.out.println("  | 标题: " + title);
        System.out.println("  | 内容: " + content);
        System.out.println("  | 编号: " + documentNo);
        System.out.println("  | 部门: " + department);
        System.out.println("  ===================================");
    }
}
