/** 题22 - 具体装饰: 高级手机(灯光) */
public class ComplexPhone extends PhoneDecorator {
    public ComplexPhone(Phone phone) { super(phone); }
    @Override public void incomingCall() {
        phone.incomingCall();
        System.out.println("  来电提醒: 灯光闪烁提示");
    }
}
