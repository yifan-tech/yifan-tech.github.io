/** 题22 - 抽象装饰类 */
public abstract class PhoneDecorator extends Phone {
    protected Phone phone;
    public PhoneDecorator(Phone phone) { this.phone = phone; }
}
