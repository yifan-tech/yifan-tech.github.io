/** 题22 - 具体构件: 简单手机 */
public class SimplePhone extends Phone {
    @Override public void incomingCall() {
        System.out.println("  来电提醒: 发出声音提醒");
    }
}
