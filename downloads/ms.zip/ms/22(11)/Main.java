/** 题22 测试 - 手机功能升级 (装饰模式) */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 手机功能升级 - 装饰模式 =====\n");
        System.out.println("[简单手机]");
        new SimplePhone().incomingCall();
        System.out.println("\n[振动手机]");
        new JarPhone(new SimplePhone()).incomingCall();
        System.out.println("\n[高级手机(声音+振动+灯光)]");
        new ComplexPhone(new JarPhone(new SimplePhone())).incomingCall();
    }
}
