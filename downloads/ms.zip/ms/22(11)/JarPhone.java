/** 题22 - 具体装饰: 振动手机 */
public class JarPhone extends PhoneDecorator {
    public JarPhone(Phone phone) { super(phone); }
    @Override public void incomingCall() {
        phone.incomingCall();
        System.out.println("  来电提醒: 产生振动");
    }
}
