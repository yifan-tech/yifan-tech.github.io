/** 题22 - 抽象构件: 手机 */
public abstract class Phone {
    public abstract void incomingCall();
}
