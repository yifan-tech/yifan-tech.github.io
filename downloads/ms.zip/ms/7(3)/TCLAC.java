/**
 * TCLAC 具体产品 —— TCL空调
 */
public class TCLAC extends AC {

    public TCLAC() {
        super("TCL");
    }

    @Override
    public void cool() {
        System.out.println("  [TCLAC] TCL柔风空调正在运行 —— 智能温控、全域柔风、新一级能效");
    }
}
