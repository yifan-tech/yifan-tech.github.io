/**
 * ApplianceFactory 抽象工厂类
 * 定义一个产品族：电视机 + 空调  (同一品牌构成一个产品族)
 */
public abstract class ApplianceFactory {

    /** 生产电视机 */
    public abstract TV createTV();

    /** 生产空调 */
    public abstract AC createAC();
}
