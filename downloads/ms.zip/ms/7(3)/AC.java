/**
 * AC 抽象产品类 —— 空调 (产品等级结构)
 */
public abstract class AC {

    protected String brand;

    public AC(String brand) {
        this.brand = brand;
    }

    /** 制冷/制热 */
    public abstract void cool();
}
