/**
 * TV 抽象产品类 —— 电视机 (产品等级结构)
 */
public abstract class TV {

    protected String brand;

    public TV(String brand) {
        this.brand = brand;
    }

    /** 播放电视 */
    public abstract void play();
}
