/**
 * HaierFactory 具体工厂 —— 海尔工厂 (海尔产品族)
 * 生产海尔品牌的电视机和空调
 */
public class HaierFactory extends ApplianceFactory {

    @Override
    public TV createTV() {
        return new HaierTV();
    }

    @Override
    public AC createAC() {
        return new HaierAC();
    }
}
