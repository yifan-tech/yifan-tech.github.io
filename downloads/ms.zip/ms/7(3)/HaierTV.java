/**
 * HaierTV 具体产品 —— 海尔电视机
 */
public class HaierTV extends TV {

    public HaierTV() {
        super("海尔(Haier)");
    }

    @Override
    public void play() {
        System.out.println("  [HaierTV] 海尔智能电视正在播放 —— 支持4K超清、AI语音控制、家电互联");
    }
}
