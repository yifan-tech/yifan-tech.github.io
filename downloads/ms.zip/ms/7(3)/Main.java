/**
 * 题7 测试类 —— 电器工厂 (抽象工厂模式)
 *
 * ============================ 类图 ============================
 *
 *   ┌─────────────────────────┐
 *   │   ApplianceFactory      │  (抽象工厂)
 *   ├─────────────────────────┤
 *   │ + createTV(): TV        │
 *   │ + createAC(): AC        │
 *   └──────────┬──────────────┘
 *              │
 *     ┌────────┴────────┐
 *     ▼                 ▼
 * ┌───────────┐   ┌───────────┐
 * │ Haier     │   │   TCL     │
 * │ Factory   │   │ Factory   │
 * ├───────────┤   ├───────────┤
 * │+createTV()│   │+createTV()│
 * │+createAC()│   │+createAC()│
 * └──┬────┬───┘   └──┬────┬───┘
 *    │    │          │    │
 *    ▼    ▼          ▼    ▼
 * ┌──────┐┌──────┐┌──────┐┌──────┐
 * │Haier ││Haier ││ TCL  ││ TCL  │
 * │  TV  ││  AC  ││  TV  ││  AC  │
 * └──┬───┘└──┬───┘└──┬───┘└──┬───┘
 *    │       │      │       │
 *    ▼       ▼      ▼       ▼
 *  ┌──┐   ┌──┐   ┌──┐   ┌──┐
 *  │TV│   │AC│   │TV│   │AC│  (抽象产品)
 *  └──┘   └──┘   └──┘   └──┘
 *
 * 产品族(横向): HaierFactory -> {HaierTV, HaierAC}
 * 产品等级(纵向): TV -> {HaierTV, TCLTV}
 * =============================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== 电器工厂 - 抽象工厂模式 =====\n");

        // 1. 使用海尔工厂生产海尔产品族
        System.out.println("--- 海尔工厂生产 ---");
        ApplianceFactory haier = new HaierFactory();
        TV haierTV = haier.createTV();
        AC haierAC = haier.createAC();
        haierTV.play();
        haierAC.cool();

        System.out.println("\n--- TCL工厂生产 ---");
        // 2. 使用TCL工厂生产TCL产品族
        ApplianceFactory tcl = new TCLFactory();
        TV tclTV = tcl.createTV();
        AC tclAC = tcl.createAC();
        tclTV.play();
        tclAC.cool();

        System.out.println("\n===== 生产完毕 =====");
        System.out.println("\n特点: 同一品牌(产品族)的电器配套生产，不会混搭品牌");
    }
}
