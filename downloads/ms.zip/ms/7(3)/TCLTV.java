/**
 * TCLTV 具体产品 —— TCL电视机
 */
public class TCLTV extends TV {

    public TCLTV() {
        super("TCL");
    }

    @Override
    public void play() {
        System.out.println("  [TCLTV] TCL量子点电视正在播放 —— QLED显示、MiniLED背光、120Hz高刷");
    }
}
