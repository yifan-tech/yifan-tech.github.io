/**
 * HaierAC 具体产品 —— 海尔空调
 */
public class HaierAC extends AC {

    public HaierAC() {
        super("海尔(Haier)");
    }

    @Override
    public void cool() {
        System.out.println("  [HaierAC] 海尔智能空调正在运行 —— 自清洁技术、PMV舒适模式、静音18分贝");
    }
}
