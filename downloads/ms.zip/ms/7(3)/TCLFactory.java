/**
 * TCLFactory 具体工厂 —— TCL工厂 (TCL产品族)
 * 生产TCL品牌的电视机和空调
 */
public class TCLFactory extends ApplianceFactory {

    @Override
    public TV createTV() {
        return new TCLTV();
    }

    @Override
    public AC createAC() {
        return new TCLAC();
    }
}
