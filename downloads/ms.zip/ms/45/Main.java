import java.util.*;

/** 题45 - 学生类 */
class Student { String name; int age;
    public Student(String n, int a) { this.name = n; this.age = a; }
    @Override public String toString() { return name + "(" + age + "岁)"; }
}

/** 题45 - 班级聚合类 */
class ClassRoom implements Iterable<Student> {
    private List<Student> students = new ArrayList<>();
    public void add(Student s) { students.add(s); }
    @Override public Iterator<Student> iterator() {
        return students.stream().sorted((a,b)->b.age-a.age).iterator();
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== 学生信息遍历(按年龄降序) =====\n");
        ClassRoom cls = new ClassRoom();
        cls.add(new Student("张三",20)); cls.add(new Student("李四",22)); cls.add(new Student("王五",19));
        for (Student s : cls) System.out.println("  " + s);
    }
}
