/** 题33 - 真实论坛 */
interface Forum { void post(String msg); void editProfile(String info); void editPost(int id, String c); void viewPosts(); }
class RealForum implements Forum {
    @Override public void post(String m) { System.out.println("  [发帖成功] " + m); }
    @Override public void editProfile(String i) { System.out.println("  [修改资料] " + i); }
    @Override public void editPost(int id, String c) { System.out.println("  [编辑帖子#" + id + "] " + c); }
    @Override public void viewPosts() { System.out.println("  [查看帖子列表]"); }
}

/** 题33 - 保护代理 */
public class Main implements Forum {
    private RealForum rf = new RealForum();
    private boolean isGuest;
    public Main(boolean guest) { this.isGuest = guest; }
    private void checkAuth(String action) {
        if (isGuest) throw new RuntimeException("游客无权执行: " + action);
    }
    @Override public void post(String m) { checkAuth("发帖"); rf.post(m); }
    @Override public void editProfile(String i) { checkAuth("修改资料"); rf.editProfile(i); }
    @Override public void editPost(int id, String c) { checkAuth("编辑帖子"); rf.editPost(id, c); }
    @Override public void viewPosts() { rf.viewPosts(); }

    public static void main(String[] args) {
        System.out.println("===== 论坛权限管理 - 保护代理 =====\n");
        System.out.println("--- 已注册用户 ---");
        Main user = new Main(false);
        user.post("大家好"); user.editProfile("新昵称"); user.viewPosts();

        System.out.println("\n--- 游客 ---");
        Main guest = new Main(true);
        guest.viewPosts();
        try { guest.post("游客发帖"); } catch(Exception e) { System.out.println("  [拦截] " + e.getMessage()); }
    }
}
