/** 题24 测试 - 多重加密 (装饰模式) */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 多重加密系统 - 装饰模式 =====\n");
        String src = "Hello";
        System.out.println("原文: " + src);
        System.out.println("一层(移位): " + new ShiftEncryptor().encrypt(src));
        System.out.println("二层(移位+逆向): " + new ReverseEncryptor(new ShiftEncryptor()).encrypt(src));
        System.out.println("三层(移位+逆向+求模): " + new ModEncryptor(new ReverseEncryptor(new ShiftEncryptor())).encrypt(src));
    }
}
