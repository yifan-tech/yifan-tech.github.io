/** 题24 - 具体装饰: 求模加密 */
public class ModEncryptor extends EncryptorDecorator {
    public ModEncryptor(Encryptor e) { super(e); }
    @Override public String encrypt(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : encryptor.encrypt(text).toCharArray()) sb.append(c % 10);
        return sb.toString();
    }
}
