/** 题24 - 具体构件: 移位加密 */
public class ShiftEncryptor extends Encryptor {
    @Override public String encrypt(String text) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) sb.append((char)(c + 1));
        return sb.toString();
    }
}
