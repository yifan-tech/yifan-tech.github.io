/** 题24 - 抽象装饰 */
public abstract class EncryptorDecorator extends Encryptor {
    protected Encryptor encryptor;
    public EncryptorDecorator(Encryptor e) { this.encryptor = e; }
}
