/** 题24 - 具体装饰: 逆向输出加密 */
public class ReverseEncryptor extends EncryptorDecorator {
    public ReverseEncryptor(Encryptor e) { super(e); }
    @Override public String encrypt(String text) {
        return new StringBuilder(encryptor.encrypt(text)).reverse().toString();
    }
}
