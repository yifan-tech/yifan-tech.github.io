/** 题24 - 抽象构件: 加密器 */
public abstract class Encryptor {
    public abstract String encrypt(String text);
}
