/**
 * 候选人抽象类 - 元素接口
 */
public abstract class Candidate {
    protected String name;

    public Candidate(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /**
     * 接受审批访问
     */
    public abstract void accept(AwardCheck check);
}
