import java.util.ArrayList;
import java.util.List;

/**
 * 候选人集合 - 对象结构
 */
public class CandidateList {
    private List<Candidate> candidates = new ArrayList<>();

    public void addCandidate(Candidate c) {
        candidates.add(c);
    }

    /**
     * 接受审批访问
     */
    public void accept(AwardCheck check) {
        for (Candidate c : candidates) {
            c.accept(check);
        }
    }
}
