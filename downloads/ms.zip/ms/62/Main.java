/**
 * 【题62】访问者模式 - 奖励审批系统
 *
 * 类图结构：
 * ┌──────────────────────────────────────────────────────────────────┐
 * │                      <<interface>>                                │
 * │                       AwardCheck                                  │
 * │  + check(Teacher): void                                          │
 * │  + check(Student): void                                          │
 * └──────────────┬────────────────────────────────┬───────────────────┘
 *                │                                │
 *   ┌────────────┴────────────────┐  ┌────────────┴────────────────┐
 *   │   ResearchAwardCheck        │  │   ExcellenceAwardCheck      │
 *   │   科研奖审批                 │  │   成绩优秀奖审批             │
 *   │   教师: 论文 > 10           │  │   教师: 反馈分 ≥ 90         │
 *   │   学生: 论文 > 2            │  │   学生: 平均分 ≥ 90         │
 *   └─────────────────────────────┘  └─────────────────────────────┘
 *
 * ┌──────────────────────────────────────────────────────────────────┐
 * │                    Candidate (abstract)                            │
 * │  # name: String                                                   │
 * │  + accept(AwardCheck): void  {abstract}                           │
 * └──────────────┬────────────────────────────────┬───────────────────┘
 *                │                                │
 *   ┌────────────┴────────────┐    ┌──────────────┴──────────────┐
 *   │        Teacher           │    │         Student             │
 *   │  - paperCount: int       │    │  - paperCount: int          │
 *   │  - feedbackScore: double │    │  - avgScore: double         │
 *   │  + accept(AwardCheck)    │    │  + accept(AwardCheck)       │
 *   └──────────────────────────┘    └─────────────────────────────┘
 *
 * ┌──────────────────────────────────────────────────────────────────┐
 * │                     CandidateList                                 │
 * │  - candidates: List<Candidate>                                   │
 * │  + addCandidate(Candidate)                                       │
 * │  + accept(AwardCheck)  ← 遍历所有候选人                          │
 * └──────────────────────────────────────────────────────────────────┘
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════");
        System.out.println("  访问者模式 - 高校奖励审批系统");
        System.out.println("══════════════════════════════════════════════\n");

        // 创建候选人集合
        CandidateList list = new CandidateList();
        list.addCandidate(new Teacher("张教授", 15, 92.5));   // 论文15篇，反馈92.5
        list.addCandidate(new Teacher("李讲师", 8, 88.0));    // 论文8篇，反馈88
        list.addCandidate(new Teacher("王副教授", 12, 85.0));  // 论文12篇，反馈85
        list.addCandidate(new Student("赵同学", 3, 91.0));     // 论文3篇，平均91
        list.addCandidate(new Student("钱同学", 1, 85.5));     // 论文1篇，平均85.5
        list.addCandidate(new Student("孙同学", 0, 93.0));     // 论文0篇，平均93

        System.out.println("══════════ 科研奖审批 ══════════\n");
        AwardCheck researchCheck = new ResearchAwardCheck();
        list.accept(researchCheck);

        System.out.println("\n══════════ 成绩优秀奖审批 ══════════\n");
        AwardCheck excellenceCheck = new ExcellenceAwardCheck();
        list.accept(excellenceCheck);

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  访问者模式总结：");
        System.out.println("  - 新增奖项类型(访问者)无需修改Teacher/Student类");
        System.out.println("  - 不同奖项对不同候选人(教师/学生)有不同判断标准");
        System.out.println("  - 审批逻辑集中在访问者中，职责清晰");
        System.out.println("══════════════════════════════════════════════");
    }
}
