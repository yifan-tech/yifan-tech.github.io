/**
 * 成绩优秀奖审批 - 具体访问者
 * 条件：教师教学反馈分 ≥ 90 或 学生平均成绩 ≥ 90
 */
public class ExcellenceAwardCheck implements AwardCheck {
    @Override
    public void check(Teacher teacher) {
        System.out.println("  [成绩优秀奖审批] 教师 " + teacher.getName()
                + "：教学反馈分 " + teacher.getFeedbackScore() + " 分");
        if (teacher.getFeedbackScore() >= 90) {
            System.out.println("    ✅ 符合条件（反馈分 ≥ 90），通过成绩优秀奖审批！");
        } else {
            System.out.println("    ❌ 不符合条件（反馈分 < 90），未通过成绩优秀奖审批");
        }
    }

    @Override
    public void check(Student student) {
        System.out.println("  [成绩优秀奖审批] 学生 " + student.getName()
                + "：平均成绩 " + student.getAvgScore() + " 分");
        if (student.getAvgScore() >= 90) {
            System.out.println("    ✅ 符合条件（平均分 ≥ 90），通过成绩优秀奖审批！");
        } else {
            System.out.println("    ❌ 不符合条件（平均分 < 90），未通过成绩优秀奖审批");
        }
    }
}
