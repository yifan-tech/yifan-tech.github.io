/**
 * 教师 - 具体元素
 */
public class Teacher extends Candidate {
    private int paperCount;      // 发表论文数
    private double feedbackScore; // 教学反馈分

    public Teacher(String name, int paperCount, double feedbackScore) {
        super(name);
        this.paperCount = paperCount;
        this.feedbackScore = feedbackScore;
    }

    public int getPaperCount() {
        return paperCount;
    }

    public double getFeedbackScore() {
        return feedbackScore;
    }

    @Override
    public void accept(AwardCheck check) {
        check.check(this);
    }
}
