/**
 * 科研奖审批 - 具体访问者
 * 条件：教师论文数 > 10 或 学生论文数 > 2
 */
public class ResearchAwardCheck implements AwardCheck {
    @Override
    public void check(Teacher teacher) {
        System.out.println("  [科研奖审批] 教师 " + teacher.getName()
                + "：发表论文 " + teacher.getPaperCount() + " 篇");
        if (teacher.getPaperCount() > 10) {
            System.out.println("    ✅ 符合条件（论文 > 10篇），通过科研奖审批！");
        } else {
            System.out.println("    ❌ 不符合条件（论文 ≤ 10篇），未通过科研奖审批");
        }
    }

    @Override
    public void check(Student student) {
        System.out.println("  [科研奖审批] 学生 " + student.getName()
                + "：发表论文 " + student.getPaperCount() + " 篇");
        if (student.getPaperCount() > 2) {
            System.out.println("    ✅ 符合条件（论文 > 2篇），通过科研奖审批！");
        } else {
            System.out.println("    ❌ 不符合条件（论文 ≤ 2篇），未通过科研奖审批");
        }
    }
}
