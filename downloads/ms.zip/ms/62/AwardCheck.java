/**
 * 奖励审批访问者接口
 */
public interface AwardCheck {
    void check(Teacher teacher);
    void check(Student student);
}
