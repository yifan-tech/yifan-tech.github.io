/**
 * 学生 - 具体元素
 */
public class Student extends Candidate {
    private int paperCount;      // 发表论文数
    private double avgScore;     // 平均成绩

    public Student(String name, int paperCount, double avgScore) {
        super(name);
        this.paperCount = paperCount;
        this.avgScore = avgScore;
    }

    public int getPaperCount() {
        return paperCount;
    }

    public double getAvgScore() {
        return avgScore;
    }

    @Override
    public void accept(AwardCheck check) {
        check.check(this);
    }
}
