import java.time.LocalDateTime;

/** 题32 - 真实业务 */
interface Business {
    void method();
}
class RealBusiness implements Business {
    @Override public void method() {
        System.out.println("  [RealBusiness] 执行业务方法...");
    }
}

/** 题32 - 日志代理 */
public class Main implements Business {
    private RealBusiness real = new RealBusiness();
    @Override public void method() {
        String time = LocalDateTime.now().toString().replace("T"," ");
        System.out.println("方法method()被调用，调用时间为" + time);
        try {
            real.method();
            System.out.println("方法method()调用成功");
        } catch (Exception e) {
            System.out.println("方法method()调用失败");
            throw e;
        }
    }
    public static void main(String[] args) {
        System.out.println("===== 日志记录代理 - 代理模式 =====\n");
        new Main().method();
    }
}
