/** 题43 - 表达式接口 */
interface Expression { String interpret(); }
class CopyViewCommand implements Expression {
    private String src, des;
    public CopyViewCommand(String s, String d) { this.src = s; this.des = d; }
    @Override public String interpret() { return "复制 " + src + " 的所有视图(View) -> " + des; }
}
class MoveTableCommand implements Expression {
    private String table, src, des;
    public MoveTableCommand(String t, String s, String d) { this.table = t; this.src = s; this.des = d; }
    @Override public String interpret() { return "移动表 " + table + " 从 " + src + " -> " + des; }
}

/** 题43 - 指令解析器 */
public class Main {
    public static Expression parse(String cmd) {
        String[] parts = cmd.split(" ");
        if (cmd.startsWith("COPYVIEW")) return new CopyViewCommand(parts[2], parts[4]);
        if (cmd.startsWith("MOVE TABLE")) return new MoveTableCommand(parts[2], parts[4], parts[6]);
        return () -> "未知指令";
    }
    public static void main(String[] args) {
        System.out.println("===== 数据库同步指令 - 解释器模式 =====\n");
        String cmd1 = "COPYVIEW FROM srcDB TO desDB";
        String cmd2 = "MOVE TABLE Student FROM srcDB TO desDB";
        System.out.println("指令: " + cmd1);
        System.out.println("执行: " + parse(cmd1).interpret());
        System.out.println("\n指令: " + cmd2);
        System.out.println("执行: " + parse(cmd2).interpret());
    }
}
