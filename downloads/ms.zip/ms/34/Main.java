/** 题34 - 真实图片 */
interface Image { void show(); }
class RealImage implements Image {
    private String name;
    public RealImage(String n) { this.name = n; load(); }
    private void load() { System.out.println("    [加载原图] " + name + " (大文件下载中...)"); try{Thread.sleep(500);}catch(Exception e){} }
    @Override public void show() { System.out.println("    [显示原图] " + name); }
}

/** 题34 - 虚拟代理: 先用图标代替 */
public class Main implements Image {
    private String name; private RealImage real;
    public Main(String n) { this.name = n; }
    @Override public void show() {
        if (real == null) {
            System.out.println("  [图标] 显示缩略图: " + name + ".png  (后台加载原图中...)");
            new Thread(() -> { real = new RealImage(name); }).start();
            try{Thread.sleep(100);}catch(Exception e){}
        } else { real.show(); }
    }
    public static void main(String[] args) throws Exception {
        System.out.println("===== 图片查看器 - 虚拟代理 =====\n");
        Image img = new Main("风景照");
        System.out.println("用户点击前(仅显示图标):");
        img.show();
        Thread.sleep(600);
        System.out.println("\n用户再次点击(原图已加载):");
        img.show();
    }
}
