/**
 * ShapeFactory 简单工厂类
 * 根据传入的图形类型字符串，创建对应的 Shape 对象
 * 若类型不支持则抛出 UnsupportedShapeException
 */
public class ShapeFactory {

    /**
     * 静态工厂方法 —— 根据类型名创建图形对象
     *
     * @param shapeType 图形类型标识: "circle" / "rectangle" / "triangle"
     * @return 对应的 Shape 实例
     * @throws UnsupportedShapeException 当类型不在支持列表中时抛出
     */
    public static Shape createShape(String shapeType) throws UnsupportedShapeException {
        if (shapeType == null || shapeType.trim().isEmpty()) {
            throw new UnsupportedShapeException("(空值)");
        }

        String type = shapeType.trim().toLowerCase();

        switch (type) {
            case "circle":
                return new Circle();
            case "rectangle":
                return new Rectangle();
            case "triangle":
                return new Triangle();
            default:
                throw new UnsupportedShapeException(shapeType);
        }
    }
}
