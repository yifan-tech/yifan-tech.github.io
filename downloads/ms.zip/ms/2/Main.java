/**
 * Main 测试类 - 模拟绘图工具使用简单工厂模式
 *
 * ==================== 类图 ====================
 *
 *          ┌─────────────────────┐
 *          │   <<interface>>     │
 *          │       Shape         │
 *          ├─────────────────────┤
 *          │ + draw() : void     │
 *          │ + erase() : void    │
 *          └──────────┬──────────┘
 *                     │
 *        ┌────────────┼────────────┐
 *        │            │            │
 *        ▼            ▼            ▼
 *   ┌────────┐  ┌──────────┐  ┌──────────┐
 *   │ Circle │  │Rectangle │  │ Triangle │
 *   ├────────┤  ├──────────┤  ├──────────┤
 *   │+draw() │  │ +draw()  │  │ +draw()  │
 *   │+erase()│  │ +erase() │  │ +erase() │
 *   └────────┘  └──────────┘  └──────────┘
 *
 *   ┌────────────────────────┐
 *   │    ShapeFactory        │
 *   ├────────────────────────┤
 *   │ + createShape(         │
 *   │     shapeType: String) │
 *   │   : Shape              │
 *   │   throws               │───throws───▶ ┌────────────────────────────┐
 *   │   UnsupportedShapeExc  │              │ UnsupportedShapeException  │
 *   └────────────────────────┘              ├────────────────────────────┤
 *                                           │ + UnsupportedShapeExc(     │
 *                                           │     shapeType: String)     │
 *                                           └────────────────────────────┘
 * ================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("========== 简单工厂模式绘图工具测试 ==========\n");

        // 使用 ShapeFactory 创建不同图形并调用 draw()/erase()

        // 1. 绘制圆形
        testShape("circle");

        // 2. 绘制矩形
        testShape("rectangle");

        // 3. 绘制三角形
        testShape("triangle");

        // 4. 尝试绘制不支持的图形 —— 应抛出异常
        testShape("pentagon");

        // 5. 空值测试
        testShape(null);

        System.out.println("\n========== 测试结束 ==========");
    }

    /**
     * 统一测试方法：创建图形 → draw → erase
     */
    private static void testShape(String typeName) {
        System.out.println(">>> 请求创建图形: " + typeName);
        try {
            Shape shape = ShapeFactory.createShape(typeName);
            shape.draw();
            shape.erase();
        } catch (UnsupportedShapeException e) {
            System.out.println("  ⚠️ 异常捕获: " + e.getMessage());
        }
        System.out.println();
    }
}
