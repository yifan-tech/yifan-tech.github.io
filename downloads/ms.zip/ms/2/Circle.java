/**
 * Circle 具体产品类 - 圆形
 */
public class Circle implements Shape {

    public Circle() {
        System.out.println("创建了一个圆形(Circle)对象");
    }

    @Override
    public void draw() {
        System.out.println("  🟢 正在绘制圆形 —— 使用圆心+半径，调用 fillOval() 完成绘制");
    }

    @Override
    public void erase() {
        System.out.println("  ❌ 正在擦除圆形 —— 清除圆形区域像素");
    }
}
