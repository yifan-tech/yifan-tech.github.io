/**
 * Rectangle 具体产品类 - 矩形
 */
public class Rectangle implements Shape {

    public Rectangle() {
        System.out.println("创建了一个矩形(Rectangle)对象");
    }

    @Override
    public void draw() {
        System.out.println("  🔷 正在绘制矩形 —— 使用左上角坐标+宽高，调用 fillRect() 完成绘制");
    }

    @Override
    public void erase() {
        System.out.println("  ❌ 正在擦除矩形 —— 清除矩形区域像素");
    }
}
