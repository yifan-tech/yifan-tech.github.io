/**
 * UnsupportedShapeException 自定义异常
 * 当请求绘制不支持的几何图形时抛出
 */
public class UnsupportedShapeException extends Exception {

    public UnsupportedShapeException(String shapeType) {
        super("不支持的几何图形类型: " + shapeType + " —— 当前仅支持 Circle、Rectangle、Triangle");
    }
}
