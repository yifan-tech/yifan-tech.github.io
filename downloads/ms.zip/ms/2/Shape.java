/**
 * Shape 接口 - 抽象产品
 * 所有几何图形均实现此接口，提供 draw() 和 erase() 方法
 */
public interface Shape {

    /** 绘制图形 */
    void draw();

    /** 擦除图形 */
    void erase();
}
