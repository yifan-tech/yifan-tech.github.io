/**
 * Triangle 具体产品类 - 三角形
 */
public class Triangle implements Shape {

    public Triangle() {
        System.out.println("创建了一个三角形(Triangle)对象");
    }

    @Override
    public void draw() {
        System.out.println("  🔺 正在绘制三角形 —— 使用三个顶点坐标，调用 fillPolygon() 完成绘制");
    }

    @Override
    public void erase() {
        System.out.println("  ❌ 正在擦除三角形 —— 清除三角形区域像素");
    }
}
