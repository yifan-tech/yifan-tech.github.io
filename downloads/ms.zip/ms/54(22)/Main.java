/** 题54 - 论坛系统 (状态模式) */

import java.util.Scanner;

/** 状态接口 */
interface LevelState {
    void post(ForumUser user);
    void reply(ForumUser user);
    void download(ForumUser user, int cost);
}

/** 新手状态 */
class NoviceState implements LevelState {
    @Override public void post(ForumUser u) { u.addScore(5); System.out.println("  [新手] 发表留言 +5积分 | 当前积分: " + u.score); }
    @Override public void reply(ForumUser u) { u.addScore(3); System.out.println("  [新手] 回复留言 +3积分 | 当前积分: " + u.score); }
    @Override public void download(ForumUser u, int c) { System.out.println("  [新手] 积分不足,不能下载文件!"); }
}
/** 高手状态 */
class ExpertState implements LevelState {
    @Override public void post(ForumUser u) { u.addScore(10); System.out.println("  [高手] 发表留言 +10积分(双倍!) | 当前积分: " + u.score); }
    @Override public void reply(ForumUser u) { u.addScore(5); System.out.println("  [高手] 回复留言 +5积分 | 当前积分: " + u.score); }
    @Override public void download(ForumUser u, int c) {
        if (u.score - c < 0) System.out.println("  [高手] 积分不足,不能下载!"); else { u.score -= c; System.out.println("  [高手] 下载文件 -" + c + "积分 | 剩余: " + u.score); }
    }
}
/** 专家状态 */
class MasterState implements LevelState {
    @Override public void post(ForumUser u) { u.addScore(10); System.out.println("  [专家] 发表留言 +10积分(双倍!) | 当前积分: " + u.score); }
    @Override public void reply(ForumUser u) { u.addScore(5); System.out.println("  [专家] 回复留言 +5积分 | 当前积分: " + u.score); }
    @Override public void download(ForumUser u, int c) {
        int half = c / 2;
        if (u.score - half < 0) System.out.println("  [专家] 积分不足,不能下载!"); else { u.score -= half; System.out.println("  [专家] 下载文件 -" + half + "积分(半价!) | 剩余: " + u.score); }
    }
}

/** 用户类 */
class ForumUser {
    int score; LevelState state;
    public ForumUser() { this.score = 0; this.state = new NoviceState(); }
    void checkState() {
        if (score >= 1000) state = new MasterState();
        else if (score >= 100) state = new ExpertState();
        else state = new NoviceState();
    }
    void addScore(int s) { score += s; checkState(); }
}

/** 题54 主测试 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 论坛积分状态 - 状态模式 =====\n");
        ForumUser user = new ForumUser();

        // 新手发帖攒积分
        for (int i = 0; i < 25; i++) user.state.post(user);  // 25*5=125 -> 高手

        // 高手下载
        user.state.download(user, 50);
        user.state.download(user, 100); // 积分不足

        // 继续升到专家
        user.score = 1100; user.checkState();
        System.out.println("\n>>> 晋升专家! 积分: " + user.score);
        user.state.post(user);
        user.state.download(user, 100); // 半价
    }
}
