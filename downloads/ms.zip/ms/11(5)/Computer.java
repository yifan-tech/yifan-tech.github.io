/**
 * Computer 产品类 —— 由建造者逐步组装
 */
public class Computer {
    private String type;     // 计算机类型
    private String cpu;
    private String memory;
    private String hardDisk;
    private String mainBoard;
    private String monitor;  // 可选，服务器无显示器

    public void setType(String type) { this.type = type; }
    public void setCpu(String cpu) { this.cpu = cpu; }
    public void setMemory(String memory) { this.memory = memory; }
    public void setHardDisk(String hardDisk) { this.hardDisk = hardDisk; }
    public void setMainBoard(String mainBoard) { this.mainBoard = mainBoard; }
    public void setMonitor(String monitor) { this.monitor = monitor; }

    public void show() {
        System.out.println("\n  ====== " + type + " 配置清单 ======");
        System.out.println("  | CPU:    " + cpu);
        System.out.println("  | 内存:   " + memory);
        System.out.println("  | 硬盘:   " + hardDisk);
        System.out.println("  | 主板:   " + mainBoard);
        if (monitor != null) System.out.println("  | 显示器: " + monitor);
        System.out.println("  ================================");
    }
}
