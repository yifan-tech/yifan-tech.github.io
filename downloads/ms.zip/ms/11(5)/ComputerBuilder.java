/**
 * ComputerBuilder 抽象建造者
 */
public abstract class ComputerBuilder {
    protected Computer computer = new Computer();

    public abstract void buildCPU();
    public abstract void buildMemory();
    public abstract void buildHardDisk();
    public abstract void buildMainBoard();
    public abstract void buildMonitor();  // 可选

    public Computer getResult() { return computer; }
}
