/**
 * 题11 测试类 - 计算机组装工厂 (建造者模式)
 *
 * ============================ 类图 ============================
 * ┌─────────────────┐      ┌─────────────────────┐
 * │ ComputerDirector │─────>│  ComputerBuilder     │ (抽象建造者)
 * ├─────────────────┤      ├─────────────────────┤
 * │+construct(b,type)│     │# computer:Computer   │
 * └─────────────────┘      │+buildCPU()           │
 *                          │+buildMemory()        │
 *                          │+buildHardDisk()      │
 *                          │+buildMainBoard()     │
 *                          │+buildMonitor()       │
 *                          │+getResult():Computer │
 *                          └──────────┬───────────┘
 *               ┌────────────────────┼────────────────┐
 *               ▼                    ▼                ▼
 *      ┌──────────────┐    ┌──────────────┐   ┌──────────────┐
 *      │NotebookBuilder│   │DesktopBuilder│   │ServerBuilder │
 *      └──────────────┘    └──────────────┘   └──────────────┘
 *               │                    │                │
 *               └────────────────────┼────────────────┘
 *                                    ▼
 *                           ┌──────────────┐
 *                           │   Computer   │ (产品)
 *                           └──────────────┘
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 计算机组装工厂 - 建造者模式 =====\n");
        ComputerDirector director = new ComputerDirector();

        // 1. 组装笔记本
        Computer notebook = director.construct(new NotebookBuilder(), "笔记本电脑");
        notebook.show();

        // 2. 组装台式机
        Computer desktop = director.construct(new DesktopBuilder(), "台式电脑");
        desktop.show();

        // 3. 组装服务器 (无显示器)
        Computer server = director.construct(new ServerBuilder(), "服务器主机");
        server.show();

        System.out.println("\n===== 所有计算机组装完毕 =====");
    }
}
