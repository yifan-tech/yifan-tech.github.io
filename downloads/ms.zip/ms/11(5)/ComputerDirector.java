/**
 * ComputerDirector 指挥者 —— 控制组装流程
 */
public class ComputerDirector {

    public Computer construct(ComputerBuilder builder, String type) {
        builder.computer.setType(type);
        System.out.println("\n>>> 开始组装 " + type + " ...");

        System.out.println("  [1/5] 安装CPU...");
        builder.buildCPU();

        System.out.println("  [2/5] 安装内存...");
        builder.buildMemory();

        System.out.println("  [3/5] 安装硬盘...");
        builder.buildHardDisk();

        System.out.println("  [4/5] 安装主板...");
        builder.buildMainBoard();

        System.out.println("  [5/5] 安装显示器...");
        builder.buildMonitor();

        System.out.println(">>> " + type + " 组装完成!");
        return builder.getResult();
    }
}
