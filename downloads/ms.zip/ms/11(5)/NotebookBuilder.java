/**
 * NotebookBuilder 具体建造者 —— 笔记本
 */
public class NotebookBuilder extends ComputerBuilder {
    @Override public void buildCPU()    { computer.setCpu("Intel i7-13700H (移动版)"); }
    @Override public void buildMemory() { computer.setMemory("16GB LPDDR5 6400MHz"); }
    @Override public void buildHardDisk(){ computer.setHardDisk("1TB NVMe SSD"); }
    @Override public void buildMainBoard(){ computer.setMainBoard("定制笔记本主板"); }
    @Override public void buildMonitor(){ computer.setMonitor("15.6寸 2.5K IPS 165Hz"); }
}
