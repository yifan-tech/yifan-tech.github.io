/**
 * ServerBuilder 具体建造者 —— 服务器主机 (无显示器)
 */
public class ServerBuilder extends ComputerBuilder {
    @Override public void buildCPU()    { computer.setCpu("AMD EPYC 9654 (96核)"); }
    @Override public void buildMemory() { computer.setMemory("256GB ECC DDR5 4800MHz"); }
    @Override public void buildHardDisk(){ computer.setHardDisk("4TB NVMe SSD (RAID 10)"); }
    @Override public void buildMainBoard(){ computer.setMainBoard("双路服务器主板"); }
    @Override public void buildMonitor(){ /* 服务器不包含显示器 */ }
}
