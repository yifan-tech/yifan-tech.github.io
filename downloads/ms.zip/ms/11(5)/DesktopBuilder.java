/**
 * DesktopBuilder 具体建造者 —— 台式机
 */
public class DesktopBuilder extends ComputerBuilder {
    @Override public void buildCPU()    { computer.setCpu("Intel i9-14900K"); }
    @Override public void buildMemory() { computer.setMemory("32GB DDR5 6000MHz"); }
    @Override public void buildHardDisk(){ computer.setHardDisk("2TB NVMe SSD + 4TB HDD"); }
    @Override public void buildMainBoard(){ computer.setMainBoard("Z790 ATX 主板"); }
    @Override public void buildMonitor(){ computer.setMonitor("27寸 4K IPS 144Hz"); }
}
