/**
 * Customer 客户类 —— 实现浅克隆和深克隆
 */
public class Customer implements Cloneable {
    private String name;
    private int age;
    private Address address;   // 引用类型成员

    public Customer(String name, int age, Address address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public void setName(String name) { this.name = name; }
    public void setAge(int age) { this.age = age; }
    public Address getAddress() { return address; }

    /** 浅克隆: 仅复制基本类型和引用(不复制引用指向的对象) */
    public Customer shallowClone() {
        try {
            return (Customer) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }

    /** 深克隆: 连同Address对象一并复制 */
    public Customer deepClone() {
        Customer c = shallowClone();        // 先浅克隆
        c.address = this.address.clone();   // 再手动克隆引用对象
        return c;
    }

    public void show(String label) {
        System.out.println(label + " [name=" + name + ", age=" + age +
                ", addrHash=" + Integer.toHexString(System.identityHashCode(address)) + "]");
        address.show();
    }
}
