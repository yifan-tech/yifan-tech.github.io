/**
 * Address 地址类 —— 客户地址
 */
public class Address implements Cloneable {
    private String province;
    private String city;
    private String street;

    public Address(String province, String city, String street) {
        this.province = province;
        this.city = city;
        this.street = street;
    }

    public void setCity(String city) { this.city = city; }
    public void setStreet(String street) { this.street = street; }

    public void show() {
        System.out.println("  [地址] " + province + "省 " + city + "市 " + street);
    }

    @Override
    public Address clone() {
        try {
            return (Address) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
            return null;
        }
    }
}
