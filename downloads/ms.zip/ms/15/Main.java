/**
 * 题15 测试类 - Customer浅克隆 vs 深克隆 (原型模式)
 *
 * ============================ 类图 ============================
 *    ┌──────────────┐        ┌──────────────┐
 *    │   Customer   │───────>│   Address    │
 *    ├──────────────┤        ├──────────────┤
 *    │-name:String  │        │-province     │
 *    │-age:int      │        │-city         │
 *    │-address      │        │-street       │
 *    ├──────────────┤        ├──────────────┤
 *    │+shallowClone()│       │+clone()      │
 *    │+deepClone()  │        │+show()       │
 *    └──────────────┘        └──────────────┘
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== Customer 浅克隆 vs 深克隆 =====\n");

        Address addr1 = new Address("广东", "深圳", "科技南路88号");
        Customer original = new Customer("张三", 30, addr1);
        System.out.println("--- 原始对象 ---");
        original.show("原始");
        System.out.println("\n>>> 浅克隆测试 <<<");

        // 1. 浅克隆
        Customer shallow = original.shallowClone();
        shallow.setName("李四(浅克隆)");
        shallow.getAddress().setCity("广州");  // 修改引用对象
        shallow.getAddress().setStreet("天河路100号");

        original.show("原始(被影响)");
        shallow.show("浅克隆副本");
        System.out.println("  >>> 浅克隆: 修改副本的Address会影响原对象 (共享同一个Address对象)");

        // 2. 深克隆 (重新创建)
        Address addr2 = new Address("浙江", "杭州", "文三路168号");
        Customer original2 = new Customer("王五", 28, addr2);

        System.out.println("\n>>> 深克隆测试 <<<");
        Customer deep = original2.deepClone();
        deep.setName("赵六(深克隆)");
        deep.getAddress().setCity("宁波");     // 修改副本的Address
        deep.getAddress().setStreet("中山东路1号");

        original2.show("原始(不受影响)");
        deep.show("深克隆副本");
        System.out.println("  >>> 深克隆: 修改副本的Address不影响原对象 (各自独立的Address对象)");

        System.out.println("\n===== 对比总结 =====");
        System.out.println("浅克隆: 基本类型独立 | 引用类型共享 | 速度快 | 修改相互影响");
        System.out.println("深克隆: 基本类型独立 | 引用类型独立 | 开销大 | 完全隔离");
    }
}
