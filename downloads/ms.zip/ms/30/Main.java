import java.util.HashMap;
import java.util.Map;

/** 题30 - 享元: 多媒体资源 (内部状态) */
class MediaResource {
    private String name; private byte[] data; // 内部状态
    public MediaResource(String name) { this.name = name; this.data = new byte[1024]; }
    public void display(int x, int y, int w, int h) { // 外部状态
        System.out.println("  显示 " + name + " 位置(" + x + "," + y + ") 大小(" + w + "x" + h + ") hash:" + hashCode());
    }
}

class MediaFactory {
    private Map<String, MediaResource> pool = new HashMap<>();
    public MediaResource get(String name) {
        return pool.computeIfAbsent(name, n -> {
            System.out.println("  [加载] 新建资源: " + n);
            return new MediaResource(n);
        });
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== 文档编辑器 - 享元模式 =====\n");
        MediaFactory f = new MediaFactory();
        f.get("logo.png").display(10, 20, 100, 80);
        f.get("logo.png").display(200, 20, 50, 50);  // 同一图片共享
        f.get("intro.gif").display(10, 150, 200, 150);
        f.get("logo.png").display(300, 200, 80, 60);
        System.out.println("\n提示: 图片数据只存一份, 位置/大小作为外部状态");
    }
}
