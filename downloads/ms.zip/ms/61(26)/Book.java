/**
 * 图书 - 具体元素（不需要过秤，按定价出售）
 */
public class Book extends Product {
    private String isbn;

    public Book(String name, double price, String isbn) {
        super(name, price);
        this.isbn = isbn;
    }

    public String getIsbn() {
        return isbn;
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
}
