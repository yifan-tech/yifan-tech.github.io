/**
 * 访问者接口 - 定义对不同商品的访问操作
 */
public interface Visitor {
    void visit(Apple apple);
    void visit(Book book);
}
