/**
 * 商品抽象类 - 元素接口
 */
public abstract class Product {
    protected String name;
    protected double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }

    /**
     * 接受访问者访问
     */
    public abstract void accept(Visitor visitor);
}
