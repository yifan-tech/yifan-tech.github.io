/**
 * 收银员 - 具体访问者（计算商品价格）
 */
public class Cashier implements Visitor {
    private String name;
    private double totalPrice = 0.0;

    public Cashier(String name) {
        this.name = name;
    }

    @Override
    public void visit(Apple apple) {
        // 苹果需要过秤计价：重量 × 单价
        double applePrice = apple.getWeight() * apple.getPrice();
        System.out.println("  [收银员" + name + "] 苹果过秤: " + apple.getName()
                + "，重量 " + apple.getWeight() + "kg × 单价 " + apple.getPrice()
                + "元/kg = " + String.format("%.2f", applePrice) + "元");
        totalPrice += applePrice;
    }

    @Override
    public void visit(Book book) {
        // 图书按定价计价
        System.out.println("  [收银员" + name + "] 图书扫码: 《" + book.getName() + "》"
                + "，定价 " + book.getPrice() + "元");
        totalPrice += book.getPrice();
    }

    public double getTotalPrice() {
        return totalPrice;
    }
}
