/**
 * 苹果 - 具体元素（需要过秤计价）
 */
public class Apple extends Product {
    private double weight; // 重量（kg）

    public Apple(double weight) {
        super("红富士苹果", 12.0); // 单价12元/kg
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }

    @Override
    public void accept(Visitor visitor) {
        visitor.visit(this);
    }
}
