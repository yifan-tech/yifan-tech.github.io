import java.util.ArrayList;
import java.util.List;

/**
 * 购物车 - 对象结构（存储商品集合）
 */
public class ShoppingCart {
    private List<Product> products = new ArrayList<>();

    public void addProduct(Product product) {
        products.add(product);
    }

    /**
     * 接受访问者访问所有商品
     */
    public void accept(Visitor visitor) {
        for (Product product : products) {
            product.accept(visitor);
        }
    }
}
