/**
 * 【题61】访问者模式 - 超市购物过程模拟
 *
 * 类图结构：
 * ┌──────────────────────────────────────────────────────────────────┐
 * │                      <<interface>>                                │
 * │                        Visitor                                    │
 * │  + visit(Apple): void                                             │
 * │  + visit(Book): void                                              │
 * └──────────────┬────────────────────────────────┬───────────────────┘
 *                │                                │
 *   ┌────────────┴────────────┐    ┌──────────────┴──────────────┐
 *   │        Customer          │    │         Cashier              │
 *   │  - name: String          │    │  - name: String              │
 *   │  + visit(Apple) 检查质量  │    │  - totalPrice: double        │
 *   │  + visit(Book)  翻阅检查  │    │  + visit(Apple) 过秤计价     │
 *   └──────────────────────────┘    │  + visit(Book)  扫码计价     │
 *                                   │  + getTotalPrice()           │
 *                                   └─────────────────────────────┘
 *
 * ┌──────────────────────────────────────────────────────────────────┐
 * │                    Product (abstract)                              │
 * │  # name: String                                                   │
 * │  # price: double                                                  │
 * │  + accept(Visitor): void  {abstract}                              │
 * └──────────────┬────────────────────────────────┬───────────────────┘
 *                │                                │
 *   ┌────────────┴────────────┐    ┌──────────────┴──────────────┐
 *   │         Apple            │    │          Book                │
 *   │  - weight: double        │    │  - isbn: String              │
 *   │  + accept(Visitor)       │    │  + accept(Visitor)           │
 *   └──────────────────────────┘    └─────────────────────────────┘
 *
 * ┌──────────────────────────────────────────────────────────────────┐
 * │                      ShoppingCart                                 │
 * │  - products: List<Product>                                       │
 * │  + addProduct(Product)                                           │
 * │  + accept(Visitor)  ← 遍历所有商品调用accept()                    │
 * └──────────────────────────────────────────────────────────────────┘
 *
 * 流程：ShoppingCart.accept(visitor) → Product.accept(visitor) → visitor.visit(product)
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════");
        System.out.println("  访问者模式 - 超市购物过程模拟");
        System.out.println("══════════════════════════════════════════════\n");

        // 创建购物车并添加商品
        ShoppingCart cart = new ShoppingCart();
        cart.addProduct(new Apple(0.5));        // 0.5kg苹果
        cart.addProduct(new Book("设计模式", 59.0, "978-7-111-12345-6"));
        cart.addProduct(new Apple(1.2));        // 1.2kg苹果
        cart.addProduct(new Book("Java编程思想", 108.0, "978-7-111-67890-1"));
        cart.addProduct(new Apple(0.08));       // 0.08kg苹果（太小）

        System.out.println("--- 第1阶段：顾客检查商品质量 ---\n");
        Customer customer = new Customer("小明");
        cart.accept(customer);

        System.out.println("\n--- 第2阶段：收银员计算价格 ---\n");
        Cashier cashier = new Cashier("小红");
        cart.accept(cashier);

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  💰 应付总金额: " + String.format("%.2f", cashier.getTotalPrice()) + " 元");
        System.out.println("══════════════════════════════════════════════");

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  访问者模式总结：");
        System.out.println("  - 将数据操作(访问)与数据结构(商品)分离");
        System.out.println("  - 增加新访问者(如库存管理员)无需修改商品类");
        System.out.println("  - 不同访问者对同一商品有不同处理方式(检查vs计价)");
        System.out.println("══════════════════════════════════════════════");
    }
}
