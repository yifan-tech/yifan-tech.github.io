/**
 * 顾客 - 具体访问者（检查商品质量）
 */
public class Customer implements Visitor {
    private String name;

    public Customer(String name) {
        this.name = name;
    }

    @Override
    public void visit(Apple apple) {
        System.out.println("  [顾客" + name + "] 检查苹果: " + apple.getName()
                + "，重量 " + apple.getWeight() + "kg，单价 " + apple.getPrice() + "元/kg");
        if (apple.getWeight() > 0.1) {
            System.out.println("  [顾客" + name + "] 苹果新鲜饱满，质量不错！加入购物车 ✓");
        } else {
            System.out.println("  [顾客" + name + "] 苹果太小，不要了 ✗");
        }
    }

    @Override
    public void visit(Book book) {
        System.out.println("  [顾客" + name + "] 检查图书: 《" + book.getName() + "》"
                + "，ISBN: " + book.getIsbn() + "，定价 " + book.getPrice() + "元");
        System.out.println("  [顾客" + name + "] 翻阅内容，印刷清晰，正版图书，加入购物车 ✓");
    }
}
