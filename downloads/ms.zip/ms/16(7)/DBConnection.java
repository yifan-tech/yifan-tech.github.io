/**
 * DBConnection 数据库连接类 (模拟)
 */
public class DBConnection {

    private int id;

    public DBConnection(int id) {
        this.id = id;
        System.out.println("  [创建] 数据库连接对象 #" + id);
    }

    public void connect() {
        System.out.println("  [连接#" + id + "] 正在连接数据库... 连接成功!");
    }

    public void disconnect() {
        System.out.println("  [连接#" + id + "] 断开数据库连接");
    }

    public int getId() { return id; }
}
