/**
 * 题16 测试类 - 数据库连接池 (改造单例为多例模式)
 *
 * ============================ 类图 ============================
 * ┌──────────────────────┐
 * │   ConnectionPool     │ (多例)
 * ├──────────────────────┤
 * │-pool:List<DBConn>    │
 * │-poolSize:int         │
 * │-random:Random        │
 * │-ConnectionPool()     │← 私有构造
 * ├──────────────────────┤
 * │+init(size):void      │
 * │+getConnection():Conn │← 静态工厂方法
 * │+showPool():void      │
 * └──────────┬───────────┘
 *            │ 管理
 *            ▼
 * ┌──────────────────────┐
 * │    DBConnection      │
 * ├──────────────────────┤
 * │-id:int               │
 * │+connect()            │
 * │+disconnect()         │
 * └──────────────────────┘
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 数据库连接池 - 改造单例模式 =====\n");

        // 初始化3个连接
        ConnectionPool.init(3);
        ConnectionPool.showPool();

        // 模拟客户端多次从池中获取连接
        System.out.println("\n--- 客户端请求连接 ---");
        for (int i = 1; i <= 5; i++) {
            System.out.print("请求 #" + i + ": ");
            DBConnection conn = ConnectionPool.getConnection();
            conn.connect();
        }

        System.out.println("\n===== 演示完毕 =====");
        System.out.println("特点: 控制实例数，从池中随机获取，连接对象可复用");
    }
}
