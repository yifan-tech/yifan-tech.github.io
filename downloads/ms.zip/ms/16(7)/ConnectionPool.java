import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * ConnectionPool 连接池 (对单例模式改造: 提供指定个数的实例)
 * 控制实例化数量，从池中随机返回连接对象
 */
public class ConnectionPool {

    private static List<DBConnection> pool;
    private static int poolSize;
    private static Random random = new Random();

    /** 初始化连接池 (代替构造方法) */
    public static void init(int size) {
        if (pool != null) return; // 防止重复初始化
        poolSize = size;
        pool = new ArrayList<>();
        System.out.println(">>> 初始化连接池，大小: " + size);
        for (int i = 1; i <= size; i++) {
            pool.add(new DBConnection(i));
        }
        System.out.println(">>> 连接池初始化完成\n");
    }

    /** 从池中随机获取一个连接 */
    public static DBConnection getConnection() {
        if (pool == null) {
            init(2); // 默认2个
        }
        int index = random.nextInt(pool.size());
        DBConnection conn = pool.get(index);
        System.out.println("[连接池] 随机分配连接 #" + conn.getId() + " (池中共" + pool.size() + "个)");
        return conn;
    }

    /** 查看池中所有连接 */
    public static void showPool() {
        System.out.println("\n  ---- 连接池状态 ----");
        for (DBConnection c : pool) {
            System.out.println("  | 连接 #" + c.getId() + " | 状态: 就绪");
        }
        System.out.println("  ---------------------");
    }

    /** 禁止外部实例化: 构造方法私有 */
    private ConnectionPool() {}
}
