/** 题25 - 子系统: 文件读取器 */
class FileReader {
    public String read(String path) {
        System.out.println("  [FileReader] 读取文件: " + path);
        return "<raw>" + path.split("\\.")[0] + "_data</raw>";
    }
}
/** 题25 - 子系统: XML转换器 */
class XmlConverter {
    public String convert(String data) {
        System.out.println("  [XMLConverter] 转换为XML格式");
        return data.replace("raw>", "xml>");
    }
}
/** 题25 - 子系统: 数据分析器 */
class DataAnalyzer {
    public String analyze(String xml) {
        System.out.println("  [DataAnalyzer] 执行统计分析");
        return "分析结果: 数据正常, 共处理1条记录";
    }
}
/** 题25 - 子系统: 报表生成器 */
class ReportGenerator {
    public void generate(String result) {
        System.out.println("  [ReportGenerator] 生成报表 -> " + result);
    }
}

/** 题25 - 抽象外观 */
abstract class DataFacade {
    public abstract void process(String path);
}

/** 题25 - 具体外观 */
public class Main extends DataFacade {
    private FileReader reader = new FileReader();
    private XmlConverter converter = new XmlConverter();
    private DataAnalyzer analyzer = new DataAnalyzer();
    private ReportGenerator reporter = new ReportGenerator();

    @Override public void process(String path) {
        System.out.println("\n>>> 处理文件: " + path);
        String raw = reader.read(path);
        String xml = converter.convert(raw);
        String result = analyzer.analyze(xml);
        reporter.generate(result);
    }

    public static void main(String[] args) {
        System.out.println("===== 数据处理报表 - 外观模式 =====\n");
        new Main().process("data/report.txt");
        System.out.println("\n提示: 引入抽象外观类DataFacade, 可为XML格式文件提供跳过转换的实现");
    }
}
