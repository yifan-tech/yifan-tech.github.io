/**
 * 按姓名查询（桥接 - 具体实现化角色）
 */
public class QueryByName implements QueryStrategy {
    @Override
    public String query(String keyword) {
        // 模拟数据库查询
        return "客户姓名：" + keyword + " | 编号：C001 | 单位：科技有限公司 | 电话：138****1234";
    }
}
