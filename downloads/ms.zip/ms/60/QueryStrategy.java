/**
 * 查询策略接口（桥接模式 - 实现化角色）
 * 定义如何根据条件查询客户信息
 */
public interface QueryStrategy {
    /**
     * 根据关键字查询客户信息
     */
    String query(String keyword);
}
