/**
 * 精简模式显示（桥接 - 具体实现化角色）
 */
public class SimpleDisplay implements DisplayStyle {
    @Override
    public void display(String result) {
        System.out.println("  [精简模式] " + result);
    }
}
