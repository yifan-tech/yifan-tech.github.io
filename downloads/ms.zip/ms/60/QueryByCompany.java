/**
 * 按单位名称查询（桥接 - 具体实现化角色）
 */
public class QueryByCompany implements QueryStrategy {
    @Override
    public String query(String keyword) {
        // 模拟数据库查询
        return "单位名称：" + keyword + " | 联系人：李四 | 编号：C003 | 电话：136****9012";
    }
}
