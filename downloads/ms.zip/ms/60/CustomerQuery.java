/**
 * 客户信息查询业务类（模板方法模式 - 抽象类角色）
 * 同时作为桥接模式的抽象化角色，组合QueryStrategy和DisplayStyle
 */
public abstract class CustomerQuery {
    // 桥接：持有查询策略和显示样式的引用
    protected QueryStrategy queryStrategy;
    protected DisplayStyle displayStyle;

    public void setQueryStrategy(QueryStrategy qs) {
        this.queryStrategy = qs;
    }

    public void setDisplayStyle(DisplayStyle ds) {
        this.displayStyle = ds;
    }

    /**
     * 模板方法 - 定义查询客户信息的统一流程（final防止覆盖）
     */
    public final void searchCustomer(String keyword) {
        // 步骤1：对查询关键词进行检查与处理
        String processedKeyword = preprocessKeyword(keyword);

        // 步骤2：根据指定条件查询（可变 - 通过桥接委托给QueryStrategy）
        String result = doQuery(processedKeyword);

        // 步骤3：显示查询结果（可变 - 通过桥接委托给DisplayStyle）
        doDisplay(result);
    }

    /**
     * 步骤1：关键词预处理（所有查询相同的固定步骤）
     */
    private String preprocessKeyword(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            throw new IllegalArgumentException("查询关键词不能为空！");
        }
        String processed = keyword.trim();
        System.out.println("  [预处理] 关键词已处理: \"" + keyword + "\" → \"" + processed + "\"");
        return processed;
    }

    /**
     * 步骤2：执行查询（委托给桥接的QueryStrategy）
     */
    protected String doQuery(String keyword) {
        System.out.println("  [查询中] 正在执行查询...");
        return queryStrategy.query(keyword);
    }

    /**
     * 步骤3：显示结果（委托给桥接的DisplayStyle）
     */
    protected void doDisplay(String result) {
        displayStyle.display(result);
    }
}
