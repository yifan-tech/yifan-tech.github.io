/**
 * 【题60】模板方法模式 + 桥接模式联用 - 客户信息查询系统
 *
 * 类图结构：
 * ┌─────────────────────────────────────────────────────────────────┐
 * │              模板方法模式（Template Method）                      │
 * │                                                                  │
 * │  CustomerQuery (abstract)  ← 抽象类（模板方法定义者）             │
 * │  ┌───────────────────────────────────────────────────────────┐  │
 * │  │ # queryStrategy: QueryStrategy   ← 桥接                    │  │
 * │  │ # displayStyle: DisplayStyle     ← 桥接                    │  │
 * │  │ + searchCustomer(keyword): void {final} ← 模板方法          │  │
 * │  │ - preprocessKeyword(): String    ← 固定步骤1                │  │
 * │  │ # doQuery(): String              ← 可变步骤2（委托桥接）    │  │
 * │  │ # doDisplay(): void              ← 可变步骤3（委托桥接）    │  │
 * │  └───────────────────────────────────────────────────────────┘  │
 * │                              △                                   │
 * │                              │                                   │
 * │                    CustomerQueryImpl                             │
 * └─────────────────────────────────────────────────────────────────┘
 *
 * ┌────────────────────── 桥接模式（Bridge） ─────────────────────────┐
 * │                                                                    │
 * │  <<interface>>                    <<interface>>                   │
 * │  QueryStrategy                    DisplayStyle                     │
 * │  + query(keyword): String         + display(result): void          │
 * │       △                                △                          │
 * │   ┌───┼───┐                      ┌─────┼─────┐                    │
 * │   │   │   │                      │           │                    │
 * │ Query  Query Query              Full        Simple                │
 * │ ByName ById ByCompany          Display     Display                │
 * │ (按姓名)(按编号)(按单位)        (完整模式)  (精简模式)             │
 * └────────────────────────────────────────────────────────────────────┘
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════");
        System.out.println("  模板方法+桥接模式 - 客户信息查询系统");
        System.out.println("══════════════════════════════════════════════\n");

        CustomerQuery query = new CustomerQueryImpl();

        // 场景1：按姓名查询 + 完整显示模式
        System.out.println("--- 场景1：按姓名查询（完整模式）---");
        query.setQueryStrategy(new QueryByName());
        query.setDisplayStyle(new FullDisplay());
        query.searchCustomer("  张三  ");

        System.out.println();

        // 场景2：按编号查询 + 精简显示模式
        System.out.println("--- 场景2：按客户编号查询（精简模式）---");
        query.setQueryStrategy(new QueryById());
        query.setDisplayStyle(new SimpleDisplay());
        query.searchCustomer("C002");

        System.out.println();

        // 场景3：按单位查询 + 完整显示模式
        System.out.println("--- 场景3：按单位名称查询（完整模式）---");
        query.setQueryStrategy(new QueryByCompany());
        query.setDisplayStyle(new FullDisplay());
        query.searchCustomer("  创新科技  ");

        System.out.println();

        // 场景4：演示关键词为空的情况
        System.out.println("--- 场景4：关键词为空测试 ---");
        try {
            query.searchCustomer("   ");
        } catch (IllegalArgumentException e) {
            System.out.println("  [错误] " + e.getMessage());
        }

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  联用模式总结：");
        System.out.println("  - 模板方法模式：统一查询流程（预处理→查询→显示）");
        System.out.println("  - 桥接模式：查询策略与显示样式独立变化，可任意组合");
        System.out.println("  - 两者联用使系统在流程和维度上都具备良好扩展性");
        System.out.println("══════════════════════════════════════════════");
    }
}
