/**
 * 显示样式接口（桥接模式 - 实现化角色）
 * 定义如何显示查询结果
 */
public interface DisplayStyle {
    /**
     * 显示查询结果
     */
    void display(String result);
}
