/**
 * 具体查询业务类
 */
public class CustomerQueryImpl extends CustomerQuery {
    // 继承模板方法和桥接引用，无需额外代码
    // 如有特殊逻辑可在此扩展
}
