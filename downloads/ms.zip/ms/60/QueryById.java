/**
 * 按客户编号查询（桥接 - 具体实现化角色）
 */
public class QueryById implements QueryStrategy {
    @Override
    public String query(String keyword) {
        // 模拟数据库查询
        return "客户编号：" + keyword + " | 姓名：张三 | 单位：创新科技 | 电话：139****5678";
    }
}
