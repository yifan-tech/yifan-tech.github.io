/**
 * 完整模式显示（桥接 - 具体实现化角色）
 */
public class FullDisplay implements DisplayStyle {
    @Override
    public void display(String result) {
        System.out.println("  ┌─────────────────────────────────────────────┐");
        System.out.println("  │  客户信息查询结果（完整模式）                  │");
        System.out.println("  ├─────────────────────────────────────────────┤");
        String[] parts = result.split("\\|");
        for (String part : parts) {
            System.out.println("  │  " + part.trim());
        }
        System.out.println("  └─────────────────────────────────────────────┘");
    }
}
