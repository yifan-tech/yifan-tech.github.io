/**
 * CarFactory 抽象工厂类 (Creator)
 * 定义工厂方法 createCar()，由子类实现具体汽车的创建
 */
public abstract class CarFactory {

    /**
     * 工厂方法 —— 创建一辆汽车
     * @param model 汽车型号
     * @return Car 产品对象
     */
    public Car orderCar(String model) {
        Car car = createCar();
        car.setModel(model);

        // 调用工厂自身的通用制造流程
        System.out.println("[" + this.getClass().getSimpleName() + "] 接到订单: " + model);
        car.produce();    // 各品牌自有制造流程
        testDrive(car);   // 通用出厂检测
        car.display();    // 展示车辆信息

        return car;
    }

    /** 抽象工厂方法 —— 具体子类实现，创建对应品牌的汽车 */
    protected abstract Car createCar();

    /** 通用出厂试车流程 */
    private void testDrive(Car car) {
        System.out.println("    >>> 出厂试车: 制动检测 OK | 灯光检测 OK | 尾气检测 OK");
    }
}
