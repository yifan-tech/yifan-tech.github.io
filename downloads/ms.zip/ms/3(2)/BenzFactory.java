/**
 * BenzFactory 具体工厂类 —— 奔驰工厂
 * 实现 createCar() 工厂方法，专门生产 Benz 汽车
 */
public class BenzFactory extends CarFactory {

    @Override
    protected Car createCar() {
        System.out.println("  [Benz工厂] 启动奔驰专属生产线...");
        return new Benz();
    }
}
