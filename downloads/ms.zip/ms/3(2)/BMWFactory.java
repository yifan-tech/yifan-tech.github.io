/**
 * BMWFactory 具体工厂类 —— 宝马工厂
 * 实现 createCar() 工厂方法，专门生产 BMW 汽车
 */
public class BMWFactory extends CarFactory {

    @Override
    protected Car createCar() {
        System.out.println("  [BMW工厂] 启动宝马专属生产线...");
        return new BMW();
    }
}
