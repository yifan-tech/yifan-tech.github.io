/**
 * BMW 具体产品类 —— 宝马汽车
 */
public class BMW extends Car {

    public BMW() {
        super("BMW");
    }

    @Override
    public void produce() {
        System.out.println(">>> BMW工厂: 使用德国精密生产线制造宝马 " + model + " ...");
        System.out.println("    [步骤1] 冲压车身部件");
        System.out.println("    [步骤2] 焊接白车身");
        System.out.println("    [步骤3] 喷涂经典BMW蓝白车漆");
        System.out.println("    [步骤4] 组装双肾格栅 + 天使眼大灯");
        System.out.println("    [步骤5] 安装B系列发动机 + xDrive系统");
    }

    @Override
    public void display() {
        System.out.println("\n  ========== 出厂车辆信息 ==========");
        System.out.println("  |  品牌: " + brand);
        System.out.println("  |  型号: " + model);
        System.out.println("  |  产地: 德国 慕尼黑");
        System.out.println("  |  特性: 操控精准, 驾驶乐趣, 豪华运动");
        System.out.println("  ===================================\n");
    }
}
