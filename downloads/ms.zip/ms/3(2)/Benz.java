/**
 * Benz 具体产品类 —— 奔驰汽车
 */
public class Benz extends Car {

    public Benz() {
        super("Mercedes-Benz");
    }

    @Override
    public void produce() {
        System.out.println(">>> Benz工厂: 使用德国高端生产线制造奔驰 " + model + " ...");
        System.out.println("    [步骤1] 冲压车身部件");
        System.out.println("    [步骤2] 激光焊接白车身");
        System.out.println("    [步骤3] 喷涂经典Benz银色车漆");
        System.out.println("    [步骤4] 组装三叉星徽标 + LED大灯");
        System.out.println("    [步骤5] 安装V系列发动机 + 4MATIC系统");
    }

    @Override
    public void display() {
        System.out.println("\n  ========== 出厂车辆信息 ==========");
        System.out.println("  |  品牌: " + brand);
        System.out.println("  |  型号: " + model);
        System.out.println("  |  产地: 德国 斯图加特");
        System.out.println("  |  特性: 豪华舒适, 安全可靠, 经典优雅");
        System.out.println("  ===================================\n");
    }
}
