/**
 * Car 抽象产品类
 * 所有汽车品牌均继承此类，提供汽车的公共属性和抽象行为
 */
public abstract class Car {
    protected String brand;    // 品牌
    protected String model;    // 型号

    public Car(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        this.model = model;
    }

    /** 制造汽车 */
    public abstract void produce();

    /** 展示汽车信息 */
    public abstract void display();
}
