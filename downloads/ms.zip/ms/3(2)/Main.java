/**
 * Main 测试类 - 模拟 BMW/Benz 工厂使用工厂方法模式造车
 *
 * ============================ 类图 ============================
 *
 *       ┌──────────────────────┐
 *       │    CarFactory        │  (抽象 Creator)
 *       ├──────────────────────┤
 *       │ + orderCar(model)    │──────────────┐
 *       │ # createCar(): Car   │              │ 依赖
 *       │ - testDrive(car)     │              │
 *       └──────────┬───────────┘              │
 *                  │                          ▼
 *        ┌─────────┴─────────┐       ┌─────────────────┐
 *        │                   │       │      Car        │  (抽象 Product)
 *   ┌───────────┐    ┌─────────────┐ ├─────────────────┤
 *   │BMWFactory │    │ BenzFactory │ │ # brand          │
 *   ├───────────┤    ├─────────────┤ │ # model          │
 *   │+createCar │    │ +createCar  │ ├─────────────────┤
 *   │  () : Car │    │  () : Car   │ │ + produce()      │
 *   └─────┬─────┘    └──────┬──────┘ │ + display()      │
 *         │                 │        └────────┬─────────┘
 *         │  创建             │  创建          │
 *         ▼                 ▼        ┌───────┴────────┐
 *    ┌─────────┐      ┌──────────┐   │                │
 *    │   BMW   │      │   Benz   │   ▼                ▼
 *    ├─────────┤      ├──────────┤ ┌──────┐   ┌──────────┐
 *    │+produce │      │ +produce │ │ BMW  │   │  Benz    │
 *    │+display │      │ +display │ └──────┘   └──────────┘
 *    └─────────┘      └──────────┘
 *
 * =============================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("========== 工厂方法模式 - 汽车制造模拟 ==========\n");

        // 1. 创建宝马工厂，下单制造 BMW X5
        CarFactory bmwFactory = new BMWFactory();
        bmwFactory.orderCar("X5");

        System.out.println("---------------------------------------------\n");

        // 2. 创建奔驰工厂，下单制造 Benz S500
        CarFactory benzFactory = new BenzFactory();
        benzFactory.orderCar("S500");

        System.out.println("---------------------------------------------\n");

        // 3. 宝马工厂再生产一辆 BMW 3系
        bmwFactory.orderCar("320Li");

        System.out.println("\n========== 所有订单制造完成 ==========");
    }
}
