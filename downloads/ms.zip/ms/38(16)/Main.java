/** 题38 - 命令接口 */
interface Command { void execute(); void undo(); }

/** 电灯 */
class Light {
    public void on() { System.out.println("  [电灯] 亮起"); }
    public void off() { System.out.println("  [电灯] 熄灭"); }
}
/** 电风扇 */
class Fan {
    public void start() { System.out.println("  [电风扇] 开始转动"); }
    public void stop() { System.out.println("  [电风扇] 停止转动"); }
}

/** 具体命令 */
class LightOnCommand implements Command {
    private Light l; public LightOnCommand(Light l) { this.l = l; }
    @Override public void execute() { l.on(); }
    @Override public void undo() { l.off(); }
}
class FanStartCommand implements Command {
    private Fan f; public FanStartCommand(Fan f) { this.f = f; }
    @Override public void execute() { f.start(); }
    @Override public void undo() { f.stop(); }
}

/** 题38 - 开关(调用者) */
public class Main {
    private Command cmd;
    public void setCommand(Command c) { this.cmd = c; }
    public void pressOn() { cmd.execute(); }
    public void pressOff() { cmd.undo(); }

    public static void main(String[] args) {
        System.out.println("===== 房间开关 - 命令模式 =====\n");
        Main sw = new Main();
        sw.setCommand(new LightOnCommand(new Light()));
        sw.pressOn(); sw.pressOff();
        sw.setCommand(new FanStartCommand(new Fan()));
        sw.pressOn(); sw.pressOff();
    }
}
