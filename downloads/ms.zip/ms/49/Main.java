/** 题49 - 中介者: 温度转换器 */
interface Mediator { void tempChanged(String source, double celsius); }

class FahrenheitDisplay {
    private Mediator m; public FahrenheitDisplay(Mediator m) { this.m = m; }
    public void setTemp(double c) { double f = c * 9 / 5 + 32; System.out.println("  [华氏] " + String.format("%.1f", f) + "F"); }
}
class CelsiusDisplay {
    private Mediator m;
    public CelsiusDisplay(Mediator m) { this.m = m; }
    public void raise() { System.out.print("  [摄氏] 点击升高:"); m.tempChanged("CelsiusRaise", 0); }
    public void lower() { System.out.print("  [摄氏] 点击降低:"); m.tempChanged("CelsiusLower", 0); }
    public void setText(double c) { System.out.println("  [摄氏] 显示 " + c + "C"); }
}

/** 题49 - 温度转换器中介者 */
public class Main implements Mediator {
    private double currentTemp = 25.0;
    private FahrenheitDisplay fDisplay = new FahrenheitDisplay(this);
    private CelsiusDisplay cDisplay = new CelsiusDisplay(this);

    @Override public void tempChanged(String source, double v) {
        if (source.equals("CelsiusRaise")) currentTemp += 1;
        else if (source.equals("CelsiusLower")) currentTemp -= 1;
        cDisplay.setText(currentTemp);
        fDisplay.setTemp(currentTemp);
    }

    public static void main(String[] args) {
        System.out.println("===== 温度转换器 - 中介者模式 =====\n");
        Main app = new Main();
        app.cDisplay.setText(app.currentTemp);
        app.fDisplay.setTemp(app.currentTemp);
        app.cDisplay.raise();
        app.cDisplay.lower();
    }
}
