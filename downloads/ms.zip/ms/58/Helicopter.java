/**
 * 直升机 - 亚音速 + 垂直起飞
 */
public class Helicopter extends AirPlane {
    public Helicopter() {
        super("直升机");
        flyBehavior = new SubSonicFly();
        takeOffBehavior = new VerticalTakeOff();
    }

    @Override
    public void display() {
        System.out.println("【直升机】旋翼机型，灵活机动，适合低空作业");
    }
}
