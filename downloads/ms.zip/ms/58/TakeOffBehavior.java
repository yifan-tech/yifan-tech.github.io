/**
 * 起飞特征策略接口
 */
public interface TakeOffBehavior {
    void takeOff();
}
