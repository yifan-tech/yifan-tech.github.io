/**
 * 歼击机 - 超音速 + 长距离起飞
 */
public class Fighter extends AirPlane {
    public Fighter() {
        super("歼击机");
        flyBehavior = new SuperSonicFly();
        takeOffBehavior = new LongDistanceTakeOff();
    }

    @Override
    public void display() {
        System.out.println("【歼击机】超音速战斗机，高机动性，适合空战与拦截");
    }
}
