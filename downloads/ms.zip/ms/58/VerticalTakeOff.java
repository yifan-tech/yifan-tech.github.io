/**
 * 垂直起飞策略
 */
public class VerticalTakeOff implements TakeOffBehavior {
    @Override
    public void takeOff() {
        System.out.println("【垂直起飞】发动机喷口向下，垂直升空...");
    }
}
