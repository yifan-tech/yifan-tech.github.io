/**
 * 长距离起飞策略
 */
public class LongDistanceTakeOff implements TakeOffBehavior {
    @Override
    public void takeOff() {
        System.out.println("【长距离起飞】在跑道上加速滑行，达到V2速度后抬轮起飞...");
    }
}
