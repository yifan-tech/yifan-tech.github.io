/**
 * 飞行特征策略接口
 */
public interface FlyBehavior {
    void fly();
}
