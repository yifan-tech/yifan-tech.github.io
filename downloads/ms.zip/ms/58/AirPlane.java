/**
 * 飞机抽象类 - 持有机动策略
 */
public abstract class AirPlane {
    protected String name;
    protected FlyBehavior flyBehavior;
    protected TakeOffBehavior takeOffBehavior;

    public AirPlane(String name) {
        this.name = name;
    }

    public void setFlyBehavior(FlyBehavior fb) {
        this.flyBehavior = fb;
        System.out.println("  [" + name + "] 更换了飞行模式");
    }

    public void setTakeOffBehavior(TakeOffBehavior tb) {
        this.takeOffBehavior = tb;
        System.out.println("  [" + name + "] 更换了起飞模式");
    }

    public void performFly() {
        System.out.print("  " + name + "：");
        flyBehavior.fly();
    }

    public void performTakeOff() {
        System.out.print("  " + name + "：");
        takeOffBehavior.takeOff();
    }

    public abstract void display();
}
