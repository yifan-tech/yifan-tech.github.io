/**
 * 亚音速飞行策略
 */
public class SubSonicFly implements FlyBehavior {
    @Override
    public void fly() {
        System.out.println("【亚音速飞行】以0.8马赫的速度巡航飞行...");
    }
}
