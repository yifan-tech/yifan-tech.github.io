/**
 * 超音速飞行策略
 */
public class SuperSonicFly implements FlyBehavior {
    @Override
    public void fly() {
        System.out.println("【超音速飞行】以2.5马赫的速度突破音障飞行...");
    }
}
