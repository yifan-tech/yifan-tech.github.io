/**
 * 【题58】策略模式 - 飞机模拟系统
 *
 * 类图结构：
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │                        <<interface>>                                │
 * │                       FlyBehavior                                   │
 * │                   + fly(): void                                     │
 * └──────────────────────────┬──────────────────────────────────────────┘
 *                            │
 *              ┌─────────────┼─────────────┐
 *              │             │             │
 *     ┌────────┴────────┐ ┌──┴──────────┐ (可扩展更多飞行策略)
 *     │  SubSonicFly    │ │SuperSonicFly│
 *     │ + fly() 亚音速   │ │ + fly() 超音速│
 *     └─────────────────┘ └─────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │                        <<interface>>                                │
 * │                      TakeOffBehavior                                │
 * │                   + takeOff(): void                                 │
 * └──────────────────────────┬──────────────────────────────────────────┘
 *                            │
 *              ┌─────────────┼─────────────┐
 *              │             │             │
 *   ┌──────────┴──────────┐ ┌┴─────────────┴────────┐
 *   │  VerticalTakeOff    │ │  LongDistanceTakeOff   │
 *   │ + takeOff() 垂直起飞 │ │ + takeOff() 长距离起飞  │
 *   └─────────────────────┘ └────────────────────────┘
 *
 * ┌─────────────────────────────────────────────────────────────────────┐
 * │                          AirPlane (abstract)                        │
 * │  # name: String                                                     │
 * │  # flyBehavior: FlyBehavior                                        │
 * │  # takeOffBehavior: TakeOffBehavior                                │
 * │  + setFlyBehavior(FlyBehavior)                                     │
 * │  + setTakeOffBehavior(TakeOffBehavior)                             │
 * │  + performFly()                                                    │
 * │  + performTakeOff()                                                │
 * │  + display(): void  {abstract}                                     │
 * └──────────┬──────────────┬───────────────┬───────────────┬───────────┘
 *            │              │               │               │
 *   ┌────────┴────────┐ ┌──┴──────────┐ ┌──┴──────┐ ┌──────┴──────┐
 *   │  Helicopter     │ │AirPlane     │ │Fighter  │ │  Harrier    │
 *   │  直升机          │ │Simulator    │ │ 歼击机   │ │ 鹞式战斗机   │
 *   │  亚音速+垂直起飞 │ │  客机        │ │超音速+  │ │超音速+      │
 *   │                 │ │  亚音速+     │ │长距离起飞│ │垂直起飞     │
 *   │                 │ │  长距离起飞   │ │         │ │            │
 *   └─────────────────┘ └─────────────┘ └─────────┘ └─────────────┘
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════");
        System.out.println("  策略模式 - 飞机模拟系统");
        System.out.println("══════════════════════════════════════════════\n");

        System.out.println("--- 创建各种飞机 ---\n");

        AirPlane helicopter = new Helicopter();
        helicopter.display();
        helicopter.performTakeOff();
        helicopter.performFly();

        System.out.println();

        AirPlane airliner = new AirPlaneSimulator();
        airliner.display();
        airliner.performTakeOff();
        airliner.performFly();

        System.out.println();

        AirPlane fighter = new Fighter();
        fighter.display();
        fighter.performTakeOff();
        fighter.performFly();

        System.out.println();

        AirPlane harrier = new Harrier();
        harrier.display();
        harrier.performTakeOff();
        harrier.performFly();

        System.out.println("\n--- 动态切换策略（策略模式核心优势）---\n");

        System.out.println("[场景] 直升机需要执行紧急长途任务，切换为超音速+长距离起飞：");
        helicopter.setFlyBehavior(new SuperSonicFly());
        helicopter.setTakeOffBehavior(new LongDistanceTakeOff());
        helicopter.performTakeOff();
        helicopter.performFly();

        System.out.println("\n[场景] 客机需要在短跑道机场起降，切换为垂直起飞：");
        airliner.setTakeOffBehavior(new VerticalTakeOff());
        airliner.performTakeOff();
        airliner.performFly();

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  策略模式总结：将飞行/起飞算法封装为独立策略类，");
        System.out.println("  飞机可在运行时动态切换策略，易于扩展新机型和新策略。");
        System.out.println("══════════════════════════════════════════════");
    }
}
