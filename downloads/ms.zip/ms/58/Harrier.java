/**
 * 鹞式战斗机 - 超音速 + 垂直起飞
 */
public class Harrier extends AirPlane {
    public Harrier() {
        super("鹞式战斗机");
        flyBehavior = new SuperSonicFly();
        takeOffBehavior = new VerticalTakeOff();
    }

    @Override
    public void display() {
        System.out.println("【鹞式战斗机】垂直/短距起降战斗机，超音速，适合舰载作战");
    }
}
