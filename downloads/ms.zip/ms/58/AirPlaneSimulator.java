/**
 * 客机 - 亚音速 + 长距离起飞
 */
public class AirPlaneSimulator extends AirPlane {
    public AirPlaneSimulator() {
        super("客机");
        flyBehavior = new SubSonicFly();
        takeOffBehavior = new LongDistanceTakeOff();
    }

    @Override
    public void display() {
        System.out.println("【客机】大型喷气式客机，经济巡航，适合民航运输");
    }
}
