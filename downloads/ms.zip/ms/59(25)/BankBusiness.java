/**
 * 银行业务模板抽象类 - 模板方法模式
 */
public abstract class BankBusiness {
    /**
     * 模板方法 - 定义银行业务办理流程（final防止子类覆盖）
     */
    public final void process() {
        takeNumber();       // 第1步：取号排队
        transact();         // 第2步：办理具体业务（钩子方法）
        evaluate();         // 第3步：对工作人员评分
    }

    // 步骤1：取号排队（所有业务相同）
    private void takeNumber() {
        System.out.println("  [1] 取号排队：请取号，等待叫号...");
        try {
            Thread.sleep(500); // 模拟等待
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("  [1] 轮到您了，请到窗口办理业务");
    }

    // 步骤2：办理具体业务（抽象方法，子类实现）
    protected abstract void transact();

    // 步骤3：对工作人员评分（钩子方法，子类可选择覆盖）
    protected void evaluate() {
        System.out.println("  [3] 评分：请对本次服务评分（默认5星好评）★ ★ ★ ★ ★");
    }
}
