/**
 * 转账业务
 */
public class TransferBusiness extends BankBusiness {
    private String targetAccount;
    private double amount;

    public TransferBusiness(String targetAccount, double amount) {
        this.targetAccount = targetAccount;
        this.amount = amount;
    }

    @Override
    protected void transact() {
        System.out.println("  [2] 转账业务：正在向账户 " + targetAccount + " 转账 " + amount + " 元...");
        System.out.println("  [2] 请确认收款方信息，转账成功！");
    }

    @Override
    protected void evaluate() {
        System.out.println("  [3] 评分：转账办理迅速，给予4星好评 ★ ★ ★ ★ ☆");
    }
}
