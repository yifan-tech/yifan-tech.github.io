/**
 * 取款业务
 */
public class WithdrawBusiness extends BankBusiness {
    private double amount;

    public WithdrawBusiness(double amount) {
        this.amount = amount;
    }

    @Override
    protected void transact() {
        System.out.println("  [2] 取款业务：正在为您办理取款 " + amount + " 元...");
        System.out.println("  [2] 请确认金额并输入密码，取款成功！");
    }

    @Override
    protected void evaluate() {
        System.out.println("  [3] 评分：服务态度很好，给予5星好评 ★ ★ ★ ★ ★");
    }
}
