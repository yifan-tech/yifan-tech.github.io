/**
 * 【题59】模板方法模式 - 银行业务办理流程
 *
 * 类图结构：
 * ┌─────────────────────────────────────────────────────────────────┐
 * │                    BankBusiness (abstract)                       │
 * │                                                                  │
 * │  + process(): void  {final}  ← 模板方法，定义算法骨架            │
 * │  - takeNumber(): void         ← 取号排队（固定步骤）              │
 * │  # transact(): void {abstract}← 办理具体业务（可变步骤）          │
 * │  # evaluate(): void           ← 评分（钩子方法，可覆盖）          │
 * └──────────┬──────────────────┬───────────────────┬────────────────┘
 *            │                  │                   │
 *   ┌────────┴────────┐ ┌──────┴───────┐ ┌─────────┴─────────┐
 *   │ WithdrawBusiness│ │DepositBusiness│ │TransferBusiness   │
 *   │   取款业务       │ │  存款业务      │ │  转账业务         │
 *   │ - amount: double│ │ - amount      │ │ - targetAccount   │
 *   │ + transact()    │ │ + transact()  │ │ - amount          │
 *   │ + evaluate()    │ │               │ │ + transact()      │
 *   └─────────────────┘ └───────────────┘ │ + evaluate()      │
 *                                         └───────────────────┘
 *
 * 流程：process() → takeNumber() → transact() → evaluate()
 *       (模板固定)  (所有相同)     (子类实现)   (可选的钩子)
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("══════════════════════════════════════════════");
        System.out.println("  模板方法模式 - 银行业务办理流程");
        System.out.println("══════════════════════════════════════════════\n");

        System.out.println(">>> 客户A - 办理取款业务（5000元）");
        BankBusiness b1 = new WithdrawBusiness(5000);
        b1.process();

        System.out.println("\n>>> 客户B - 办理存款业务（10000元）");
        BankBusiness b2 = new DepositBusiness(10000);
        b2.process();

        System.out.println("\n>>> 客户C - 办理转账业务（向6222****8888转账3000元）");
        BankBusiness b3 = new TransferBusiness("6222****8888", 3000);
        b3.process();

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  模板方法模式总结：");
        System.out.println("  - 父类定义算法骨架(process)，子类实现具体步骤(transact)");
        System.out.println("  - 钩子方法(evaluate)允许子类选择性覆盖");
        System.out.println("  - 流程统一，步骤可变，符合开闭原则");
        System.out.println("══════════════════════════════════════════════");
    }
}
