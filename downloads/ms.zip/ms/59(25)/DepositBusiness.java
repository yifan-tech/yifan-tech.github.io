/**
 * 存款业务
 */
public class DepositBusiness extends BankBusiness {
    private double amount;

    public DepositBusiness(double amount) {
        this.amount = amount;
    }

    @Override
    protected void transact() {
        System.out.println("  [2] 存款业务：正在为您办理存款 " + amount + " 元...");
        System.out.println("  [2] 请将现金交给柜员，存款成功！");
    }
}
