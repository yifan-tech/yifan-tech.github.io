/** 题55 - 状态接口 */
interface LevelState {
    void play(Role role);
    void win(Role role);
    void lose(Role role);
}

/** 入门级 */
class PrimaryState implements LevelState {
    @Override public void play(Role r) { System.out.println("  [入门] 进行基本游戏..."); }
    @Override public void win(Role r) { r.score += 10; r.checkState(); System.out.println("  [入门] 胜利 +10分 | 积分: " + r.score); }
    @Override public void lose(Role r) { r.score -= 5; r.checkState(); System.out.println("  [入门] 失败 -5分 | 积分: " + r.score); }
}
/** 熟练级 */
class SecondaryState implements LevelState {
    @Override public void play(Role r) { System.out.println("  [熟练] 进行游戏(积分加倍)..."); }
    @Override public void win(Role r) { r.score += 20; r.checkState(); System.out.println("  [熟练] 胜利 +20分(双倍!) | 积分: " + r.score); }
    @Override public void lose(Role r) { r.score -= 10; r.checkState(); System.out.println("  [熟练] 失败 -10分 | 积分: " + r.score); }
    public void doubleScore() { System.out.println("  [熟练] 使用积分加倍功能"); }
}
/** 高手级 */
class ProfessionalState implements LevelState {
    @Override public void play(Role r) { System.out.println("  [高手] 进行游戏(含换牌功能)..."); }
    @Override public void win(Role r) { r.score += 20; r.checkState(); System.out.println("  [高手] 胜利 +20分 | 积分: " + r.score); }
    @Override public void lose(Role r) { r.score -= 10; r.checkState(); System.out.println("  [高手] 失败 -10分 | 积分: " + r.score); }
    public void changeCards() { System.out.println("  [高手] 使用换牌功能"); }
}
/** 骨灰级 */
class FinalState implements LevelState {
    @Override public void play(Role r) { System.out.println("  [骨灰] 进行游戏(含偷看牌功能)..."); }
    @Override public void win(Role r) { r.score += 20; r.checkState(); System.out.println("  [骨灰] 胜利 +20分 | 积分: " + r.score); }
    @Override public void lose(Role r) { r.score -= 10; r.checkState(); System.out.println("  [骨灰] 失败 -10分 | 积分: " + r.score); }
    public void peekCards() { System.out.println("  [骨灰] 使用偷看他人牌功能"); }
}

/** 角色 */
class Role {
    int score = 0; LevelState state = new PrimaryState();
    void checkState() {
        if (score >= 200) state = new FinalState();
        else if (score >= 100) state = new ProfessionalState();
        else if (score >= 50) state = new SecondaryState();
        else state = new PrimaryState();
    }
}

/** 题55 主测试 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 纸牌游戏等级 - 状态模式 =====\n");
        Role r = new Role();
        r.state.play(r); r.state.win(r); r.state.win(r);
        // 升到熟练级
        for (int i = 0; i < 4; i++) r.state.win(r);
        r.state.play(r);
        // 高手级
        for (int i = 0; i < 5; i++) r.state.win(r);
        ((ProfessionalState)r.state).changeCards();
    }
}
