/**
 * InterfaceController 抽象产品 —— 游戏界面控制
 */
public abstract class InterfaceController {

    protected String platform;

    public InterfaceController(String platform) {
        this.platform = platform;
    }

    /** 初始化界面 */
    public abstract void initUI();

    /** 渲染界面 */
    public abstract void render();
}
