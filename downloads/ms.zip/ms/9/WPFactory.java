/**
 * WPFactory 具体工厂 —— Windows Phone平台产品族
 */
public class WPFactory extends GameFactory {

    @Override
    public OperationController createOperationController() {
        return new WPOperationController();
    }

    @Override
    public InterfaceController createInterfaceController() {
        return new WPInterfaceController();
    }
}
