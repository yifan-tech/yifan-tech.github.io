/**
 * WPOperationController 具体产品 —— Windows Phone操作控制
 */
public class WPOperationController extends OperationController {

    public WPOperationController() {
        super("Windows Phone");
    }

    @Override
    public void init() {
        System.out.println("  [WP] 初始化操作控制器...");
        System.out.println("    -> 注册 Manipulation 事件处理器");
        System.out.println("    -> 支持: 点击 | 滑动 | 捏合缩放");
    }

    @Override
    public void handleInput() {
        System.out.println("  [WP] 处理用户输入 -> ManipulationDelta + 磁贴反馈");
    }
}
