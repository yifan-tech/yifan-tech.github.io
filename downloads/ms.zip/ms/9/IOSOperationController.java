/**
 * IOSOperationController 具体产品 —— iOS操作控制
 */
public class IOSOperationController extends OperationController {

    public IOSOperationController() {
        super("iOS");
    }

    @Override
    public void init() {
        System.out.println("  [iOS] 初始化操作控制器...");
        System.out.println("    -> 注册 UITouch 手势识别器");
        System.out.println("    -> 支持: 点击 | 滑动 | 捏合 | 3D Touch");
    }

    @Override
    public void handleInput() {
        System.out.println("  [iOS] 处理用户输入 -> 多点触控 + Taptic Engine震动反馈");
    }
}
