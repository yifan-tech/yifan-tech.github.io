/**
 * AndroidInterfaceController 具体产品 —— Android界面控制
 */
public class AndroidInterfaceController extends InterfaceController {

    public AndroidInterfaceController() {
        super("Android");
    }

    @Override
    public void initUI() {
        System.out.println("  [Android] 初始化游戏界面...");
        System.out.println("    -> 使用 SurfaceView + OpenGL ES 渲染引擎");
        System.out.println("    -> 适配多种屏幕密度 (mdpi/hdpi/xhdpi/xxhdpi)");
        System.out.println("    -> 支持全面屏 + 挖孔屏 + 折叠屏适配");
    }

    @Override
    public void render() {
        System.out.println("  [Android] 渲染界面 -> OpenGL ES 渲染 + Material Design动效");
    }
}
