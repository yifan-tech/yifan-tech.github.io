/**
 * GameFactory 抽象工厂类
 * 定义一个产品族: OperationController + InterfaceController (同一平台)
 */
public abstract class GameFactory {

    /** 创建游戏操作控制器 */
    public abstract OperationController createOperationController();

    /** 创建游戏界面控制器 */
    public abstract InterfaceController createInterfaceController();
}
