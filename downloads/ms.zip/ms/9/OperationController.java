/**
 * OperationController 抽象产品 —— 游戏操作控制
 */
public abstract class OperationController {

    protected String platform;

    public OperationController(String platform) {
        this.platform = platform;
    }

    /** 初始化操作控制器 */
    public abstract void init();

    /** 处理触摸/按键事件 */
    public abstract void handleInput();
}
