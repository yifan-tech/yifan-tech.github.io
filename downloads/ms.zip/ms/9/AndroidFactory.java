/**
 * AndroidFactory 具体工厂 —— Android平台产品族
 */
public class AndroidFactory extends GameFactory {

    @Override
    public OperationController createOperationController() {
        return new AndroidOperationController();
    }

    @Override
    public InterfaceController createInterfaceController() {
        return new AndroidInterfaceController();
    }
}
