/**
 * IOSInterfaceController 具体产品 —— iOS界面控制
 */
public class IOSInterfaceController extends InterfaceController {

    public IOSInterfaceController() {
        super("iOS");
    }

    @Override
    public void initUI() {
        System.out.println("  [iOS] 初始化游戏界面...");
        System.out.println("    -> 使用 UIKit + Metal 渲染引擎");
        System.out.println("    -> 适配 iPhone X/XS/11/12/13/14 刘海屏");
        System.out.println("    -> 支持 Safe Area 安全区域布局");
    }

    @Override
    public void render() {
        System.out.println("  [iOS] 渲染界面 -> 60fps Metal渲染 + Core Animation动画");
    }
}
