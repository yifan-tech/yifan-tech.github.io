/**
 * AndroidOperationController 具体产品 —— Android操作控制
 */
public class AndroidOperationController extends OperationController {

    public AndroidOperationController() {
        super("Android");
    }

    @Override
    public void init() {
        System.out.println("  [Android] 初始化操作控制器...");
        System.out.println("    -> 注册 MotionEvent 触摸监听器");
        System.out.println("    -> 支持: 点击 | 滑动 | 多点触控 | 手柄外设");
    }

    @Override
    public void handleInput() {
        System.out.println("  [Android] 处理用户输入 -> GestureDetector + HapticFeedback");
    }
}
