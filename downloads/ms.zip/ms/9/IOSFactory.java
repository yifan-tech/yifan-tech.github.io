/**
 * IOSFactory 具体工厂 —— iOS平台产品族
 */
public class IOSFactory extends GameFactory {

    @Override
    public OperationController createOperationController() {
        return new IOSOperationController();
    }

    @Override
    public InterfaceController createInterfaceController() {
        return new IOSInterfaceController();
    }
}
