/**
 * 题9 测试类 —— 手机游戏 (抽象工厂模式)
 *
 * ============================ 类图 ============================
 *
 *   ┌──────────────────────────────┐
 *   │        GameFactory           │  (抽象工厂)
 *   ├──────────────────────────────┤
 *   │+createOperationController()  │
 *   │+createInterfaceController()  │
 *   └──────────────┬───────────────┘
 *                  │
 *   ┌──────────────┼──────────────────┐
 *   ▼              ▼                  ▼
 * ┌──────────┐ ┌──────────┐ ┌──────────┐
 * │  IOS     │ │ Android  │ │   WP     │
 * │ Factory  │ │ Factory  │ │ Factory  │
 * ├──────────┤ ├──────────┤ ├──────────┤
 * │+create   │ │+create   │ │+create   │
 * │ OpCtrl() │ │ OpCtrl() │ │ OpCtrl() │
 * │+create   │ │+create   │ │+create   │
 * │ IfCtrl() │ │ IfCtrl() │ │ IfCtrl() │
 * └──┬───┬───┘ └──┬───┬───┘ └──┬───┬───┘
 *    │   │        │   │        │   │
 *    ▼   ▼        ▼   ▼        ▼   ▼
 * ┌──────┐┌──────┐ (iOS/Android/WP 各一组 Operation + Interface)
 * │IOS   ││IOS   │
 * │OpCtrl││IfCtrl│
 * └──┬───┘└──┬───┘
 *    │       │
 *    ▼       ▼
 * ┌──────────┐┌──────────────┐
 * │Operation ││  Interface   │
 * │Controller││ Controller   │  (抽象产品)
 * └──────────┘└──────────────┘
 * =============================================================
 */
public class Main {

    /** 在指定平台上运行游戏 */
    private static void runOnPlatform(GameFactory factory) {
        OperationController opCtrl = factory.createOperationController();
        InterfaceController ifCtrl = factory.createInterfaceController();

        opCtrl.init();
        ifCtrl.initUI();
        opCtrl.handleInput();
        ifCtrl.render();
        System.out.println();
    }

    public static void main(String[] args) {
        System.out.println("===== 手机游戏 - 抽象工厂模式 =====\n");

        // 1. iOS 平台
        System.out.println("--- iOS 平台启动 ---");
        runOnPlatform(new IOSFactory());

        // 2. Android 平台
        System.out.println("--- Android 平台启动 ---");
        runOnPlatform(new AndroidFactory());

        // 3. Windows Phone 平台
        System.out.println("--- Windows Phone 平台启动 ---");
        runOnPlatform(new WPFactory());

        System.out.println("===== 所有平台适配完成 =====");
        System.out.println("\n特点: 切换平台只需更换工厂，操作控制和界面控制自动配套");
        System.out.println("扩展: 新增平台(如HarmonyOS)时，只需新增具体产品和工厂类");
    }
}
