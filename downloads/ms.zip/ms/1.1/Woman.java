/**
 * Woman 类 - 具体产品：女人
 */
public class Woman extends Person {

    public Woman() {
        super("女人");
    }

    @Override
    public void speak() {
        System.out.println("我是女人，声音温柔婉转！");
    }

    @Override
    public void action() {
        System.out.println("女人正在织布缝衣、采集果实...");
    }
}
