/**
 * Person 抽象类 - 产品抽象类
 * 所有由女娲造出的"人"（男人、女人、机器人）都继承此类
 */
public abstract class Person {
    protected String name;
    protected String type;

    public Person(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    /** 每个子类实现自己的说话方式 */
    public abstract void speak();

    /** 每个子类实现自己的行为方式 */
    public abstract void action();
}
