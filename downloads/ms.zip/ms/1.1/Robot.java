/**
 * Robot 类 - 新增的具体产品：机器人
 * 扩展简单工厂模式：只需新增一个具体产品类并在工厂中添加分支即可
 */
public class Robot extends Person {

    public Robot() {
        super("机器人");
    }

    @Override
    public void speak() {
        System.out.println("我是机器人，发出电子合成音：Hello World！");
    }

    @Override
    public void action() {
        System.out.println("机器人正在执行程序指令、处理数据...");
    }
}
