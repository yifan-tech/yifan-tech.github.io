/**
 * Nvwa（女娲）类 - 简单工厂类
 * 
 * 使用简单工厂模式，根据传入的参数不同创建不同类型的 Person 对象。
 * 
 * 【新增 Robot 后的变化说明】：
 * 1. 在 switch/case 中新增了 case "R" 分支，返回 Robot 对象。
 * 2. 工厂类的核心逻辑（createPerson 方法）需要修改以支持新产品。
 * 3. 这是简单工厂模式的缺点之一：增加新产品时需要修改工厂类的判断逻辑，
 *    违反了"开闭原则"（对扩展开放，对修改关闭）。
 * 4. 若希望完全遵循开闭原则，可升级为工厂方法模式或抽象工厂模式。
 */
public class Nvwa {

    /**
     * 静态工厂方法 - 根据类型参数创建对应的 Person 对象
     * 
     * @param type "M" = 男人, "W" = 女人, "R" = 机器人
     * @return Person 对象，类型不匹配返回 null
     */
    public static Person createPerson(String type) {
        if (type == null) {
            return null;
        }

        Person person = null;

        switch (type.toUpperCase()) {
            case "M":
                person = new Man();
                System.out.println("🔥 女娲捏土造人，一个男人诞生了！");
                break;
            case "W":
                person = new Woman();
                System.out.println("🔥 女娲捏土造人，一个女人诞生了！");
                break;
            case "R":
                // ===== 新增：机器人分支 =====
                person = new Robot();
                System.out.println("⚡ 女娲启动制造程序，一个机器人诞生了！");
                break;
            default:
                System.out.println("❌ 参数错误：无法造出类型为 '" + type + "' 的人！");
                break;
        }

        return person;
    }
}
