/**
 * 主测试类 - 模拟女娲造人场景
 * 
 * 输出结果展示简单工厂模式的运行效果：
 * - 传入 "M" 创建 Man
 * - 传入 "W" 创建 Woman
 * - 传入 "R" 创建 Robot（新增）
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("====== 女娲开始造人 ======\n");

        // 1. 造一个男人
        Person man = Nvwa.createPerson("M");
        if (man != null) {
            man.setName("亚当");
            System.out.println("  名称: " + man.getName());
            System.out.print("  说话: ");
            man.speak();
            System.out.print("  行为: ");
            man.action();
        }

        System.out.println("\n------------------------\n");

        // 2. 造一个女人
        Person woman = Nvwa.createPerson("W");
        if (woman != null) {
            woman.setName("夏娃");
            System.out.println("  名称: " + woman.getName());
            System.out.print("  说话: ");
            woman.speak();
            System.out.print("  行为: ");
            woman.action();
        }

        System.out.println("\n------------------------\n");

        // 3. 造一个机器人（新增功能）
        Person robot = Nvwa.createPerson("R");
        if (robot != null) {
            robot.setName("瓦力");
            System.out.println("  名称: " + robot.getName());
            System.out.print("  说话: ");
            robot.speak();
            System.out.print("  行为: ");
            robot.action();
        }

        System.out.println("\n------------------------\n");

        // 4. 尝试传入非法参数
        Person unknown = Nvwa.createPerson("X");

        System.out.println("\n====== 造人结束 ======");
    }
}
