/**
 * Man 类 - 具体产品：男人
 */
public class Man extends Person {

    public Man() {
        super("男人");
    }

    @Override
    public void speak() {
        System.out.println("我是男人，声音低沉有力！");
    }

    @Override
    public void action() {
        System.out.println("男人正在辛勤劳作、建造房屋...");
    }
}
