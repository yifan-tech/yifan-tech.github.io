/**
 * BarChart 具体产品类 —— 柱状图
 */
public class BarChart extends Chart {

    @Override
    public void render() {
        System.out.println("  >> 渲染柱状图: 绘制坐标轴 -> 计算柱宽 -> 绘制各数据柱 -> 填充颜色");
    }

    @Override
    public void export() {
        System.out.println("  >> 导出柱状图: 将柱状图以 PNG 格式保存到磁盘");
    }
}
