/**
 * 题4 测试类 —— 数据统计系统：曲线图/柱状图 (工厂方法模式)
 *
 * ============================ 类图 ============================
 *
 *    ┌───────────────────┐
 *    │   ChartCreator    │  (抽象 Creator)
 *    ├───────────────────┤
 *    │ + generateChart() │──────────────┐
 *    │ # createChart()   │              │ 依赖
 *    └─────────┬─────────┘              ▼
 *              │               ┌─────────────────┐
 *   ┌──────────┴──────────┐    │     Chart       │  (抽象 Product)
 *   │                     │    ├─────────────────┤
 *   ▼                     ▼    │ + render()      │
 * ┌──────────────┐ ┌──────────────┐ + export() │
 * │CurveChart    │ │BarChart      │ └───────┬─────────┘
 * │ Creator      │ │ Creator      │         │
 * ├──────────────┤ ├──────────────┤   ┌─────┴──────┐
 * │+createChart()│ │+createChart()│   ▼            ▼
 * └──────┬───────┘ └──────┬───────┘ ┌──────────┐ ┌──────────┐
 *        │                │         │CurveChart│ │ BarChart │
 *        ▼                ▼         └──────────┘ └──────────┘
 *   ┌──────────┐    ┌──────────┐
 *   │CurveChart│    │ BarChart │
 *   └──────────┘    └──────────┘
 * =============================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== 数据统计系统 - 工厂方法模式 =====\n");

        // 1. 使用曲线图创建器生成曲线图
        ChartCreator curveCreator = new CurveChartCreator();
        System.out.println("【任务1】生成月度销售趋势图");
        curveCreator.generateChart();

        System.out.println("\n-----------------------------------\n");

        // 2. 使用柱状图创建器生成柱状图
        ChartCreator barCreator = new BarChartCreator();
        System.out.println("【任务2】生成各部门业绩对比图");
        barCreator.generateChart();

        System.out.println("\n===== 统计报表生成完毕 =====");
    }
}
