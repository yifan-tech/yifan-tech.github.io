/**
 * CurveChart 具体产品类 —— 曲线图
 */
public class CurveChart extends Chart {

    @Override
    public void render() {
        System.out.println("  >> 渲染曲线图: 绘制坐标轴 -> 绘制数据点 -> 贝塞尔平滑连线 -> 添加图例");
    }

    @Override
    public void export() {
        System.out.println("  >> 导出曲线图: 将曲线图以 PNG 格式保存到磁盘");
    }
}
