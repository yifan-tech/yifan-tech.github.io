/**
 * ChartCreator 抽象工厂类 (Creator)
 * 定义工厂方法 createChart()，子类实现以创建具体图表
 */
public abstract class ChartCreator {

    public Chart generateChart() {
        Chart chart = createChart();
        System.out.println("[" + this.getClass().getSimpleName() + "] 创建图表成功，开始渲染...");
        chart.render();
        chart.export();
        return chart;
    }

    /** 工厂方法 —— 由子类实现 */
    protected abstract Chart createChart();
}
