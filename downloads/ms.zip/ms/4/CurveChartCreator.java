/**
 * CurveChartCreator 具体工厂 —— 曲线图创建器
 */
public class CurveChartCreator extends ChartCreator {

    @Override
    protected Chart createChart() {
        return new CurveChart();
    }
}
