/**
 * BarChartCreator 具体工厂 —— 柱状图创建器
 */
public class BarChartCreator extends ChartCreator {

    @Override
    protected Chart createChart() {
        return new BarChart();
    }
}
