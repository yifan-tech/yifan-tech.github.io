/**
 * Chart 抽象产品类
 * 所有统计图表均继承此类
 */
public abstract class Chart {

    /** 渲染图表 */
    public abstract void render();

    /** 导出图表 */
    public abstract void export();
}
