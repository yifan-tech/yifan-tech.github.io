import java.util.ArrayList;
import java.util.List;

/**
 * VideoPlayer 产品类 —— 视频播放器界面
 */
public class VideoPlayer {
    private String modeName;
    private List<String> components = new ArrayList<>();

    public void setModeName(String name) { this.modeName = name; }
    public void addComponent(String comp) { components.add(comp); }

    public void show() {
        System.out.println("\n  ====== [" + modeName + "] 界面布局 ======");
        for (String c : components) {
            System.out.println("  |  " + c);
        }
        System.out.println("  =================================");
    }
}
