/**
 * MemoryModeBuilder 具体建造者 —— 记忆模式
 * 显示: 主窗口 + 控制条 + 收藏列表
 */
public class MemoryModeBuilder extends PlayerBuilder {
    @Override public void buildMenu()       { /* 记忆模式无菜单 */ }
    @Override public void buildPlayList()   { /* 记忆模式无播放列表 */ }
    @Override public void buildMainWindow() { player.addComponent("主窗口 (视频渲染区域)"); }
    @Override public void buildControlBar() { player.addComponent("控制条 (含上次播放记录按钮)"); }
    @Override public void buildFavorites()  { player.addComponent("收藏列表 (历史记录/我的收藏)"); }
    @Override public void buildNetworkPanel(){/* 记忆模式无网络 */ }
}
