/**
 * PlayerDirector 指挥者 —— 统一控制界面组装流程
 */
public class PlayerDirector {

    public VideoPlayer construct(PlayerBuilder builder, String modeName) {
        builder.player.setModeName(modeName);
        System.out.println("\n>>> 构建界面: " + modeName);

        builder.buildMenu();
        builder.buildPlayList();
        builder.buildMainWindow();
        builder.buildControlBar();
        builder.buildFavorites();
        builder.buildNetworkPanel();

        System.out.println(">>> 界面构建完成!");
        return builder.getResult();
    }
}
