/**
 * PlayerBuilder 抽象建造者 —— 定义创建各界面组件的抽象方法
 */
public abstract class PlayerBuilder {
    protected VideoPlayer player = new VideoPlayer();

    public abstract void buildMenu();
    public abstract void buildPlayList();
    public abstract void buildMainWindow();
    public abstract void buildControlBar();
    public abstract void buildFavorites();
    public abstract void buildNetworkPanel();

    public VideoPlayer getResult() { return player; }
}
