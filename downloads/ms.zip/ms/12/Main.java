/**
 * 题12 测试类 - 视频播放器界面模式 (建造者模式)
 *
 * ============================ 类图 ============================
 * ┌───────────────┐       ┌──────────────────────────┐
 * │PlayerDirector │──────>│    PlayerBuilder          │ (抽象建造者)
 * ├───────────────┤       ├──────────────────────────┤
 * │+construct()   │       │# player:VideoPlayer      │
 * └───────────────┘       │+buildMenu()              │
 *                         │+buildPlayList()          │
 *                         │+buildMainWindow()        │
 *                         │+buildControlBar()        │
 *                         │+buildFavorites()         │
 *                         │+buildNetworkPanel()      │
 *                         │+getResult():VideoPlayer  │
 *                         └────────────┬─────────────┘
 *      ┌─────────────────┬────────────┼────────────┬──────────────────┐
 *      ▼                 ▼            ▼            ▼                  ▼
 * ┌──────────┐   ┌────────────┐ ┌──────────┐ ┌────────────┐
 * │  Full    │   │  Compact   │ │  Memory  │ │  Network   │
 * │  Mode    │   │  Mode      │ │  Mode    │ │  Mode      │
 * └──────────┘   └────────────┘ └──────────┘ └────────────┘
 *                          │
 *                          ▼
 *                  ┌──────────────┐
 *                  │ VideoPlayer  │ (产品)
 *                  └──────────────┘
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 视频播放器 - 建造者模式 =====\n");
        PlayerDirector director = new PlayerDirector();

        // 1. 完整模式
        VideoPlayer full = director.construct(new FullModeBuilder(), "完整模式");
        full.show();

        // 2. 精简模式
        VideoPlayer compact = director.construct(new CompactModeBuilder(), "精简模式");
        compact.show();

        // 3. 记忆模式
        VideoPlayer memory = director.construct(new MemoryModeBuilder(), "记忆模式");
        memory.show();

        // 4. 网络模式
        VideoPlayer network = director.construct(new NetworkModeBuilder(), "网络模式");
        network.show();

        System.out.println("\n===== 所有界面模式构建完毕 =====");
    }
}
