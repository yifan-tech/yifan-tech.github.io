/**
 * FullModeBuilder 具体建造者 —— 完整模式
 * 显示: 菜单 + 播放列表 + 主窗口 + 控制条
 */
public class FullModeBuilder extends PlayerBuilder {
    @Override public void buildMenu()       { player.addComponent("菜单栏 (文件/播放/工具/帮助)"); }
    @Override public void buildPlayList()   { player.addComponent("播放列表 (右侧边栏)"); }
    @Override public void buildMainWindow() { player.addComponent("主窗口 (视频渲染区域)"); }
    @Override public void buildControlBar() { player.addComponent("控制条 (播放/暂停/进度/音量)"); }
    @Override public void buildFavorites()  { /* 完整模式不含收藏 */ }
    @Override public void buildNetworkPanel(){/* 完整模式不含网络 */ }
}
