/**
 * NetworkModeBuilder 具体建造者 —— 网络模式
 * 显示: 菜单 + 播放列表(网络) + 主窗口 + 控制条 + 网络面板
 */
public class NetworkModeBuilder extends PlayerBuilder {
    @Override public void buildMenu()       { player.addComponent("菜单栏 (在线资源/直播/网络设置)"); }
    @Override public void buildPlayList()   { player.addComponent("播放列表 (网络流媒体列表)"); }
    @Override public void buildMainWindow() { player.addComponent("主窗口 (在线视频渲染)"); }
    @Override public void buildControlBar() { player.addComponent("控制条 (含网络缓冲状态)"); }
    @Override public void buildFavorites()  { /* 网络模式不含本地收藏 */ }
    @Override public void buildNetworkPanel(){player.addComponent("网络面板 (带宽/缓存/连接状态)"); }
}
