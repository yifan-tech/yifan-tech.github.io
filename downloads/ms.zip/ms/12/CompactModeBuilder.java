/**
 * CompactModeBuilder 具体建造者 —— 精简模式
 * 显示: 主窗口 + 控制条
 */
public class CompactModeBuilder extends PlayerBuilder {
    @Override public void buildMenu()       { /* 精简模式无菜单 */ }
    @Override public void buildPlayList()   { /* 精简模式无播放列表 */ }
    @Override public void buildMainWindow() { player.addComponent("主窗口 (全屏视频渲染)"); }
    @Override public void buildControlBar() { player.addComponent("控制条 (浮动简洁控制条)"); }
    @Override public void buildFavorites()  { /* 精简模式无收藏 */ }
    @Override public void buildNetworkPanel(){/* 精简模式无网络 */ }
}
