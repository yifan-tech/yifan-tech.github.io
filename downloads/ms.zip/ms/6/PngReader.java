/**
 * PngReader 具体产品 —— PNG图片读取器
 */
public class PngReader extends ImageReader {

    @Override
    public void read() {
        System.out.println("  [PngReader] 解析PNG文件: " + filePath);
        System.out.println("    -> 验证 PNG Signature (89 50 4E 47)");
        System.out.println("    -> 解析 IHDR 图像头信息...");
        System.out.println("    -> Deflate解压IDAT数据块...");
        System.out.println("    -> 逐行Filter过滤重建像素");
    }

    @Override
    public void showInfo() {
        System.out.println("\n  [图片信息] 格式: PNG | 路径: " + filePath);
        System.out.println("  [特性] 支持RGBA透明 | 无损压缩 | 广泛兼容");
    }
}
