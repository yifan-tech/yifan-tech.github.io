/**
 * PngReaderFactory 具体工厂 —— PNG读取器工厂
 */
public class PngReaderFactory extends ImageReaderFactory {

    @Override
    protected ImageReader createReader() {
        return new PngReader();
    }
}
