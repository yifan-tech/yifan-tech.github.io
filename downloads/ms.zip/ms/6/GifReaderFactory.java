/**
 * GifReaderFactory 具体工厂 —— GIF读取器工厂
 */
public class GifReaderFactory extends ImageReaderFactory {

    @Override
    protected ImageReader createReader() {
        return new GifReader();
    }
}
