/**
 * JpgReaderFactory 具体工厂 —— JPG读取器工厂
 */
public class JpgReaderFactory extends ImageReaderFactory {

    @Override
    protected ImageReader createReader() {
        return new JpgReader();
    }
}
