/**
 * ImageReaderFactory 抽象工厂类 (Creator)
 */
public abstract class ImageReaderFactory {

    public ImageReader openImage(String filePath) {
        ImageReader reader = createReader();
        reader.setFilePath(filePath);
        System.out.println("[" + this.getClass().getSimpleName() + "] 打开图片: " + filePath);
        reader.read();
        reader.showInfo();
        return reader;
    }

    /** 工厂方法 */
    protected abstract ImageReader createReader();
}
