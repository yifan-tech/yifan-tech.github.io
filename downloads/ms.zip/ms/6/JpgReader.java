/**
 * JpgReader 具体产品 —— JPG图片读取器
 */
public class JpgReader extends ImageReader {

    @Override
    public void read() {
        System.out.println("  [JpgReader] 解析JPG文件: " + filePath);
        System.out.println("    -> 验证 SOI (FFD8) 文件起始标记");
        System.out.println("    -> 解析JFIF/EXIF元数据段...");
        System.out.println("    -> Huffman解码 + 反量化...");
        System.out.println("    -> IDCT逆变换重建图像");
    }

    @Override
    public void showInfo() {
        System.out.println("\n  [图片信息] 格式: JPG | 路径: " + filePath);
        System.out.println("  [特性] 支持1670万色 | 有损压缩 | 适合照片存储");
    }
}
