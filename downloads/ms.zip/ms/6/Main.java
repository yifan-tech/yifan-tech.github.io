/**
 * 题6 测试类 —— 图片读取器 (工厂方法模式)
 *
 * ============================ 类图 ============================
 *
 *   ┌──────────────────────────┐
 *   │   ImageReaderFactory     │  (抽象 Creator)
 *   ├──────────────────────────┤
 *   │ + openImage(path)        │──────────┐
 *   │ # createReader()         │          │ 依赖
 *   └─────────────┬────────────┘          ▼
 *                 │            ┌─────────────────────┐
 *   ┌─────────────┼────────────┤    ImageReader      │  (抽象 Product)
 *   ▼             ▼            ▼  ├─────────────────────┤
 * ┌──────────┐┌──────────┐┌──────────┐│ + read()          │
 * │  Gif     ││   Jpg    ││   Png    ││ + showInfo()      │
 * │ Factory  ││ Factory  ││ Factory  │└─────────┬───────────┘
 * └────┬─────┘└────┬─────┘└────┬─────┘          │
 *      │           │           │      ┌─────────┼─────────┐
 *      ▼           ▼           ▼      ▼         ▼         ▼
 *   ┌──────┐  ┌──────────┐  ┌──────┐┌──────┐┌──────┐
 *   │ Gif  │  │   Jpg    │  │ Png  ││ Jpg  ││ Png  │
 *   │Reader│  │  Reader  │  │Reader││Reader││Reader│
 *   └──────┘  └──────────┘  └──────┘└──────┘└──────┘
 * =============================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== 图片读取器 - 工厂方法模式 =====\n");

        // 1. 读取 GIF 图片
        ImageReaderFactory gifFactory = new GifReaderFactory();
        gifFactory.openImage("photos/animation.gif");

        System.out.println("\n--------------------------------------\n");

        // 2. 读取 JPG 图片
        ImageReaderFactory jpgFactory = new JpgReaderFactory();
        jpgFactory.openImage("photos/landscape.jpg");

        System.out.println("\n--------------------------------------\n");

        // 3. 读取 PNG 图片 (扩展性展示)
        ImageReaderFactory pngFactory = new PngReaderFactory();
        pngFactory.openImage("photos/logo.png");

        System.out.println("\n===== 图片读取完毕 =====");
        System.out.println("\n提示: 如需支持新格式(BMP/WEBP等)，只需新增具体产品和工厂类");
    }
}
