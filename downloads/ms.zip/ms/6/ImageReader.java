/**
 * ImageReader 抽象产品类
 * 所有图片读取器均继承此类
 */
public abstract class ImageReader {

    protected String filePath;

    public void setFilePath(String path) {
        this.filePath = path;
    }

    /** 读取图片文件 */
    public abstract void read();

    /** 显示图片信息 */
    public abstract void showInfo();
}
