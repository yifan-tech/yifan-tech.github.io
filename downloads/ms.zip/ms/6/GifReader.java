/**
 * GifReader 具体产品 —— GIF图片读取器
 */
public class GifReader extends ImageReader {

    @Override
    public void read() {
        System.out.println("  [GifReader] 解析GIF文件头: " + filePath);
        System.out.println("    -> 验证 GIF87a/GIF89a 格式标识");
        System.out.println("    -> 读取全局调色板...");
        System.out.println("    -> 逐帧解码LZW压缩数据...");
        System.out.println("    -> 支持透明通道与动画帧");
    }

    @Override
    public void showInfo() {
        System.out.println("\n  [图片信息] 格式: GIF | 路径: " + filePath);
        System.out.println("  [特性] 支持256色调色板 | 支持多帧动画 | 无损压缩");
    }
}
