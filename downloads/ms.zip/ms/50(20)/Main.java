import java.util.Stack;

/** 题50 - 备忘录: 编辑器状态 */
class EditorState { private String content;
    public EditorState(String c) { this.content = c; }
    public String getContent() { return content; }
}

/** 发起人: 编辑器 */
class Editor {
    private String content = "";
    public void write(String t) { content += t; }
    public String getContent() { return content; }
    public EditorState save() { return new EditorState(content); }
    public void restore(EditorState s) { content = s.getContent(); }
}

/** 题50 - 管理者: 双栈 */
public class Main {
    private Editor editor = new Editor();
    private Stack<EditorState> undoStack = new Stack<>();
    private Stack<EditorState> redoStack = new Stack<>();

    public void type(String t) {
        undoStack.push(editor.save());
        redoStack.clear();
        editor.write(t);
        System.out.println("  输入: \"" + t + "\" -> 当前: \"" + editor.getContent() + "\"");
    }
    public void undo() {
        if (!undoStack.isEmpty()) { redoStack.push(editor.save()); editor.restore(undoStack.pop());
            System.out.println("  Undo -> 当前: \"" + editor.getContent() + "\""); }
    }
    public void redo() {
        if (!redoStack.isEmpty()) { undoStack.push(editor.save()); editor.restore(redoStack.pop());
            System.out.println("  Redo -> 当前: \"" + editor.getContent() + "\""); }
    }

    public static void main(String[] args) {
        System.out.println("===== 备忘录模式 - 撤销/重做(双栈) =====\n");
        Main app = new Main();
        app.type("Hello"); app.type(" World"); app.undo(); app.undo(); app.redo(); app.redo();
    }
}
