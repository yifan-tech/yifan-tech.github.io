/**
 * Statement 抽象产品 —— 数据库语句对象
 */
public abstract class Statement {

    protected String dbType;

    public Statement(String dbType) {
        this.dbType = dbType;
    }

    /** 执行SQL语句 */
    public abstract void execute(String sql);

    /** 获取结果集 */
    public abstract void getResultSet();
}
