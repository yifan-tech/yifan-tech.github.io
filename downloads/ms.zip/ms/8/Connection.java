/**
 * Connection 抽象产品 —— 数据库连接对象
 */
public abstract class Connection {

    protected String dbType;

    public Connection(String dbType) {
        this.dbType = dbType;
    }

    /** 打开连接 */
    public abstract void open();

    /** 关闭连接 */
    public abstract void close();
}
