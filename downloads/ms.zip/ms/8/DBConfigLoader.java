/**
 * DBConfigLoader 配置文件加载器
 * 从 dbconfig.properties 中读取数据库类型配置，动态创建对应的工厂
 */
import java.io.*;
import java.util.Properties;

public class DBConfigLoader {

    private static Properties props = new Properties();

    static {
        try (InputStream in = new FileInputStream("dbconfig.properties")) {
            props.load(in);
            System.out.println("[DBConfig] 配置文件加载成功");
        } catch (IOException e) {
            System.out.println("[DBConfig] 配置文件未找到，使用默认配置: oracle");
            props.setProperty("db.type", "oracle");
        }
    }

    public static String getDBType() {
        return props.getProperty("db.type", "oracle");
    }

    /** 根据配置创建对应的数据库工厂 */
    public static DBFactory getFactory() {
        String type = getDBType();
        System.out.println("[DBConfig] 当前数据库类型: " + type);
        switch (type.toLowerCase()) {
            case "oracle":
                return new OracleFactory();
            case "mysql":
                return new MySQLFactory();
            default:
                System.out.println("[DBConfig] 未知类型 '" + type + "'，使用默认 Oracle");
                return new OracleFactory();
        }
    }
}
