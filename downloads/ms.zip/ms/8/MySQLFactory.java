/**
 * MySQLFactory 具体工厂 —— MySQL产品族
 */
public class MySQLFactory extends DBFactory {

    @Override
    public Connection createConnection() {
        return new MySQLConnection();
    }

    @Override
    public Statement createStatement() {
        return new MySQLStatement();
    }
}
