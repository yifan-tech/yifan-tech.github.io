/**
 * 题8 测试类 —— 数据库连接 (抽象工厂模式 + 配置文件)
 *
 * ============================ 类图 ============================
 *
 *    ┌──────────────────┐
 *    │    DBFactory     │  (抽象工厂)
 *    ├──────────────────┤
 *    │+createConnection()│
 *    │+createStatement() │
 *    └────────┬─────────┘
 *             │
 *    ┌────────┴───────┐
 *    ▼                ▼
 * ┌──────────┐  ┌──────────┐
 * │ Oracle   │  │  MySQL   │
 * │ Factory  │  │ Factory  │
 * ├──────────┤  ├──────────┤
 * │+create   │  │+create   │
 * │ Conn()   │  │ Conn()   │
 * │+create   │  │+create   │
 * │ Stmt()   │  │ Stmt()   │
 * └──┬───┬───┘  └──┬───┬───┘
 *    │   │         │   │
 *    ▼   ▼         ▼   ▼
 * ┌──────┐┌──────┐┌──────┐┌──────┐
 * │Oracle││Oracle││MySQL ││MySQL │
 * │Conn  ││Stmt  ││Conn  ││Stmt  │
 * └──┬───┘└──┬───┘└──┬───┘└──┬───┘
 *    │       │      │       │
 *    ▼       ▼      ▼       ▼
 * ┌──────┐┌──────┐  (Connection / Statement 抽象产品)
 * │Conn  ││Stmt  │
 * └──────┘└──────┘
 *
 *   ┌───────────────┐       ┌──────────────────┐
 *   │DBConfigLoader │──────▶│dbconfig.properties│
 *   ├───────────────┤       └──────────────────┘
 *   │+getFactory()  │
 *   └───────────────┘
 * =============================================================
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("===== 数据库连接 - 抽象工厂模式 =====\n");

        // 从配置文件读取数据库类型，动态获取工厂
        DBFactory factory = DBConfigLoader.getFactory();

        // 通过工厂创建 Connection 和 Statement，保证同一产品族
        Connection conn = factory.createConnection();
        Statement stmt = factory.createStatement();

        System.out.println();
        conn.open();
        stmt.execute("SELECT * FROM users WHERE status = 1");
        stmt.getResultSet();
        conn.close();

        System.out.println("\n===== 操作完毕 =====");
        System.out.println("\n提示: 修改 dbconfig.properties 中 db.type 的值");
        System.out.println("      (oracle / mysql) 即可切换数据库类型");
    }
}
