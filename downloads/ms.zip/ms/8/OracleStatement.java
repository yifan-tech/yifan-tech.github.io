/**
 * OracleStatement 具体产品 —— Oracle语句对象
 */
public class OracleStatement extends Statement {

    public OracleStatement() {
        super("Oracle");
    }

    @Override
    public void execute(String sql) {
        System.out.println("  [Oracle] 执行SQL: " + sql);
        System.out.println("    -> 查询优化器模式: ALL_ROWS");
        System.out.println("    -> 使用Oracle特有语法解析...");
    }

    @Override
    public void getResultSet() {
        System.out.println("  [Oracle] 获取结果集 -> OracleResultSet (支持ROWID)");
    }
}
