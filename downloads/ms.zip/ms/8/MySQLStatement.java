/**
 * MySQLStatement 具体产品 —— MySQL语句对象
 */
public class MySQLStatement extends Statement {

    public MySQLStatement() {
        super("MySQL");
    }

    @Override
    public void execute(String sql) {
        System.out.println("  [MySQL] 执行SQL: " + sql);
        System.out.println("    -> 查询优化器模式: 基于成本");
        System.out.println("    -> 使用MySQL特有语法解析...");
    }

    @Override
    public void getResultSet() {
        System.out.println("  [MySQL] 获取结果集 -> MySQLResultSet (支持流式读取)");
    }
}
