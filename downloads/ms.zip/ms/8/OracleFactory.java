/**
 * OracleFactory 具体工厂 —— Oracle产品族
 */
public class OracleFactory extends DBFactory {

    @Override
    public Connection createConnection() {
        return new OracleConnection();
    }

    @Override
    public Statement createStatement() {
        return new OracleStatement();
    }
}
