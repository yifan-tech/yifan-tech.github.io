/**
 * OracleConnection 具体产品 —— Oracle数据库连接
 */
public class OracleConnection extends Connection {

    public OracleConnection() {
        super("Oracle");
    }

    @Override
    public void open() {
        System.out.println("  [Oracle] 连接Oracle数据库...");
        System.out.println("    -> Driver: oracle.jdbc.OracleDriver");
        System.out.println("    -> URL: jdbc:oracle:thin:@localhost:1521:ORCL");
        System.out.println("    -> 连接成功 (SID=ORCL, sessionID=0xA3F2)");
    }

    @Override
    public void close() {
        System.out.println("  [Oracle] 关闭Oracle数据库连接");
    }
}
