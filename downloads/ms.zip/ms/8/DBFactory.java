/**
 * DBFactory 抽象工厂类
 * 定义一个产品族: Connection + Statement (同一数据库品牌)
 */
public abstract class DBFactory {

    /** 创建数据库连接 */
    public abstract Connection createConnection();

    /** 创建语句对象 */
    public abstract Statement createStatement();
}
