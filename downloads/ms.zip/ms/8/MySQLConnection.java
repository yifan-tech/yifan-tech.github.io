/**
 * MySQLConnection 具体产品 —— MySQL数据库连接
 */
public class MySQLConnection extends Connection {

    public MySQLConnection() {
        super("MySQL");
    }

    @Override
    public void open() {
        System.out.println("  [MySQL] 连接MySQL数据库...");
        System.out.println("    -> Driver: com.mysql.cj.jdbc.Driver");
        System.out.println("    -> URL: jdbc:mysql://localhost:3306/test?serverTimezone=UTC");
        System.out.println("    -> 连接成功 (threadID=42, charset=utf8mb4)");
    }

    @Override
    public void close() {
        System.out.println("  [MySQL] 关闭MySQL数据库连接");
    }
}
