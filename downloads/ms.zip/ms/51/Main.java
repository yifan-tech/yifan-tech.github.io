/** 题51 - 备忘录: 游戏存档 */
class GameMemento implements java.io.Serializable {
    String scene; int level; int hp;
    public GameMemento(String s, int l, int h) { this.scene = s; this.level = l; this.hp = h; }
}

/** 发起人: RPG游戏 */
class RPGGame {
    private String scene; private int level; private int hp;
    public RPGGame() { this.scene = "新手村"; this.level = 1; this.hp = 100; }
    public void play() { level++; hp -= 20; scene = "第" + level + "关: 黑暗森林"; }
    public void die() { System.out.println("  玩家在 " + scene + " 阵亡! HP=0"); }
    public GameMemento save() { System.out.println("  [保存] 恢复点: " + scene + " Lv." + level + " HP:" + hp); return new GameMemento(scene, level, hp); }
    public void restore(GameMemento m) { scene = m.scene; level = m.level; hp = m.hp;
        System.out.println("  [读取] 恢复到: " + scene + " Lv." + level + " HP:" + hp); }
    public void info() { System.out.println("  当前: " + scene + " Lv." + level + " HP:" + hp); }
}

/** 题51 主测试 */
public class Main {
    private RPGGame game = new RPGGame(); private GameMemento checkpoint;

    public static void main(String[] args) {
        System.out.println("===== RPG游戏恢复点 - 备忘录模式 =====\n");
        Main app = new Main();
        app.game.info();
        app.game.play();
        app.game.play();
        app.checkpoint = app.game.save();  // 设置恢复点
        app.game.play();
        app.game.die();
        app.game.restore(app.checkpoint);  // 回到恢复点
    }
}
