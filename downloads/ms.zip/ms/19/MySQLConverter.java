/**
 * MySQLConverter 细化抽象 —— MySQL数据库转换器
 */
public class MySQLConverter extends DataConverter {

    public MySQLConverter(FileFormat format, String dataSource) {
        super(format, dataSource);
    }

    @Override
    protected String fetchData() {
        System.out.println("  [MySQL] 连接 mysql://" + dataSource + " -> SELECT * FROM table...");
        return "[MySQL数据: id=1,name=Alice | id=2,name=Bob]";
    }
}
