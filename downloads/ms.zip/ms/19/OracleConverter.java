/**
 * OracleConverter 细化抽象 —— Oracle数据库转换器
 */
public class OracleConverter extends DataConverter {

    public OracleConverter(FileFormat format, String dataSource) {
        super(format, dataSource);
    }

    @Override
    protected String fetchData() {
        System.out.println("  [Oracle] 连接 oracle://" + dataSource + " -> SELECT * FROM table...");
        return "[Oracle数据: ROWID=AAAE,a=100 | ROWID=AAAF,a=200]";
    }
}
