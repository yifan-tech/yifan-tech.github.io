/**
 * PDFFormat 具体实现者 —— PDF格式
 */
public class PDFFormat implements FileFormat {
    @Override
    public void export(String data, String fileName) {
        System.out.println("  [PDF导出] -> " + fileName + ".pdf");
        System.out.println("    生成PDF文档, 内嵌字体, 分页排版");
        System.out.println("    内容摘要: " + data.substring(0, Math.min(50, data.length())) + "...");
    }
}
