/**
 * DataConverter 抽象类 —— 数据库维度 (抽象)
 * 持有 FileFormat 引用形成桥接
 */
public abstract class DataConverter {
    protected FileFormat format;  // 桥接: 输出格式
    protected String dataSource;

    public DataConverter(FileFormat format, String dataSource) {
        this.format = format;
        this.dataSource = dataSource;
    }

    /** 获取数据库中数据 */
    protected abstract String fetchData();

    /** 执行转换 */
    public void convert(String fileName) {
        System.out.println("\n>>> 数据转换: " + dataSource + " -> " + fileName);
        String data = fetchData();
        format.export(data, fileName);
    }
}
