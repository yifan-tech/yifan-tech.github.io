/**
 * FileFormat 实现者接口 —— 文件格式维度
 * 定义将数据输出为不同格式的能力
 */
public interface FileFormat {
    /** 将指定数据导出为对应格式 */
    void export(String data, String fileName);
}
