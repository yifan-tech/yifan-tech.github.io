/**
 * TXTFormat 具体实现者 —— TXT文本格式
 */
public class TXTFormat implements FileFormat {
    @Override
    public void export(String data, String fileName) {
        System.out.println("  [TXT导出] -> " + fileName + ".txt");
        System.out.println("    内容: " + data);
        System.out.println("    编码: UTF-8 | 分隔符: 制表符");
    }
}
