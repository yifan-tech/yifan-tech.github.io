/**
 * XMLFormat 具体实现者 —— XML格式
 */
public class XMLFormat implements FileFormat {
    @Override
    public void export(String data, String fileName) {
        System.out.println("  [XML导出] -> " + fileName + ".xml");
        System.out.println("    <data>" + data + "</data>");
        System.out.println("    格式: 结构化XML | 带Schema验证");
    }
}
