/**
 * 题19 测试类 - 数据转换工具 (桥接模式)
 *
 * ============================ 类图 ============================
 *   ┌──────────────┐        ┌──────────────┐
 *   │ DataConverter│───────>│  FileFormat  │ (实现者接口)
 *   ├──────────────┤        ├──────────────┤
 *   │#format       │        │+export()     │
 *   │#dataSource   │        └──────┬───────┘
 *   │+convert()    │      ┌────────┼─────────┐
 *   │#fetchData()  │      ▼        ▼         ▼
 *   └──────┬───────┘   ┌────┐ ┌──────┐ ┌──────┐
 *          │           │TXT │ │ XML  │ │ PDF  │
 *   ┌──────┴──────┐    └────┘ └──────┘ └──────┘
 *   ▼             ▼
 * ┌────────┐ ┌────────┐
 * │ MySQL  │ │ Oracle │
 * │ Conv   │ │ Conv   │
 * └────────┘ └────────┘
 *   (抽象维度)     (实现者维度)
 * 桥接: DataConverter ◄──► FileFormat
 * 数据库类型 与 输出格式 两个维度独立扩展
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 数据转换工具 - 桥接模式 =====\n");

        // MySQL + TXT
        new MySQLConverter(new TXTFormat(), "192.168.1.100:3306/mydb")
                .convert("users_export");

        // MySQL + XML
        new MySQLConverter(new XMLFormat(), "192.168.1.100:3306/mydb")
                .convert("users_export");

        // Oracle + PDF
        new OracleConverter(new PDFFormat(), "10.0.0.50:1521/ORCL")
                .convert("financial_report");

        // Oracle + TXT (新增数据库+现有格式自由组合)
        new OracleConverter(new TXTFormat(), "10.0.0.50:1521/ORCL")
                .convert("audit_log");

        System.out.println("\n===== 转换完毕 =====");
        System.out.println("特点: 数据库类型(MySQL/Oracle/...) 与 输出格式(TXT/XML/PDF/...)");
        System.out.println("       两个维度通过桥接模式独立扩展, 可任意组合");
    }
}
