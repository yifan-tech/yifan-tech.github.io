/** 题35 - 军情任务书 */
class Mission {
    int enemyCount;
    public Mission(int c) { this.enemyCount = c; }
}

/** 题35 - 抽象长官 */
abstract class Officer {
    protected Officer superior;
    public Officer(Officer s) { this.superior = s; }
    public abstract void handleMission(Mission m);
}

/** 题35 - 具体长官 */
class Banzhang extends Officer {
    public Banzhang(Officer s) { super(s); }
    @Override public void handleMission(Mission m) {
        if (m.enemyCount < 10) System.out.println("  班长下达作战命令! (敌人数:" + m.enemyCount + ")");
        else { System.out.println("  班长无法处理(敌人数:"+m.enemyCount+"), 上报排长..."); superior.handleMission(m); }
    }
}
class Paizhang extends Officer {
    public Paizhang(Officer s) { super(s); }
    @Override public void handleMission(Mission m) {
        if (m.enemyCount < 50) System.out.println("  排长下达作战命令! (敌人数:" + m.enemyCount + ")");
        else { System.out.println("  排长无法处理(敌人数:"+m.enemyCount+"), 上报营长..."); superior.handleMission(m); }
    }
}
class Yingzhang extends Officer {
    public Yingzhang() { super(null); }
    @Override public void handleMission(Mission m) {
        if (m.enemyCount < 200) System.out.println("  营长下达作战命令! (敌人数:" + m.enemyCount + ")");
        else System.out.println("  敌人数" + m.enemyCount + " >= 200, 需要开会讨论再下达作战命令!");
    }
}

/** 题35 主测试 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 军队作战命令 - 职责链模式 =====\n");
        Yingzhang yz = new Yingzhang();
        Paizhang pz = new Paizhang(yz);
        Banzhang bz = new Banzhang(pz);
        for (int n : new int[]{5, 30, 150, 300}) {
            System.out.println(">>> 情报: 敌人数量 = " + n);
            bz.handleMission(new Mission(n));
            System.out.println();
        }
    }
}
