import java.util.List;
/** 题21 - 抽象构件 */
public abstract class Control {
    protected String name;
    public Control(String name) { this.name = name; }
    public abstract void render();
    public void add(Control c) { throw new UnsupportedOperationException(); }
    public void remove(Control c) { throw new UnsupportedOperationException(); }
}
