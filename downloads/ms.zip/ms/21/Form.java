import java.util.ArrayList;
import java.util.List;
/** 题21 - 容器控件: 窗体 */
public class Form extends Control {
    private List<Control> children = new ArrayList<>();
    public Form(String name) { super(name); }
    @Override public void add(Control c) { children.add(c); }
    @Override public void remove(Control c) { children.remove(c); }
    @Override public void render() {
        System.out.println("[窗体] " + name + " 开始渲染...");
        for (Control c : children) c.render();
    }
}
