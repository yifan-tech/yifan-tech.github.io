/** 题21 - 叶子控件: 按钮 */
public class Button extends Control {
    public Button(String name) { super(name); }
    @Override public void render() { System.out.println("  [按钮] " + name + " 渲染完成"); }
}
