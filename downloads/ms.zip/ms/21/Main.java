/**
 * 题21 测试 - 界面控件库 (组合模式)
 * 类图: Control(抽象) <- Button/TextBox(叶子) / Form/Panel(容器)
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 界面控件库 - 组合模式 =====\n");
        Form mainForm = new Form("主窗体");
        Panel topPanel = new Panel("顶部面板");
        Panel bottomPanel = new Panel("底部面板");
        topPanel.add(new Button("确定"));
        topPanel.add(new Button("取消"));
        bottomPanel.add(new TextBox("用户名"));
        bottomPanel.add(new TextBox("密码"));
        mainForm.add(topPanel);
        mainForm.add(bottomPanel);
        mainForm.render();
    }
}
