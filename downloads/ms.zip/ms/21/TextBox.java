/** 题21 - 叶子控件: 文本框 */
public class TextBox extends Control {
    public TextBox(String name) { super(name); }
    @Override public void render() { System.out.println("  [文本框] " + name + " 渲染完成"); }
}
