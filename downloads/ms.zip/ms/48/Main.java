import java.util.*;

/** 题48 - 中介者接口 */
interface Mediator { void notify(String from, String event); }

/** 抽象窗格 */
abstract class Pane {
    protected Mediator mediator; protected String name;
    public Pane(Mediator m, String n) { this.mediator = m; this.name = n; }
    public abstract void handleEvent(String event);
}

class TextPane extends Pane {
    public TextPane(Mediator m) { super(m, "TextPane"); }
    @Override public void handleEvent(String e) { System.out.println("  [" + name + "] 处理事件: " + e); }
}
class ListPane extends Pane {
    public ListPane(Mediator m) { super(m, "ListPane"); }
    @Override public void handleEvent(String e) { System.out.println("  [" + name + "] 处理事件: " + e); }
}

/** 具体中介者: 窗口 */
public class Main implements Mediator {
    private TextPane text = new TextPane(this);
    private ListPane list = new ListPane(this);

    @Override public void notify(String from, String event) {
        System.out.println("[Window] 协调: " + from + " 触发 " + event);
        if (from.equals("ListPane")) text.handleEvent("刷新文本");
        else list.handleEvent("更新列表");
    }

    public void simulate() {
        System.out.println("--- 用户在ListPane选择一项 ---");
        list.handleEvent("选中"); notify("ListPane", "selectionChanged");
    }

    public static void main(String[] args) {
        System.out.println("===== 图形界面窗格协调 - 中介者模式 =====\n");
        new Main().simulate();
    }
}
