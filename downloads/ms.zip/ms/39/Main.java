import java.util.*;

/** 题39 - 命令接口 */
interface Command { void execute(); void undo(); }

class AddCommand implements Command {
    private List<Integer> list; private int val, index;
    public AddCommand(List<Integer> l, int v) { this.list = l; this.val = v; }
    @Override public void execute() { index = list.size(); list.add(val); }
    @Override public void undo() { if(index>=0) list.remove(index); }
}

class RemoveCommand implements Command {
    private List<Integer> list; private int val, index;
    public RemoveCommand(List<Integer> l, int idx) { this.list = l; this.index = idx; }
    @Override public void execute() { val = list.remove(index); }
    @Override public void undo() { list.add(index, val); }
}

/** 题39 - 命令集合管理器 */
public class Main {
    private List<Command> history = new ArrayList<>();
    private int cursor = -1;
    private List<Integer> data = new ArrayList<>();

    public void execute(Command c) { c.execute(); while(history.size()>cursor+1) history.remove(history.size()-1); history.add(c); cursor++; }
    public void undo() { if(cursor>=0) { history.get(cursor).undo(); cursor--; } }
    public void redo() { if(cursor<history.size()-1) { cursor++; history.get(cursor).execute(); } }

    public static void main(String[] args) {
        System.out.println("===== 命令集合 undo/redo - 命令模式 =====\n");
        Main app = new Main();
        app.execute(new AddCommand(app.data, 10));
        app.execute(new AddCommand(app.data, 20));
        app.execute(new AddCommand(app.data, 30));
        System.out.println("当前数据: " + app.data);  // [10,20,30]
        app.undo();
        System.out.println("undo后: " + app.data);   // [10,20]
        app.redo();
        System.out.println("redo后: " + app.data);   // [10,20,30]
    }
}
