/** 题31 - 中介者模式蕴含 */
/** 主题接口 */
interface JobCenter {
    void match(String student, String job);
}
/** 具体中介: 职业介绍所 */
class EmploymentAgency implements JobCenter {
    @Override public void match(String s, String j) {
        System.out.println("[职业介绍所] 为毕业生 " + s + " 匹配工作: " + j);
    }
}

/** 题31 测试 - 蕴含中介者模式 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 毕业生求职 - 中介者模式 =====\n");
        JobCenter agency = new EmploymentAgency();
        agency.match("张三", "Java开发工程师");
        agency.match("李四", "软件测试工程师");
        System.out.println("\n这里蕴含的是【中介者模式】: 职业介绍所作为中介协调毕业生和用人单位");
    }
}
