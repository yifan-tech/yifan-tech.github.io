import java.io.*;

/**
 * DataChart 图表类 —— 支持深克隆 (通过序列化实现)
 */
public class DataChart implements Serializable {
    private static final long serialVersionUID = 1L;

    private int id;
    private String color;
    private DataSet dataSet;

    public DataChart(int id, String color, DataSet dataSet) {
        this.id = id;
        this.color = color;
        this.dataSet = dataSet;
    }

    public void setId(int id) { this.id = id; }
    public void setColor(String color) { this.color = color; }
    public DataSet getDataSet() { return dataSet; }

    /** 深克隆: 通过序列化/反序列化实现 */
    public DataChart deepClone() {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(this);

            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(bais);
            return (DataChart) ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public void show() {
        System.out.println("\n  ==== 图表信息 ====");
        System.out.println("  | 编号: " + id);
        System.out.println("  | 颜色: " + color);
        System.out.println("  | 数据: ");
        dataSet.show();
        System.out.println("  ===================");
    }
}
