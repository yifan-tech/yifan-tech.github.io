import java.io.*;
import java.util.Arrays;

/**
 * DataSet 数据集 —— 支持深克隆
 */
public class DataSet implements Serializable {
    private static final long serialVersionUID = 1L;

    private String tableName;
    private int[][] data;

    public DataSet(String tableName, int[][] data) {
        this.tableName = tableName;
        this.data = data;
    }

    public void setData(int row, int col, int value) { data[row][col] = value; }
    public void setTableName(String name) { this.tableName = name; }

    public void show() {
        System.out.println("  数据集: " + tableName);
        for (int[] row : data) {
            System.out.print("    ");
            for (int v : row) System.out.printf("%4d", v);
            System.out.println();
        }
    }
}
