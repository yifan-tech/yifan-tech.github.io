/**
 * 题13 测试类 - 图表复制 (原型模式 深克隆)
 *
 * ============================ 类图 ============================
 * ┌───────────────┐        ┌───────────────┐
 * │  <<interface>>│        │   DataSet     │
 * │ Serializable  │        ├───────────────┤
 * └───────┬───────┘        │-tableName     │
 *         │                │-data[][]      │
 *         ▼                │+show()        │
 * ┌───────────────┐        └───────────────┘
 * │  DataChart    │◄───持有
 * ├───────────────┤
 * │-id: int       │
 * │-color: String │
 * │-dataSet       │
 * ├───────────────┤
 * │+deepClone()   │────序列化/反序列化实现深克隆
 * │+show()        │
 * └───────────────┘
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 图表复制 - 原型模式 (深克隆) =====\n");

        // 原始图表
        DataSet ds1 = new DataSet("销售数据", new int[][]{{100,200,300},{400,500,600}});
        DataChart chart1 = new DataChart(1, "蓝色", ds1);
        System.out.println("【原始图表】");
        chart1.show();

        // 深克隆复制
        DataChart chart2 = chart1.deepClone();
        chart2.setId(2);
        chart2.setColor("红色");
        chart2.getDataSet().setTableName("销售数据(副本)");
        chart2.getDataSet().setData(0, 1, 999); // 修改副本数据
        System.out.println("\n【克隆后修改的图表】");
        chart2.show();

        // 验证原始图表未被影响 (深克隆特性)
        System.out.println("\n【验证: 原始图表是否受影响?】");
        chart1.show();
        System.out.println("\n>>> 原始图表数据未变，深克隆成功！");
    }
}
