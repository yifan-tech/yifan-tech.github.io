/** 题56 - 策略接口 */
interface EncryptStrategy { String encrypt(String text); }

class CaesarEncrypt implements EncryptStrategy {
    @Override public String encrypt(String t) {
        StringBuilder sb = new StringBuilder();
        for (char c : t.toCharArray()) sb.append((char)(c + 3));
        return sb.toString();
    }
}

class ModEncrypt implements EncryptStrategy {
    @Override public String encrypt(String t) {
        StringBuilder sb = new StringBuilder();
        for (char c : t.toCharArray()) sb.append((char)(c ^ 42));
        return sb.toString();
    }
}

/** 题56 - 加密上下文 */
public class Main {
    private EncryptStrategy strategy;
    public void setStrategy(EncryptStrategy s) { this.strategy = s; }
    public String encrypt(String t) { return strategy.encrypt(t); }

    public static void main(String[] args) {
        System.out.println("===== 数据加密(动态选择) - 策略模式 =====\n");
        Main ctx = new Main();
        ctx.setStrategy(new CaesarEncrypt());
        System.out.println("凯撒加密: " + ctx.encrypt("password"));

        ctx.setStrategy(new ModEncrypt());
        System.out.println("求模加密: " + ctx.encrypt("password"));

        System.out.println("\n可通过setStrategy动态切换加密方案");
    }
}
