import java.io.*;
import java.util.*;

/** 题40 - 命令接口(实现序列化) */
interface Command extends Serializable { void execute(); }

class PrintCommand implements Command {
    private String msg;
    public PrintCommand(String m) { this.msg = m; }
    @Override public void execute() { System.out.println("  执行: " + msg); }
}

/** 题40 - 请求日志记录 */
public class Main {
    public static void saveCommands(List<Command> cmds, String file) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
            oos.writeObject(cmds);
        }
        System.out.println("[日志] 命令已序列化到 " + file);
    }

    @SuppressWarnings("unchecked")
    public static List<Command> loadCommands(String file) throws Exception {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            return (List<Command>) ois.readObject();
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("===== 请求日志记录 - 命令模式 =====\n");
        List<Command> cmds = new ArrayList<>();
        cmds.add(new PrintCommand("步骤1: 初始化"));
        cmds.add(new PrintCommand("步骤2: 数据处理"));
        cmds.add(new PrintCommand("步骤3: 生成报告"));

        for (Command c : cmds) c.execute();
        saveCommands(cmds, "commands.log");
        System.out.println("\n[恢复] 从日志重放命令:");
        for (Command c : loadCommands("commands.log")) c.execute();
    }
}
