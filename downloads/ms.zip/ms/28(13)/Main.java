import java.util.HashMap;
import java.util.Map;

/** 题28 - 网络设备 (享元 - 内部状态) */
class NetworkDevice {
    private String type; // 内部状态: 设备类型
    public NetworkDevice(String type) { this.type = type; }
    public void forwardData(String port, String data) {
        System.out.println("  [" + type + ":" + port + "] 转发数据 -> " + data);
    }
}

/** 题28 - 享元工厂 */
class DeviceFactory {
    private Map<String, NetworkDevice> pool = new HashMap<>();
    public NetworkDevice getDevice(String type) {
        if (!pool.containsKey(type)) {
            pool.put(type, new NetworkDevice(type));
            System.out.println("[设备池] 创建新设备: " + type);
        }
        return pool.get(type);
    }
    public int getPoolSize() { return pool.size(); }
}

/** 题28 - 主测试 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 共享网络设备 - 享元模式 =====\n");
        DeviceFactory factory = new DeviceFactory();
        String[] ports = {"P01","P02","P03","P04"};
        // 多台终端共享同一设备，但端口不同(外部状态)
        for (int i = 0; i < 4; i++) {
            factory.getDevice("交换机").forwardData(ports[i], "来自终端"+(i+1)+"的数据包");
        }
        System.out.println("\n[统计] 设备池中对象数: " + factory.getPoolSize() + " (对象被共享)");
    }
}
