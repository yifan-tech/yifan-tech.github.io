/** 题27 - 子系统类 */
class ContactsMgr { public void backup() { System.out.println("  [通讯录] 备份完成 (125条)"); } }
class SMSMgr { public void backup() { System.out.println("  [短信] 备份完成 (340条)"); } }
class PhotoMgr { public void backup() { System.out.println("  [照片] 备份完成 (89张)"); } }
class MusicMgr { public void backup() { System.out.println("  [歌曲] 备份完成 (56首)"); } }

/** 题27 - 外观: 一键备份 */
public class Main {
    private ContactsMgr contacts = new ContactsMgr();
    private SMSMgr sms = new SMSMgr();
    private PhotoMgr photo = new PhotoMgr();
    private MusicMgr music = new MusicMgr();

    public void oneKeyBackup() {
        System.out.println(">>> 开始一键备份...");
        contacts.backup(); sms.backup(); photo.backup(); music.backup();
        System.out.println(">>> 备份完毕! 数据已存至SD卡\n");
    }

    public static void main(String[] args) {
        System.out.println("===== 手机一键备份 - 外观模式 =====\n");
        new Main().oneKeyBackup();
    }
}
