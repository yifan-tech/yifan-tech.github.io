import java.util.*;

/** 题44 - 电视聚合类 */
class TV implements Iterable<String> {
    private List<String> channels = new ArrayList<>();
    public void addChannel(String c) { channels.add(c); }
    @Override public Iterator<String> iterator() { return channels.iterator(); }
}

/** 题44 - 遥控器 */
public class Main {
    private TV tv;
    public Main(TV tv) { this.tv = tv; }
    public void browse() {
        for (Iterator<String> it = tv.iterator(); it.hasNext();) {
            System.out.println("  [遥控器] 切换到频道: " + it.next());
        }
    }
    public static void main(String[] args) {
        System.out.println("===== 电视机遥控器 - 迭代器模式 =====\n");
        TV tv = new TV();
        tv.addChannel("CCTV-1"); tv.addChannel("CCTV-5"); tv.addChannel("湖南卫视"); tv.addChannel("浙江卫视");
        new Main(tv).browse();
    }
}
