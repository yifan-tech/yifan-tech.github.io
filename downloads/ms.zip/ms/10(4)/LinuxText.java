public class LinuxText extends Text {
    public LinuxText() { super("Linux"); }
    @Override
    public void input(String content) {
        System.out.println("  [Linux Text] 使用 GTK+/GtkEntry 控件显示: " + content);
    }
}
