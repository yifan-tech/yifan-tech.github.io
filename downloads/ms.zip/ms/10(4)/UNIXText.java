public class UNIXText extends Text {
    public UNIXText() { super("UNIX"); }
    @Override
    public void input(String content) {
        System.out.println("  [UNIX Text] 使用 Motif/XmText 控件显示: " + content);
    }
}
