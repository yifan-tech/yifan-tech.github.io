public class WindowsFactory extends GUIFactory {
    @Override public Button createButton() { return new WindowsButton(); }
    @Override public Text createText() { return new WindowsText(); }
}
