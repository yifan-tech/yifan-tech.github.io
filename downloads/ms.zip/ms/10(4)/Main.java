/**
 * 题10 测试类 - 跨OS图形构件 (抽象工厂模式)
 *
 * ============================ 类图 ============================
 *   ┌───────────────┐
 *   │  GUIFactory   │ (抽象工厂)
 *   ├───────────────┤
 *   │+createButton()│
 *   │+createText()  │
 *   └───────┬───────┘
 *      ┌────┼─────────────┐
 *      ▼    ▼             ▼
 * ┌──────────┐┌──────────┐┌──────────┐
 * │ Windows  ││  UNIX    ││  Linux   │
 * │ Factory  ││ Factory  ││ Factory  │
 * └──┬───┬───┘└──┬───┬───┘└──┬───┬───┘
 *    │   │       │   │       │   │
 *    ▼   ▼       ▼   ▼       ▼   ▼
 * ┌──────┐┌──────┐  (Windows/UNIX/Linux 产品族各一组)
 * │WinBtn││WinTxt│
 * └──┬───┘└──┬───┘
 *    │       │
 *    ▼       ▼
 * ┌──────┐┌──────┐
 * │Button││ Text │ (抽象产品 - 产品等级结构)
 * └──────┘└──────┘
 *
 * 产品族(横向): WindowsFactory -> {WindowsButton, WindowsText}
 * 产品等级(纵向): Button -> {WindowsButton, UNIXButton, LinuxButton}
 * =============================================================
 */
public class Main {
    private static void testGUI(GUIFactory factory, String osName) {
        System.out.println("--- " + osName + " 平台 ---");
        Button btn = factory.createButton();
        Text txt = factory.createText();
        btn.click();
        txt.input("Hello " + osName + "!");
        System.out.println();
    }

    public static void main(String[] args) {
        System.out.println("===== 跨OS图形构件 - 抽象工厂模式 =====\n");
        testGUI(new WindowsFactory(), "Windows");
        testGUI(new UNIXFactory(), "UNIX");
        testGUI(new LinuxFactory(), "Linux");
        System.out.println("===== 所有平台GUI构件创建完成 =====");
    }
}
