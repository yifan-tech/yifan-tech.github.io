/**
 * Text 抽象产品 —— 文本框
 */
public abstract class Text {
    protected String os;

    public Text(String os) { this.os = os; }
    public abstract void input(String content);
}
