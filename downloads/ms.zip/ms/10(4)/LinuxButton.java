public class LinuxButton extends Button {
    public LinuxButton() { super("Linux"); }
    @Override
    public void click() {
        System.out.println("  [Linux Button] 使用 GTK+/Qt 绘制 -> 触发 GtkSignal 消息");
    }
}
