public class WindowsButton extends Button {
    public WindowsButton() { super("Windows"); }
    @Override
    public void click() {
        System.out.println("  [Windows Button] 使用 Win32 API 绘制 -> 触发 WM_COMMAND 消息");
    }
}
