public class WindowsText extends Text {
    public WindowsText() { super("Windows"); }
    @Override
    public void input(String content) {
        System.out.println("  [Windows Text] 使用 Win32 EDIT 控件显示: " + content);
    }
}
