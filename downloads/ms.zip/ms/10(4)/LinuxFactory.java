public class LinuxFactory extends GUIFactory {
    @Override public Button createButton() { return new LinuxButton(); }
    @Override public Text createText() { return new LinuxText(); }
}
