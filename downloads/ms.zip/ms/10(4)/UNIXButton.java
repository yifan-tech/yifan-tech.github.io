public class UNIXButton extends Button {
    public UNIXButton() { super("UNIX"); }
    @Override
    public void click() {
        System.out.println("  [UNIX Button] 使用 Motif/X11 绘制 -> 触发 XEvent 消息");
    }
}
