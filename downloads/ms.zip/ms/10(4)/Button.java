/**
 * Button 抽象产品 —— 按钮
 */
public abstract class Button {
    protected String os;

    public Button(String os) { this.os = os; }
    public abstract void click();
}
