public class UNIXFactory extends GUIFactory {
    @Override public Button createButton() { return new UNIXButton(); }
    @Override public Text createText() { return new UNIXText(); }
}
