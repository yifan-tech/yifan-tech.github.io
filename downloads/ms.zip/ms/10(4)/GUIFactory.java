/**
 * GUIFactory 抽象工厂
 * 产品族: {Button, Text} (同一操作系统下的构件家族)
 * 产品等级: Button (WindowsButton / UNIXButton / LinuxButton)
 *          Text   (WindowsText   / UNIXText   / LinuxText)
 */
public abstract class GUIFactory {
    public abstract Button createButton();
    public abstract Text createText();
}
