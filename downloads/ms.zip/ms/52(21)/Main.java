import java.util.*;

/** 题52 - 观察者 */
interface Investor { void update(String stock, double price); }
class StockInvestor implements Investor {
    private String name; public StockInvestor(String n) { this.name = n; }
    @Override public void update(String s, double p) { System.out.println("  [" + name + "] 收到通知: " + s + " 最新价 " + p); }
}

/** 题52 - 被观察者: 股票 */
class Stock {
    private String name; private double price;
    private List<Investor> investors = new ArrayList<>();
    public Stock(String n, double p) { this.name = n; this.price = p; }
    public void attach(Investor i) { investors.add(i); }
    public void setPrice(double newPrice) {
        double old = price; price = newPrice;
        if (Math.abs((newPrice - old) / old) >= 0.05) notifyAll(old + "->" + newPrice);
    }
    private void notifyAll(String msg) {
        System.out.println("[股票:" + name + "] 价格变化超过5%! " + msg);
        for (Investor i : investors) i.update(name, price);
    }
}

/** 题52 主测试 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 股票价格通知 - 观察者模式 =====\n");
        Stock tsla = new Stock("TSLA", 200);
        tsla.attach(new StockInvestor("股民A")); tsla.attach(new StockInvestor("股民B"));
        tsla.setPrice(205); // 变化2.5%, 不通知
        tsla.setPrice(220); // 变化7.3% > 5%, 通知所有观察者
    }
}
