/** 题36 - 查询上下文 */
abstract class HelpContext {
    protected HelpContext next;
    protected String name;
    public HelpContext(String name, HelpContext next) { this.name = name; this.next = next; }
    public void search(String keyword) {
        if (hasContent(keyword)) System.out.println("  [" + name + "] 找到相关内容: " + keyword);
        else if (next != null) { System.out.println("  [" + name + "] 无结果, 转发到 " + next.name + "..."); next.search(keyword); }
        else System.out.println("  [所有上下文] 均无相关内容");
    }
    protected abstract boolean hasContent(String kw);
}
class BasicHelp extends HelpContext {
    public BasicHelp(HelpContext n) { super("基础帮助", n); }
    @Override protected boolean hasContent(String kw) { return kw.contains("入门") || kw.contains("安装"); }
}
class APIHelp extends HelpContext {
    public APIHelp(HelpContext n) { super("API参考", n); }
    @Override protected boolean hasContent(String kw) { return kw.contains("class") || kw.contains("方法"); }
}
class FAQHelp extends HelpContext {
    public FAQHelp() { super("常见问题(FAQ)", null); }
    @Override protected boolean hasContent(String kw) { return true; }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== 在线文档帮助 - 职责链模式 =====\n");
        HelpContext chain = new BasicHelp(new APIHelp(new FAQHelp()));
        chain.search("如何安装");
        System.out.println();
        chain.search("String类的方法");
        System.out.println();
        chain.search("其他问题");
    }
}
