import java.util.*;

/** 题41 - 公告板界面 */
class BoardScreen {
    public void open() { System.out.println("  打开公告板"); }
    public void create() { System.out.println("  新建公告"); }
    public void edit() { System.out.println("  编辑公告"); }
}

/** 命令接口 */
interface Command { void execute(); }
class OpenCommand implements Command {
    private BoardScreen board; public OpenCommand(BoardScreen b) { this.board = b; }
    @Override public void execute() { board.open(); }
}
class CreateCommand implements Command {
    private BoardScreen board; public CreateCommand(BoardScreen b) { this.board = b; }
    @Override public void execute() { board.create(); }
}
class EditCommand implements Command {
    private BoardScreen board; public EditCommand(BoardScreen b) { this.board = b; }
    @Override public void execute() { board.edit(); }
}

/** 题41 - 菜单项 */
class MenuItem {
    private String name; private Command cmd;
    public MenuItem(String name, Command c) { this.name = name; this.cmd = c; }
    public void click() { System.out.print("  点击[" + name + "] -> "); cmd.execute(); }
}

/** 题41 - 菜单 */
public class Main {
    private List<MenuItem> items = new ArrayList<>();
    public void addMenuItem(MenuItem item) { items.add(item); System.out.println("[菜单] 添加菜单项: " + item); }
    public static void main(String[] args) {
        System.out.println("===== 公告板系统 - 命令模式 =====\n");
        Main menu = new Main();
        BoardScreen board = new BoardScreen();
        menu.addMenuItem(new MenuItem("打开", new OpenCommand(board)));
        menu.addMenuItem(new MenuItem("新建", new CreateCommand(board)));
        menu.addMenuItem(new MenuItem("编辑", new EditCommand(board)));
        System.out.println();
        menu.items.get(0).click();
        menu.items.get(1).click();
        menu.items.get(2).click();
        System.out.println("\n命令模式解耦: MenuItem 不直接依赖 BoardScreen");
    }
}
