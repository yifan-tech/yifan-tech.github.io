import java.util.*;

/** 题53 - 观察者接口 */
interface Observer { void update(String event); }

/** 被观察者: 猫 */
class Cat {
    private List<Observer> observers = new ArrayList<>();
    public void addObserver(Observer o) { observers.add(o); }
    public void scream() {
        System.out.println("  [猫] 大叫一声! 喵呜~~~");
        for (Observer o : observers) o.update("猫叫了");
    }
}

/** 具体观察者 */
class Mouse implements Observer {
    @Override public void update(String e) { System.out.println("  [老鼠] 听到猫叫, 开始逃跑!"); }
}
class Master implements Observer {
    @Override public void update(String e) { System.out.println("  [主人] 被猫叫声惊醒!"); }
}

/** 题53 - 教师学生 */
class Teacher implements Observer {
    private String name; public Teacher(String n) { this.name = n; }
    @Override public void update(String e) { System.out.println("  [教师" + name + "] 系名已更新为: " + e); }
}
class Stu implements Observer {
    private String name; public Stu(String n) { this.name = n; }
    @Override public void update(String e) { System.out.println("  [学生" + name + "] 系名已更新为: " + e); }
}
class Department {
    private String name; private List<Observer> members = new ArrayList<>();
    public Department(String n) { this.name = n; }
    public void addMember(Observer o) { members.add(o); }
    public void rename(String newName) { name = newName;
        for (Observer o : members) o.update(newName); }
}

/** 题53 主测试 (观察者模式) */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 猫叫事件 - 观察者模式 =====\n");
        Cat cat = new Cat();
        cat.addObserver(new Mouse()); cat.addObserver(new Master());
        cat.scream();

        System.out.println("\n===== 教学管理系统 - 观察者模式 =====\n");
        Department cs = new Department("计算机系");
        cs.addMember(new Teacher("王教授")); cs.addMember(new Stu("赵同学"));
        System.out.println("原系名: 计算机系");
        cs.rename("人工智能与计算机学院");
    }
}
