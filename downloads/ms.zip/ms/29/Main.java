import java.util.HashMap;
import java.util.Map;

/** 题29 - 享元: 字符串对象 (内部状态: 字符内容) */
class CharFlyweight {
    private String content; // 内部状态
    public CharFlyweight(String c) { this.content = c; }
    public void display(String color, int size) { // 外部状态
        System.out.println("  显示字符串 [" + content + "] 颜色: " + color + " 字号: " + size + " 对象hash:" + hashCode());
    }
}

class CharFactory {
    private Map<String, CharFlyweight> pool = new HashMap<>();
    public CharFlyweight getChar(String c) {
        if (!pool.containsKey(c)) pool.put(c, new CharFlyweight(c));
        return pool.get(c);
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== 字符串共享 - 享元模式 =====\n");
        CharFactory factory = new CharFactory();
        System.out.println("文档中的 'Java' 出现多次, 颜色/大小不同:");
        CharFlyweight j1 = factory.getChar("Java");
        CharFlyweight j2 = factory.getChar("Java");
        CharFlyweight j3 = factory.getChar("Java");
        j1.display("Red", 12);
        j2.display("Blue", 18);
        j3.display("Green", 14);
        System.out.println("\n j1==j2==j3 ? " + (j1==j2 && j2==j3) + " (同一对象被共享)");
    }
}
