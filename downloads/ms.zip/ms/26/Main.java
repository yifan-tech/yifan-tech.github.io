/** 题26 - 子系统类 */
class Memory { public void check() { System.out.println("  [Memory] 自检...OK"); } }
class CPU { public void run() { System.out.println("  [CPU] 启动运行...OK"); } }
class HardDisk { public void read() { System.out.println("  [HardDisk] 读取引导区...OK"); } }
class OS { public void load() { System.out.println("  [OS] 加载操作系统...OK"); } }

/** 题26 - 外观: 主机 */
public class Main {
    private Memory mem = new Memory();
    private CPU cpu = new CPU();
    private HardDisk hd = new HardDisk();
    private OS os = new OS();

    public void on() {
        System.out.println(">>> 按下开机按钮...");
        try { mem.check(); cpu.run(); hd.read(); os.load();
            System.out.println(">>> 电脑启动成功!\n");
        } catch(Exception e) { System.out.println(">>> 启动失败: " + e.getMessage()); }
    }

    public static void main(String[] args) {
        System.out.println("===== 电脑主机启动 - 外观模式 =====\n");
        new Main().on();
    }
}
