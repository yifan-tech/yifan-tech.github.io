/**
 * Aircraft 抽象类 —— 飞机类型维度 (抽象)
 * 持有 PlaneType (制造商) 引用，形成桥接
 */
public abstract class Aircraft {
    protected PlaneType manufacturer;  // 桥接: 制造商
    protected String model;

    public Aircraft(PlaneType manufacturer, String model) {
        this.manufacturer = manufacturer;
        this.model = model;
    }

    /** 生产飞机 */
    public abstract void manufacture();
}
