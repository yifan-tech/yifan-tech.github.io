/**
 * McDonnellDouglas 具体实现者 —— 麦道
 */
public class McDonnellDouglas implements PlaneType {

    @Override
    public void producePassengerPlane(String model) {
        System.out.println("  [McDonnell-Douglas] 生产载客飞机 " + model);
        System.out.println("    -> 长滩总装线组装 | MD-80/MD-90/MD-11系列");
    }

    @Override
    public void produceCargoPlane(String model) {
        System.out.println("  [McDonnell-Douglas] 生产载货飞机 " + model);
        System.out.println("    -> MD-11F货机 | C-17军用运输机");
    }
}
