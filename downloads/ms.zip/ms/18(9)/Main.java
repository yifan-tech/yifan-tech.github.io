/**
 * 题18 测试类 - 飞机制造商 (桥接模式)
 *
 * ============================ 类图 ============================
 *   ┌──────────────┐        ┌──────────────┐
 *   │   Aircraft   │───────>│  PlaneType   │ (实现者接口)
 *   ├──────────────┤        ├──────────────┤
 *   │#manufacturer │        │+producePass  │
 *   │#model        │        │ engerPlane() │
 *   │+manufacture()│        │+produceCargo │
 *   └──────┬───────┘        │ Plane()      │
 *          │                └──────┬───────┘
 *   ┌──────┴──────┐      ┌────────┼─────────┐
 *   ▼             ▼      ▼        ▼         ▼
 * ┌────────┐ ┌────────┐ ┌────┐ ┌──────┐ ┌────────┐
 * │Passenger││ Cargo  │ │Air-│ │Boeing│ │McDon- │
 * │ Plane  ││ Plane  │ │bus │ │      │ │nell   │
 * └────────┘ └────────┘ └────┘ └──────┘ └────────┘
 *   (抽象维度)           (实现者维度)
 * 桥接: Aircraft ◄──► PlaneType  两个维度独立扩展
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 飞机制造商 - 桥接模式 =====\n");

        // 空客生产 A320 载客飞机
        new PassengerPlane(new Airbus(), "A320neo").manufacture();

        // 波音生产 777F 载货飞机
        new CargoPlane(new Boeing(), "777F").manufacture();

        // 麦道生产 MD-11 载客飞机
        new PassengerPlane(new McDonnellDouglas(), "MD-11").manufacture();

        // 空客生产 A330-200F 载货飞机
        new CargoPlane(new Airbus(), "A330-200F").manufacture();

        System.out.println("===== 生产完毕 =====");
        System.out.println("特点: 飞机类型(载客/载货)与制造商(空客/波音/麦道)两个维度独立扩展");
    }
}
