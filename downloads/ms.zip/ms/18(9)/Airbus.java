/**
 * Airbus 具体实现者 —— 空客
 */
public class Airbus implements PlaneType {

    @Override
    public void producePassengerPlane(String model) {
        System.out.println("  [Airbus] 生产载客飞机 " + model);
        System.out.println("    -> 图卢兹总装线组装 | A320/A330/A350系列");
    }

    @Override
    public void produceCargoPlane(String model) {
        System.out.println("  [Airbus] 生产载货飞机 " + model);
        System.out.println("    -> BelugaXL超大运输机 | A330-200F货机");
    }
}
