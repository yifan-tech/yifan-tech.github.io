/**
 * CargoPlane 细化抽象 —— 载货飞机
 */
public class CargoPlane extends Aircraft {

    public CargoPlane(PlaneType manufacturer, String model) {
        super(manufacturer, model);
    }

    @Override
    public void manufacture() {
        System.out.println(">>> 生产载货飞机: " + model);
        manufacturer.produceCargoPlane(model);
        System.out.println("    -> 配置货舱导轨 + 大型货舱门 + 加固地板\n");
    }
}
