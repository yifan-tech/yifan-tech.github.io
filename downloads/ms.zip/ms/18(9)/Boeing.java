/**
 * Boeing 具体实现者 —— 波音
 */
public class Boeing implements PlaneType {

    @Override
    public void producePassengerPlane(String model) {
        System.out.println("  [Boeing] 生产载客飞机 " + model);
        System.out.println("    -> 西雅图总装线组装 | 737/777/787系列");
    }

    @Override
    public void produceCargoPlane(String model) {
        System.out.println("  [Boeing] 生产载货飞机 " + model);
        System.out.println("    -> 747 Dreamlifter | 777F货机");
    }
}
