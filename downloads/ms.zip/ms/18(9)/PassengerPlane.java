/**
 * PassengerPlane 细化抽象 —— 载客飞机
 */
public class PassengerPlane extends Aircraft {

    public PassengerPlane(PlaneType manufacturer, String model) {
        super(manufacturer, model);
    }

    @Override
    public void manufacture() {
        System.out.println(">>> 生产载客飞机: " + model);
        manufacturer.producePassengerPlane(model);
        System.out.println("    -> 配置客舱座椅 + 娱乐系统 + 厨房\n");
    }
}
