/**
 * PlaneType 实现者接口 —— 飞机制造商维度
 * 定义制造商的制造能力
 */
public interface PlaneType {
    /** 制造载客飞机 */
    void producePassengerPlane(String model);

    /** 制造载货飞机 */
    void produceCargoPlane(String model);
}
