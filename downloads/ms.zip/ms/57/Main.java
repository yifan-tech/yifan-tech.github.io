import java.util.Arrays;

/** 题57 - 策略接口 */
interface SortStrategy { void sort(int[] arr); }

class BubbleSort implements SortStrategy {
    @Override public void sort(int[] a) {
        for (int i = 0; i < a.length - 1; i++)
            for (int j = 0; j < a.length - 1 - i; j++)
                if (a[j] > a[j + 1]) { int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; }
        System.out.println("  [冒泡排序] 完成");
    }
}

class SelectionSort implements SortStrategy {
    @Override public void sort(int[] a) {
        for (int i = 0; i < a.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < a.length; j++) if (a[j] < a[min]) min = j;
            int t = a[i]; a[i] = a[min]; a[min] = t;
        }
        System.out.println("  [选择排序] 完成");
    }
}

class InsertionSort implements SortStrategy {
    @Override public void sort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int key = a[i], j = i - 1;
            while (j >= 0 && a[j] > key) { a[j + 1] = a[j]; j--; }
            a[j + 1] = key;
        }
        System.out.println("  [插入排序] 完成");
    }
}

/** 题57 - 数组操作上下文 */
public class Main {
    private SortStrategy strategy;
    public void setStrategy(SortStrategy s) { this.strategy = s; }
    public void sort(int[] arr) { strategy.sort(arr); }

    public static void main(String[] args) {
        System.out.println("===== 数组排序(动态切换算法) - 策略模式 =====\n");
        Main ctx = new Main();
        int[] a1 = {5,2,8,1,9}; ctx.setStrategy(new BubbleSort()); ctx.sort(a1);
        System.out.println("  结果: " + Arrays.toString(a1) + "\n");

        int[] a2 = {6,3,9,0,4}; ctx.setStrategy(new InsertionSort()); ctx.sort(a2);
        System.out.println("  结果: " + Arrays.toString(a2));

        System.out.println("\n新增排序算法只需实现SortStrategy接口,完全符合开闭原则");
    }
}
