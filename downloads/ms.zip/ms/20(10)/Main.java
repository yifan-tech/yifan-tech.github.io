/**
 * 题20 测试类 - 教育机构组织结构 (组合模式)
 * 类图: Unit(抽象构件) <- Office(叶子) / Department(容器)
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 教育机构OA公文下发 - 组合模式 =====\n");

        Department root = new Department("北京总部");
        Department hrb = new Department("哈尔滨分部");
        Department sha = new Department("上海分部");

        Office hrbA = new Office("行政办公室(哈尔滨)");
        Office hrbB = new Office("教务办公室(哈尔滨)");
        Office shaA = new Office("行政办公室(上海)");

        hrb.add(hrbA); hrb.add(hrbB);
        sha.add(shaA);
        root.add(hrb); root.add(sha);

        System.out.println("--- 下发公文到全体 ---");
        root.receiveDocument("关于期末考试安排的通知");
    }
}
