/** 题20 - 叶子构件：办公室 */
public class Office extends Unit {
    public Office(String name) { super(name); }
    @Override
    public void receiveDocument(String doc) {
        System.out.println("  [" + name + "] 收到公文: " + doc);
    }
}
