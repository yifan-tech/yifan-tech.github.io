import java.util.ArrayList;
import java.util.List;

/** 题20 - 抽象构件 */
public abstract class Unit {
    protected String name;
    public Unit(String name) { this.name = name; }
    public abstract void receiveDocument(String doc);
    public void add(Unit u) { throw new UnsupportedOperationException(); }
    public void remove(Unit u) { throw new UnsupportedOperationException(); }
}
