import java.util.ArrayList;
import java.util.List;

/** 题20 - 容器构件：部门(可包含子部门和办公室) */
public class Department extends Unit {
    private List<Unit> children = new ArrayList<>();
    public Department(String name) { super(name); }

    @Override
    public void add(Unit u) { children.add(u); }
    @Override
    public void remove(Unit u) { children.remove(u); }

    @Override
    public void receiveDocument(String doc) {
        System.out.println("[" + name + "] 转发公文: " + doc);
        for (Unit c : children) c.receiveDocument(doc);
    }
}
