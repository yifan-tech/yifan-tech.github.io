/** 题37 - 请假条 */
class LeaveRequest {
    String name; int days;
    public LeaveRequest(String n, int d) { this.name = n; this.days = d; }
}

abstract class Approver {
    protected Approver next;
    public Approver(Approver n) { this.next = n; }
    public abstract void approve(LeaveRequest r);
}
class Director extends Approver {
    public Director(Approver n) { super(n); }
    @Override public void approve(LeaveRequest r) {
        if (r.days < 3) System.out.println("  主任审批通过: " + r.name + " 请假" + r.days + "天");
        else { System.out.println("  主任无权审批("+r.days+"天), 转经理..."); next.approve(r); }
    }
}
class Manager extends Approver {
    public Manager(Approver n) { super(n); }
    @Override public void approve(LeaveRequest r) {
        if (r.days < 10) System.out.println("  经理审批通过: " + r.name + " 请假" + r.days + "天");
        else { System.out.println("  经理无权审批("+r.days+"天), 转总经理..."); next.approve(r); }
    }
}
class GeneralManager extends Approver {
    public GeneralManager() { super(null); }
    @Override public void approve(LeaveRequest r) {
        if (r.days < 30) System.out.println("  总经理审批通过: " + r.name + " 请假" + r.days + "天");
        else System.out.println("  拒绝! " + r.name + " 请假" + r.days + "天超过30天, 无法审批");
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("===== 假条审批 - 职责链模式 =====\n");
        Approver chain = new Director(new Manager(new GeneralManager()));
        for (int[] d : new int[][]{{2},{8},{15},{35}}) {
            LeaveRequest r = new LeaveRequest("员工张三", d[0]);
            System.out.println(">>> " + r.name + " 请假 " + r.days + " 天");
            chain.approve(r);
            System.out.println();
        }
    }
}
