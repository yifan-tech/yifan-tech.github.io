/** 题23 - 具体配料: 牛奶 */
public class Milk extends Condiment {
    public Milk(Beverage b) { this.beverage = b; }
    @Override public String getDesc() { return beverage.getDesc() + "+牛奶"; }
    @Override public double cost() { return beverage.cost() + 3.0; }
}
