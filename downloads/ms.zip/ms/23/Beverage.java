/** 题23 - 抽象构件: 饮料 */
public abstract class Beverage {
    protected String desc = "未知";
    public String getDesc() { return desc; }
    public abstract double cost();
}
