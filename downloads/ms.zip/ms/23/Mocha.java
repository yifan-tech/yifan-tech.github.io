/** 题23 - 具体配料: 摩卡 */
public class Mocha extends Condiment {
    public Mocha(Beverage b) { this.beverage = b; }
    @Override public String getDesc() { return beverage.getDesc() + "+摩卡"; }
    @Override public double cost() { return beverage.cost() + 4.0; }
}
