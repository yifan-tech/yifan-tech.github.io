/** 题23 具体配料: 奶泡 */
public class Soy extends Condiment {
    public Soy(Beverage b) { this.beverage = b; }
    @Override public String getDesc() { return beverage.getDesc() + "+奶泡"; }
    @Override public double cost() { return beverage.cost() + 2.5; }
}
