/** 题23 测试 - 咖啡配料 (装饰模式) */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 咖啡店 - 装饰模式 =====\n");
        Beverage b1 = new Espresso();
        System.out.println(b1.getDesc() + " = " + b1.cost() + "元");
        Beverage b2 = new Mocha(new Milk(new Americano()));
        System.out.println(b2.getDesc() + " = " + b2.cost() + "元");
        Beverage b3 = new Soy(new Mocha(new Mocha(new Espresso())));
        System.out.println(b3.getDesc() + " = " + b3.cost() + "元");
    }
}
