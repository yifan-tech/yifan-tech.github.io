/** 题23 - 抽象装饰: 配料 */
public abstract class Condiment extends Beverage {
    protected Beverage beverage;
    public abstract String getDesc();
}
