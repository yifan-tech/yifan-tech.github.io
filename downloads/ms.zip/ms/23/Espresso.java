/** 题23 - 具体饮料: 浓缩咖啡 */
public class Espresso extends Beverage {
    public Espresso() { desc = "浓缩咖啡"; }
    @Override public double cost() { return 15.0; }
}
