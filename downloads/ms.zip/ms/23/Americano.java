/** 题23 - 具体饮料: 美式咖啡 */
public class Americano extends Beverage {
    public Americano() { desc = "美式咖啡"; }
    @Override public double cost() { return 12.0; }
}
