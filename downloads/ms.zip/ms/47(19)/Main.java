/** 题47 - 抽象中介者: 联合国 */
abstract class UN {
    public abstract void declare(String country, String msg);
}
/** 具体中介者: WTO */
class WTO extends UN {
    private USA usa; private China china;
    public void setUSA(USA u) { this.usa = u; }
    public void setChina(China c) { this.china = c; }
    @Override public void declare(String country, String msg) {
        System.out.println("[WTO] " + country + " 发言: " + msg);
    }
}

/** 抽象同事: 国家 */
abstract class Country {
    protected UN un; protected String name;
    public Country(UN u, String n) { this.un = u; this.name = n; }
    public void speak(String msg) { un.declare(name, msg); }
    public abstract void receive(String msg);
}
class USA extends Country {
    public USA(UN u) { super(u, "美国"); }
    @Override public void receive(String msg) { System.out.println("  美国收到: " + msg); }
}
class China extends Country {
    public China(UN u) { super(u, "中国"); }
    @Override public void receive(String msg) { System.out.println("  中国收到: " + msg); }
}

/** 题47 主测试 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 联合国(WTO) - 中介者模式 =====\n");
        WTO wto = new WTO();
        USA usa = new USA(wto); China china = new China(wto);
        wto.setUSA(usa); wto.setChina(china);
        usa.speak("呼吁降低关税壁垒");
        china.speak("倡议多边贸易合作");
        System.out.println("\n国家间通过联合国(中介者)协调, 不直接交互");
    }
}
