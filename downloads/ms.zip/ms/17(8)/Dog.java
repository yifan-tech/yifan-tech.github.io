/**
 * Dog 目标接口/抽象类 —— 狗的行为
 */
public abstract class Dog {
    public abstract void cry();
}
