/**
 * 题17 测试类 - 双向适配器 (适配器模式)
 *
 * ============================ 类图 ============================
 *    ┌──────┐           ┌───────────┐           ┌──────┐
 *    │ Cat  │◄───────│CatAdapter │           │ Dog  │
 *    ├──────┤         ├───────────┤           ├──────┤
 *    │+catch│         │-dog:Dog   │           │+cry()│
 *    │Mouse │         │+catchMouse│           └──┬───┘
 *    └──┬───┘         └───────────┘              ▲
 *       ▲                                        │
 *       │         ┌───────────┐           ┌──────┴───────┐
 *  ┌────────┐     │DogAdapter │──────────>│              │
 *  │Concrete│     ├───────────┤           │  Concrete    │
 *  │  Cat   │     │-cat:Cat   │           │    Dog       │
 *  └────────┘     │+cry()     │           └──────────────┘
 *                 └───────────┘
 *
 * CatAdapter: Dog -> Cat  (狗学猫抓老鼠)
 * DogAdapter: Cat -> Dog  (猫学狗叫)
 * =============================================================
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("===== 双向适配器 - 猫学狗叫 / 狗学猫抓老鼠 =====\n");

        Cat realCat = new ConcreteCat();
        Dog realDog = new ConcreteDog();

        System.out.println("--- 真实行为 ---");
        realCat.catchMouse();
        realDog.cry();

        System.out.println("\n--- 适配器行为 ---");

        // 狗学猫抓老鼠 (CatAdapter)
        Cat dogAsCat = new CatAdapter(realDog);
        dogAsCat.catchMouse();

        // 猫学狗叫 (DogAdapter)
        Dog catAsDog = new DogAdapter(realCat);
        catAsDog.cry();

        System.out.println("\n===== 演示完毕 =====");
    }
}
