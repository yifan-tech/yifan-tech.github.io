/**
 * DogAdapter 适配器 —— 让猫变成狗 (猫学狗叫)
 * 继承Dog, 内部组合Cat对象, 将cry适配为猫的catchMouse
 */
public class DogAdapter extends Dog {
    private Cat cat;

    public DogAdapter(Cat cat) {
        this.cat = cat;
    }

    @Override
    public void cry() {
        System.out.print("  [猫学狗] 尝试汪汪叫 -> ");
        cat.catchMouse();  // 抓老鼠来代替狗叫
    }
}
