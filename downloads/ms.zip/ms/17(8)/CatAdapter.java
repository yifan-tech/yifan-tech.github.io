/**
 * CatAdapter 适配器 —— 让狗变成猫 (狗学猫抓老鼠)
 * 继承Cat, 内部组合Dog对象, 将catchMouse适配为狗的cry
 */
public class CatAdapter extends Cat {
    private Dog dog;

    public CatAdapter(Dog dog) {
        this.dog = dog;
    }

    @Override
    public void catchMouse() {
        System.out.print("  [狗学猫] 尝试抓老鼠 -> ");
        dog.cry();  // 狗叫来代替抓老鼠
    }
}
