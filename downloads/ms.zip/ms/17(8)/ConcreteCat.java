/**
 * ConcreteCat 真正的猫
 */
public class ConcreteCat extends Cat {
    @Override
    public void catchMouse() {
        System.out.println("  [猫] 喵呜~ 抓到一只老鼠!");
    }
}
