/**
 * ConcreteDog 真正的狗
 */
public class ConcreteDog extends Dog {
    @Override
    public void cry() {
        System.out.println("  [狗] 汪汪汪~!");
    }
}
