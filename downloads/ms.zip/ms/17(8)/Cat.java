/**
 * Cat 目标接口/抽象类 —— 猫的行为
 */
public abstract class Cat {
    public abstract void catchMouse();
}
